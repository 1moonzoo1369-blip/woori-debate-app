@echo off
chcp 65001 >nul
title 토론 수업 앱 (같은 와이파이) - 이 창을 닫으면 앱이 꺼집니다
cd /d "%~dp0"

rem ===== exe가 있으면 그걸로 바로 실행 (폴더형 우선) =====
if exist "DebateApp\DebateApp.exe" goto runexedir
if exist "DebateApp.exe" goto runexe

rem ===== 파이썬 찾기: py 런처 우선, 없으면 python =====
set "PY="
py -3 -c "import sys" >nul 2>nul && set "PY=py -3"
if not defined PY python -c "import sys; sys.exit(0 if sys.version_info >= (3,8) else 1)" >nul 2>nul && set "PY=python"
if not defined PY goto nopython

rem ===== 처음 한 번만: 필요한 부품 설치 =====
%PY% -c "import flask, reportlab, waitress" >nul 2>nul && goto run
echo.
echo  처음 실행이라 필요한 부품을 설치하고 있어요. 1~2분 걸리고 인터넷이 필요해요...
echo.
%PY% -m pip install --disable-pip-version-check flask reportlab waitress
if errorlevel 1 goto pipfail

:run
%PY% app.py --lan
if errorlevel 1 goto crashed
exit /b

:runexedir
"DebateApp\DebateApp.exe" --lan
if errorlevel 1 goto crashed
exit /b

:runexe
"DebateApp.exe" --lan
if errorlevel 1 goto crashed
exit /b

:nopython
echo.
echo  [안내] 이 컴퓨터에 파이썬이 설치되어 있지 않아요.
echo   1. 지금 열리는 python.org 에서 Python 을 내려받아 설치하세요.
echo   2. 설치 첫 화면 아래의 "Add python.exe to PATH" 를 꼭 체크하세요.
echo   3. 설치가 끝나면 이 파일을 다시 더블클릭하세요.
start "" "https://www.python.org/downloads/"
pause
exit /b

:pipfail
echo.
echo  [안내] 부품 설치에 실패했어요. 인터넷 연결을 확인하고 다시 실행해 주세요.
pause
exit /b

:crashed
echo.
echo  [안내] 앱이 오류로 멈췄어요. 위의 메시지를 사진으로 찍어 두시면 원인을 찾는 데 도움이 돼요.
pause
exit /b
