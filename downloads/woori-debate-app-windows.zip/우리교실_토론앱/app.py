import json, os, time, threading, random, io, csv, zipfile, re, socket, subprocess, shutil, hmac, atexit, hashlib, secrets, base64
from urllib.parse import quote as urllib_quote
from flask import Flask, request, jsonify, render_template, Response
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.lib import colors
from reportlab.lib.styles import ParagraphStyle
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, HRFlowable, Table, TableStyle
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

import sys
# 실행 방식에 따라 파일 위치 결정
#  - exe(PyInstaller)로 실행: 화면·글꼴은 exe 안(임시 폴더)에서 읽고, 기록(data.json·config.json·archives)은 exe 옆 폴더에 저장
#    (임시 폴더는 exe를 끄면 지워지므로 기록을 거기 두면 사라짐)
#  - python app.py 로 실행: 모두 이 파일이 있는 폴더
if getattr(sys, "frozen", False):
    RES_DIR = getattr(sys, "_MEIPASS", os.path.dirname(os.path.abspath(sys.executable)))
    DATA_DIR = os.path.dirname(os.path.abspath(sys.executable))
    if os.path.basename(DATA_DIR).lower() == "debateapp":           # 폴더형 exe(앱폴더\DebateApp\DebateApp.exe): 기록은 앱 폴더에 (예전 기록·cloudflared와 같은 곳)
        DATA_DIR = os.path.dirname(DATA_DIR)
else:
    RES_DIR = DATA_DIR = os.path.dirname(os.path.abspath(__file__))
app = Flask(__name__, template_folder=os.path.join(RES_DIR, "templates"), static_folder=os.path.join(RES_DIR, "static"))
app.config["SEND_FILE_MAX_AGE_DEFAULT"] = 43200        # 그림·엔진 파일은 학생 기기에 12시간 보관 (다시 열어도 또 받지 않게)

import gzip as _gzip
_GZ_CACHE = {}                                          # 압축해 둔 정적 파일 (경로, 수정 시각) → 압축본


@app.after_request
def _compress(resp):
    """글자로 된 응답(화면·스크립트·상태 정보)은 압축해서 보냄 → 터널로 나가는 양이 크게 줄어듦 (브라우저가 자동으로 풂)"""
    try:
        if resp.status_code != 200 or "Content-Encoding" in resp.headers or "gzip" not in request.headers.get("Accept-Encoding", ""):
            return resp
        ct = resp.headers.get("Content-Type", "")
        if not any(k in ct for k in ("text/", "json", "javascript")):
            return resp                                 # 그림(WebP)·PDF·엑셀은 이미 압축돼 있음
        if resp.direct_passthrough:                     # 정적 파일(engine.js 등): 한 번 압축해 두고 재사용
            path = os.path.join(app.static_folder, request.path[len("/static/"):]) if request.path.startswith("/static/") else None
            if not path or not os.path.isfile(path):
                return resp
            key = (path, os.path.getmtime(path))
            z = _GZ_CACHE.get(key)
            if z is None:
                with open(path, "rb") as f:
                    z = _gzip.compress(f.read(), 6)
                _GZ_CACHE[key] = z
            resp.direct_passthrough = False
        else:
            data = resp.get_data()
            if len(data) < 1024:
                return resp
            z = _gzip.compress(data, 5)
        resp.set_data(z)
        resp.headers["Content-Encoding"] = "gzip"
        resp.headers["Content-Length"] = str(len(z))
        resp.headers.add("Vary", "Accept-Encoding")
    except Exception:
        pass
    return resp

DATA_FILE = os.path.join(DATA_DIR, "data.json")
LOCK = threading.Lock()

DEFAULT_TOPICS = [
    "인공지능 사용, 학교에서 전면 허용해야 한다",
    "학생 두발/복장 자유화해야 한다",
    "학교 내 스마트폰 사용을 전면 허용해야 한다",
    "동물원은 폐지되어야 한다",
]

BAD_WORDS = ["시발", "ㅅㅂ", "병신", "새끼", "꺼져", "미친놈", "미친년", "닥쳐"]

# ---------------------------------------------------------------
# 확정된 흐름 (각 단계 타이머만 있고 수업 전체 시간 제한은 없음):
#   waiting -> claim(5분 + 경고 후 1분 1회) -> prep(3분,읽기전용) -> qa(18분 체스 시계: 팀당 9분 = 3분×3턴, 턴당 최대 3분)
#   -> final(자기 단련 10분 + 경고 후 1분씩 최대 2회) -> done -> (자기피드백 확인 → 다른 조 구경 → 따봉 투표 → 시상식)
# ---------------------------------------------------------------
MAX_ROOMS = 10                # 한 수업에서 쓸 수 있는 최대 조 수
DEFAULT_ROOMS = 6             # 처음 기본 조 수 (그다음부터는 지난 수업에서 정한 값을 이어 씀)
PHASE_ORDER = ["waiting", "claim", "prep", "qa", "final", "done"]   # final = 자기 단련의 시간(최종 결론 + 자기 피드백을 한 화면에서)

PHASE_DURATION = {
    "claim": 5 * 60,      # 최초 주장: 5분 (+경고 후 1분씩 최대 2회)
    "prep": 3 * 60,       # 최초 주장 읽는 시간: 3분, 연장 없이 자동 진행
    "qa": 18 * 60,        # 자유토론 18분 고정 = 체스 시계 (찬성 9분 + 반대 9분, 각각 3분씩 3턴)
    "final": 10 * 60,     # 자기 단련의 시간 10분 (+경고 후 1분씩 최대 2회)
}

DEFAULT_PHASE_DURATION = dict(PHASE_DURATION)   # 토론앱 기본 시간 (교사가 안 바꾸면 이대로)
# 교사가 수업 세팅에서 바꿀 수 있는 범위(분). 턴당 3분·추가시간 규칙은 그대로
TIME_LIMITS = {"claim": (1, 30), "prep": (1, 15), "qa": (2, 60), "final": (1, 30)}

QA_TURN_SECONDS = 180       # 자유토론 한 턴당 기본 3분
EXTENSION_SECONDS = 60      # 경고 1회마다 주는 추가시간
MAX_EXTENSIONS = 2          # (기본값) 추가시간 최대 횟수
PHASE_MAX_EXT = {"claim": 1, "final": 2}   # 최초 주장은 추가 1분 1회만, 자기 단련은 2회
QA_BANK_SECONDS = 540        # (기본값) 자유토론 체스 시계: 팀마다 9분(=3분×3턴) = 전체 18분 — 실제 값은 qa_bank()로 (자유토론 시간의 절반)
QA_TURN_CAP = 180           # 한 턴 최대 3분 (독점 방지)
QA_TURN_WARN = 30           # 턴 남은 시간이 30초 이하면 경고 표시
WARNING_GRACE_SECONDS = EXTENSION_SECONDS * MAX_EXTENSIONS  # 기준시간 이후 자동 제출까지의 총 여유(2분)


def _ext_level(elapsed, base, max_ext=MAX_EXTENSIONS):
    """기준시간 이후 몇 번째 추가시간 구간인지 (0=기준시간 안, 1=첫 1분, ..., max_ext+1=모두 소진)"""
    if elapsed < base:
        return 0
    return min(max_ext + 1, int((elapsed - base) // EXTENSION_SECONDS) + 1)


def _window_remaining(elapsed, base, max_ext=MAX_EXTENSIONS):
    """지금 구간(기준시간 또는 추가 1분)이 끝나기까지 남은 초"""
    lv = _ext_level(elapsed, base, max_ext)
    if lv > max_ext:
        return 0
    return max(0, base + lv * EXTENSION_SECONDS - elapsed)


def qa_bank():
    """자유토론 체스 시계: 팀마다 자유토론 전체 시간의 절반 (기본 18분 → 9분, 30분이면 15분)"""
    return PHASE_DURATION["qa"] // 2


def time_cfg_minutes(s=None):
    """이 수업의 단계별 시간(분). 교사가 안 바꾼 단계는 기본값"""
    cfg = (s or {}).get("time_cfg") or {}
    out = {}
    for k, sec in DEFAULT_PHASE_DURATION.items():
        lo, hi = TIME_LIMITS[k]
        try:
            v = int(cfg.get(k, sec // 60))
        except (TypeError, ValueError):
            v = sec // 60
        out[k] = max(lo, min(hi, v))
    return out


def apply_time_cfg(s):
    """지금 수업의 단계별 시간을 앱 전체에 반영 (상태를 읽을 때마다)"""
    m = time_cfg_minutes(s)
    for k in PHASE_DURATION:
        PHASE_DURATION[k] = m[k] * 60


def phase_grace(phase):
    """기준시간 이후 자동 제출까지의 총 여유 (최초 주장 1분, 자기 단련 2분)"""
    return EXTENSION_SECONDS * PHASE_MAX_EXT.get(phase, MAX_EXTENSIONS)


MIN_LEN = {
    "claim": {"claim": 15, "reason": 25, "source": 2},
    "qa_message": 5,
    "final": {"text": 30},
    "selfcheck": {"text": 15},
}

PHASE_LABEL_KO = {
    "waiting": "대기중", "claim": "주장 펼치기", "prep": "응답 준비 중",
    "qa": "자유토론 중", "final": "자기 단련의 시간", "selfcheck": "자기 단련의 시간", "done": "완료",
}

# ---------------- 게임 레이어: 아이템 카탈로그 / 배틀 판정 ----------------
ITEM_CATALOG = {
    "double_claim": {"name": "이중 주장", "icon": "⚔️",
                      "desc": "주장 단계에서 보조 주장(핵심주장·근거)을 하나 더 쓸 수 있습니다."},
    "time_bank":    {"name": "타임뱅크", "icon": "⏳",
                      "desc": "지금 단계의 남은시간에 2분을 더합니다."},
    "extra_turn":   {"name": "질문 스틸", "icon": "🎯",
                      "desc": "자유토론에서 내 턴이 아니어도 1번 끼어들어 발언할 수 있습니다."},
    "hint":         {"name": "힌트 카드", "icon": "💡",
                      "desc": "논증을 더 강하게 만드는 힌트를 확인합니다."},
    "shield":       {"name": "쉴드", "icon": "🛡️",
                      "desc": "자유토론에서 상대의 다음 공격 1번을 무효화합니다(HP 안 깎임)."},
}
STARTING_ITEM_COUNT = 2

HINT_BANK = [
    "숫자(%, 건수, 연도)를 직접 언급하면 근거가 훨씬 더 설득력 있게 들립니다.",
    "상대 주장을 먼저 한 문장으로 인정한 뒤 반박하면, 감정적으로 안 보이면서 더 강하게 반박할 수 있습니다.",
    "'그런데 실제로는' 같은 표현으로 상대 근거의 허점을 짚으면 반박이 훨씬 선명해집니다.",
    "출처(기관명, 연도)를 짧게라도 언급하면 근거의 신뢰도가 크게 올라갑니다.",
    "상대 주장의 전제 자체가 맞는지 먼저 의심해보면 새로운 반박 지점이 보입니다.",
]

_CRIT_NUMBER_RE = re.compile(r"\d")
_CRIT_KEYWORDS = ("출처", "연구", "통계", "%", "조사", "논문", "보고서", "데이터", "자료")


def _is_crit_message(text):
    """공격 메시지에 숫자나 근거 관련 키워드가 있으면 '치명타'(효과 2배)로 판정한다.
    실시간 AI/동료 판정 없이, 가볍고 예측 가능한 규칙만 사용한다."""
    if not text:
        return False
    if _CRIT_NUMBER_RE.search(text):
        return True
    return any(k in text for k in _CRIT_KEYWORDS)


def hp_tier(hit_count):
    if hit_count >= 5:
        return {"label": "골드", "icon": "🥇"}
    if hit_count >= 2:
        return {"label": "실버", "icon": "🥈"}
    return {"label": "브론즈", "icon": "🥉"}


def apply_attack(room, attacker, text, base_dmg=10):
    """공격측(attacker)이 메시지를 보냈을 때, 상대 HP를 깎는다.
    방어측이 쉴드를 갖고 있으면 이번 공격은 무효화되고 쉴드가 소모된다."""
    defender = other_side(attacker)
    crit = _is_crit_message(text)
    dmg = base_dmg * 2 if crit else base_dmg
    shielded = room["shield_active"].get(defender, False)
    if shielded:
        room["shield_active"][defender] = False
        dmg = 0
    else:
        room["hp"][defender] = max(0, room["hp"].get(defender, 100) - dmg)
        if crit:
            room["hit_counts"][attacker] = room["hit_counts"].get(attacker, 0) + 1
    room["battle_log"].append({
        "attacker": attacker, "defender": defender, "dmg": dmg,
        "crit": crit, "shielded": shielded, "ts": now(),
    })
    room["battle_log"] = room["battle_log"][-30:]
SIDE_KO_PY = {"pro": "찬성팀", "con": "반대팀"}

AUTO_PLACEHOLDER = "(시간 초과로 제출되지 않았습니다)"
QA_TIMEOUT_TEXT = "(시간 초과, 응답 없음)"


def now():
    return time.time()


def empty_room():
    t = now()
    return {
        "pro": None, "con": None, "pro_name": None, "con_name": None,
        "phase": "waiting",
        "phase_entered_at": t,
        "claims": {"pro": None, "con": None},
        "prep_ready": {"pro": False, "con": False},
        "qa": {"messages": [], "current_turn": "pro", "turn_started_at": None,
                "timeout_counts": {"pro": 0, "con": 0}},
        "final": {"pro": None, "con": None},
        "selfcheck": {"pro": None, "con": None},
        "drafts": {"pro": {}, "con": {}},
        "forced": False,
        "members": {"pro": [], "con": []},   # [{"sid": "10203", "name": "김민준"}, ...]
        # ---- 게임 레이어 ----
        "avatar": {"pro": {"emoji": "😀", "color": "#ff6b6b"}, "con": {"emoji": "🙂", "color": "#4fd3ff"}},
        "hp": {"pro": 100, "con": 100},
        "hit_counts": {"pro": 0, "con": 0},  # "치명타"(근거 활용) 판정 받은 발언 수 -> 등급 표시용
        "items": {"pro": [], "con": []},           # 이번 판에 지급된 아이템 id 목록
        "items_used": {"pro": [], "con": []},      # 이미 사용한 아이템 id 목록
        "shield_active": {"pro": False, "con": False},   # 다음 피격 1회 무효화
        "extra_turn_active": {"pro": False, "con": False},  # 내 턴 아니어도 1회 발언 가능
        "hint_revealed": {"pro": False, "con": False},
        "hint_text": {"pro": None, "con": None},
        "double_claim_active": {"pro": False, "con": False},  # 이중 주장 사용 여부 (claim 단계에서만 유효)
        "battle_log": [],  # 최근 공격 이벤트 (연출 트리거용): {"attacker":..,"defender":..,"dmg":..,"crit":bool,"ts":..}
    }


def default_state():
    return {
        "topics": list(DEFAULT_TOPICS),
        "active_topic": None,
        "class_started_at": None,
        "class_duration_min": 50,
        "clients": {},
        "rooms": {str(i): empty_room() for i in range(1, MAX_ROOMS + 1)}, "room_count": DEFAULT_ROOMS,
        "showcase": {"open": False, "revealed": False, "votes": {}},
        "ai_report": {"status": "idle", "progress": "", "result": None, "error": None},
    }


IS_WINDOWS = os.name == "nt"
SHORTCUT_NAME = "토론 수업 앱"


def shortcut_target():
    """바탕화면 바로가기가 실행할 것: exe로 쓰면 그 exe(아이콘은 exe 안에), 파이썬으로 쓰면 토론앱_시작.bat"""
    if getattr(sys, "frozen", False):
        exe = os.path.abspath(sys.executable)
        return exe, os.path.dirname(exe), exe + ",0"
    bat = os.path.join(DATA_DIR, "토론앱_시작.bat")
    if not os.path.exists(bat):
        return None, None, None
    ico = os.path.join(RES_DIR, "app_icon.ico")
    return bat, DATA_DIR, (ico if os.path.exists(ico) else "")


def _ps_quote(v):
    """PowerShell 작은따옴표 문자열 (경로에 ' 가 있어도 안전)"""
    return "'" + str(v).replace("'", "''") + "'"


def shortcut_script(target, workdir, icon):
    """바로가기를 만드는 PowerShell 명령. 바탕화면 위치는 윈도우에게 물어봄(OneDrive로 옮겨진 바탕화면도 찾음)"""
    lines = ["$ErrorActionPreference = 'Stop'",
             "$desk = [Environment]::GetFolderPath('Desktop')",
             "if (-not $desk) { throw 'no desktop folder' }",
             f"$lnk = Join-Path $desk {_ps_quote(SHORTCUT_NAME + '.lnk')}",
             "$sh = New-Object -ComObject WScript.Shell",
             "$s = $sh.CreateShortcut($lnk)",
             f"$s.TargetPath = {_ps_quote(target)}",
             f"$s.WorkingDirectory = {_ps_quote(workdir)}"]
    if icon:
        lines.append(f"$s.IconLocation = {_ps_quote(icon)}")
    lines += [f"$s.Description = {_ps_quote('토론 수업 앱 - 두 번 누르면 켜져요')}",
              "$s.WindowStyle = 1",
              "$s.Save()",
              "[Console]::Out.Write([Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($lnk)))"]
    return "\r\n".join(lines)


def create_desktop_shortcut(force=False):
    """바탕화면에 '토론 수업 앱' 바로가기 만들기 (윈도우만).
    처음 켤 때 한 번 자동으로 만들고, 선생님이 지웠으면 저절로 다시 만들지 않음(교사 화면 버튼으로 다시). 앱 폴더를 옮기면 새 위치로 다시 만듦"""
    if not IS_WINDOWS:
        return {"ok": False, "error": "바탕화면 바로가기는 윈도우 컴퓨터에서만 만들 수 있어요."}
    target, workdir, icon = shortcut_target()
    if not target:
        return {"ok": False, "error": "실행 파일(DebateApp.exe 또는 토론앱_시작.bat)을 찾지 못했어요."}
    rec = load_config().get("desktop_shortcut") or {}
    if not force and rec.get("target") == target:
        return {"ok": True, "skipped": True, "path": rec.get("path", "")}
    enc = base64.b64encode(shortcut_script(target, workdir, icon).encode("utf-16-le")).decode("ascii")
    try:
        r = subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-EncodedCommand", enc],
                           capture_output=True, timeout=40, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    except Exception as e:
        return {"ok": False, "error": f"바로가기를 만들지 못했어요 ({type(e).__name__}). 교사 화면 ④에서 다시 시도해 주세요."}
    if r.returncode != 0:
        why = (r.stderr or b"").decode("utf-8", "replace").strip().splitlines()
        return {"ok": False, "error": "바로가기를 만들지 못했어요. " + (why[-1][:120] if why else "")}
    try:
        path = base64.b64decode((r.stdout or b"").strip()).decode("utf-8")
    except Exception:
        path = ""
    with CFG_LOCK:
        cfg = load_config()
        cfg["desktop_shortcut"] = {"target": target, "path": path, "at": now()}
        save_config({k: v for k, v in cfg.items() if k not in COMPUTED_CFG})
    return {"ok": True, "path": path}


def _auto_shortcut():
    """앱을 켤 때(윈도우) 바탕화면 바로가기를 한 번 만들어 둠 — 화면을 늦추지 않게 뒤에서"""
    try:
        r = create_desktop_shortcut(force=False)
    except Exception as e:
        r = {"ok": False, "error": str(e)}
    if r.get("ok") and not r.get("skipped"):
        print(f"  🖥  바탕화면에 '{SHORTCUT_NAME}' 바로가기를 만들었어요. 다음부터는 그걸 두 번 누르면 켜져요.")
    elif not r.get("ok"):
        print(f"  (바탕화면 바로가기: {r.get('error')} — 교사 화면 ④에서 다시 만들 수 있어요)")


def room_count(s):
    """이 수업에서 쓰는 조 수 (1~MAX_ROOMS)"""
    try:
        n = int(s.get("room_count") or DEFAULT_ROOMS)
    except (TypeError, ValueError):
        n = DEFAULT_ROOMS
    return max(1, min(MAX_ROOMS, n))


def room_in_use(s, rid):
    rid = str(rid)
    return rid.isdigit() and 1 <= int(rid) <= room_count(s)


def _fill_rooms(s):
    """예전 저장 파일(6개 조)도 그대로 열리게: 모자란 조는 빈 조로 채우고, 조 수가 없으면 기본값(입장한 조가 더 있으면 그만큼)"""
    changed = False
    for i in range(1, MAX_ROOMS + 1):
        if str(i) not in s["rooms"]:
            s["rooms"][str(i)] = empty_room(); changed = True
    for k in [k for k in s["rooms"] if not k.isdigit() or int(k) > MAX_ROOMS]:      # 예전 버전(최대 15조)의 빈 조는 정리
        r = s["rooms"][k]
        if not (r.get("pro") or r.get("con")):
            del s["rooms"][k]; changed = True
    if isinstance(s.get("room_count"), int) and s["room_count"] > MAX_ROOMS:
        s["room_count"] = MAX_ROOMS; changed = True
    if "room_count" not in s:
        used = [int(k) for k, r in s["rooms"].items() if k.isdigit() and (r.get("pro") or r.get("con"))]
        s["room_count"] = max(DEFAULT_ROOMS, min(MAX_ROOMS, max(used or [0]))); changed = True
    return changed


def load_state():
    with _MEM_LOCK:                               # 방금 바꾼 내용이 아직 디스크에 안 갔으면 메모리가 최신, 파일이 그대로면 메모리를 그대로 씀 (요청마다 파일을 열지 않음)
        txt = _MEM["text"]
        if txt is not None and (_MEM["dirty"] or (_MEM["sig"] is not None and _file_sig() == _MEM["sig"])):
            return json.loads(txt)
    if not os.path.exists(DATA_FILE):
        s = default_state()
        save_state(s)
        return s
    last_err = None
    for attempt in range(3):                      # 읽기 실패 시 바로 초기화하지 않고 잠시 뒤 다시 시도
        try:
            with open(DATA_FILE, "r", encoding="utf-8") as f:
                text = f.read()
            s = json.loads(text)
            if _LAST_SAVED["text"] is None:
                _LAST_SAVED["text"] = text
            with _MEM_LOCK:
                if not _MEM["dirty"]:
                    _MEM.update(text=text, sig=_file_sig())
            break
        except Exception as e:
            last_err = e
            time.sleep(0.05)
    else:
        # 그래도 못 읽으면: 고장 난 파일을 백업해 두고 새로 시작 (토론 기록을 조용히 지우지 않음)
        try:
            os.replace(DATA_FILE, DATA_FILE.replace(".json", f".broken-{int(now())}.json"))
        except Exception:
            pass
        s = default_state()
        save_state(s)
        return s
    if ("rooms" not in s or "1" not in s.get("rooms", {})
            or "prep_ready" not in s["rooms"]["1"]
            or "timeout_counts" not in s["rooms"]["1"].get("qa", {})):
        try:                                      # 아주 예전 형식의 파일도 지우기 전에 백업
            os.replace(DATA_FILE, DATA_FILE.replace(".json", f".old-{int(now())}.json"))
        except Exception:
            pass
        s = default_state()
        save_state(s)
    if _fill_rooms(s):
        save_state(s)
    apply_time_cfg(s)
    return s


ARCHIVE_DIR = os.path.join(DATA_DIR, "archives")   # 반별 수업 기록 보관 폴더
ARCH_LOCK = threading.Lock()


def _arch_path(aid):
    safe = re.sub(r"[^0-9A-Za-z가-힣_\-]", "", str(aid))
    return os.path.join(ARCHIVE_DIR, safe + ".json")


def _atomic_write_json(path, obj):
    tmp = f"{path}.{os.getpid()}.{threading.get_ident()}.tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, separators=(",", ":"))
        f.flush()
        try:
            os.fsync(f.fileno())
        except Exception:
            pass
    os.replace(tmp, path)


def src_load(aid):
    """'current'(지금 수업) 또는 보관된 반의 기록 읽기"""
    if aid in (None, "", "current"):
        with LOCK:
            return load_state()
    with ARCH_LOCK:
        with open(_arch_path(aid), encoding="utf-8") as f:
            return json.load(f)


def src_update(aid, fn):
    """기록을 고쳐 저장 (지금 수업은 data.json, 보관된 반은 archives/아이디.json)"""
    if aid in (None, "", "current"):
        with LOCK:
            st = load_state(); fn(st); save_state(st)
        return
    with ARCH_LOCK:
        p = _arch_path(aid)
        with open(p, encoding="utf-8") as f:
            st = json.load(f)
        fn(st)
        _atomic_write_json(p, st)


_LAST_SAVED = {"text": None}
TYPING = {}          # "입력 중" 신호: 메모리에만 (조|팀 → 마지막 입력 시각)


_MEM = {"text": None, "sig": None, "dirty": False}   # 지금 수업 상태(글자)와 파일 상태, 아직 디스크에 안 쓴 변경이 있는지
_MEM_LOCK = threading.Lock()
_FLUSH_LOCK = threading.Lock()
_WRITE_EVENT = threading.Event()
_FB_WAKE = threading.Event()       # 상태가 바뀌면(조가 최종 제출 등) 피드백 작업자를 바로 깨움 (예전엔 1.5초마다 확인)
_WRITER = {"started": False}
SAVE_DELAY = 0.25                  # 거의 같은 때 일어난 여러 변경을 모아서 한 번에 디스크에 씀 (초)


def _file_sig():
    try:
        st = os.stat(DATA_FILE)
        return (st.st_mtime_ns, st.st_size)
    except OSError:
        return None


def flush_state():
    """아직 디스크에 안 쓴 변경을 지금 씀 (뒤에서 쓰는 작업자·앱 종료 때 호출). 안전 저장: 임시 파일에 다 쓴 뒤 한 번에 교체 + fsync"""
    with _FLUSH_LOCK:
        with _MEM_LOCK:
            text, dirty = _MEM["text"], _MEM["dirty"]
        if not dirty or text is None:
            return True
        tmp = f"{DATA_FILE}.{os.getpid()}.{threading.get_ident()}.tmp"
        try:
            with open(tmp, "w", encoding="utf-8") as f:
                f.write(text)
                f.flush()
                try:
                    os.fsync(f.fileno())
                except Exception:
                    pass
            os.replace(tmp, DATA_FILE)
        except Exception:
            try:
                os.remove(tmp)
            except Exception:
                pass
            return False
        sig = _file_sig()
        with _MEM_LOCK:
            if _MEM["text"] == text:             # 쓰는 동안 또 바뀌었으면 dirty를 그대로 두어 다음에 다시 씀
                _MEM.update(dirty=False, sig=sig)
        _LAST_SAVED["text"] = text
        return True


def _state_writer():
    while True:
        _WRITE_EVENT.wait()
        time.sleep(SAVE_DELAY)
        _WRITE_EVENT.clear()
        if not flush_state():                    # 디스크 오류면 1초 뒤 다시 (변경 내용은 메모리에 그대로 있음)
            time.sleep(1.0)
            _WRITE_EVENT.set()


def save_state(s):
    """상태 저장. 메모리에는 바로 반영하고(다음 읽기부터 최신), 디스크에는 뒤에서 모아서 씀 — 요청이 느린 디스크(윈도우 백신 등)를 기다리며 다른 학생 화면까지 멈추는 일이 없게.
    내용이 바뀌지 않았으면 아무것도 안 함"""
    text = json.dumps(s, ensure_ascii=False, separators=(",", ":"))
    with _MEM_LOCK:
        if text == _MEM["text"] and (_MEM["dirty"] or os.path.exists(DATA_FILE)):
            return
        _MEM["text"] = text
        _MEM["dirty"] = True
    _LAST_SAVED["text"] = text
    _FB_WAKE.set()
    if not _WRITER["started"]:
        _WRITER["started"] = True
        threading.Thread(target=_state_writer, daemon=True).start()
    _WRITE_EVENT.set()


atexit.register(flush_state)               # 정상 종료 때 남은 변경 저장


def clean_text_check(*texts):
    joined = " ".join(t or "" for t in texts)
    for w in BAD_WORDS:
        if w in joined:
            return False, w
    return True, None


def member_label(m):
    """화면·작성자 기록·AI에 쓰는 이름 = 닉네임 (학번·이름은 교사 PC의 엑셀에서만 복원)"""
    nick = str(m.get("nick") or "").strip()
    return nick or f"{m.get('sid', '').strip()} {m.get('name', '').strip()}".strip()


def pii_map(state):
    """실명·학번 → 닉네임 (AI에 보내기 전에 토론 문장 속 실명·학번을 닉네임으로 바꾸는 데 사용)"""
    mp = {}
    for r in state["rooms"].values():
        for sd in ("pro", "con"):
            for m in (r.get("members") or {}).get(sd) or []:
                nick, nm, sid = str(m.get("nick") or "").strip(), str(m.get("name") or "").strip(), str(m.get("sid") or "").strip()
                if not nick:
                    continue
                if sid:
                    mp[sid] = nick
                if len(nm) >= 2:
                    mp[nm] = nick
                    if len(nm) >= 3 and len(nm[1:]) >= 2:
                        mp.setdefault(nm[1:], nick)          # '김가온' → '가온'처럼 이름만 부른 경우
    return mp


def scrub(text, mp):
    """AI 전송 직전: 실명·학번을 닉네임으로 (한 번에 바꿔서, 방금 넣은 닉네임 안쪽이 또 바뀌는 일이 없음).
    원문에 이미 쓰인 닉네임은 먼저 보호했다가 마지막에 되돌림"""
    if not mp:
        return text
    nicks = sorted(set(mp.values()), key=len, reverse=True)
    for i, n in enumerate(nicks):
        text = text.replace(n, f"\ue000{i}\ue001")
    pat = re.compile("|".join(re.escape(k) for k in sorted(mp, key=len, reverse=True)))
    text = pat.sub(lambda m: mp[m.group(0)], text)
    for i, n in enumerate(nicks):
        text = text.replace(f"\ue000{i}\ue001", n)
    return text


def writer_list(writer):
    """작성자 문자열 → 이름 목록 ('10203 김민준, 10207 이서연' → 두 명). 여러 명(모두같이) 선택 지원"""
    return [w.strip() for w in str(writer or "").split(",") if w.strip()]


def writer_has(writer, label):
    return label in writer_list(writer)


def seteuk_enabled(s):
    """개인별 생기부(발언마다 작성자 기록 · 생기부 만들기) 사용 여부 — 기본 켬"""
    return s.get("seteuk_enabled", True) is not False


def writer_ok(room, side, writer):
    """작성자는 입장할 때 등록한 팀원들 중에서 한 명 이상 (팀원 등록이 없는 예전 방식은 통과)"""
    members = (room.get("members") or {}).get(side) or []
    if not members:
        return True
    labels = [member_label(m) for m in members]
    ws = writer_list(writer)
    return bool(ws) and all(w in labels for w in ws)


def other_side(side):
    return "con" if side == "pro" else "pro"


def set_phase(room, phase):
    room["phase"] = phase
    room["phase_entered_at"] = now()
    if phase == "qa":
        qa_start(room)


def next_phase(phase):
    idx = PHASE_ORDER.index(phase)
    return PHASE_ORDER[idx + 1] if idx < len(PHASE_ORDER) - 1 else phase


# ---------------- 자동 시간초과 처리 ----------------

def force_submit_claim(room, side):
    if room["claims"][side] is not None:
        return
    warn = side_warning_level(room, side, "claim")
    draft = (room["drafts"].get(side) or {}).get("claim") or {}
    room["claims"][side] = {
        "claim": draft.get("claim") or AUTO_PLACEHOLDER,
        "reason": draft.get("reason") or AUTO_PLACEHOLDER,
        "source": draft.get("source") or "-",
        "writer": draft.get("writer") or room.get(f"{side}_name") or "",
        "submitted_at": now(), "auto": True, "warning_level": warn,
    }


def force_submit_final(room, side):
    if room["final"][side] is not None:
        return
    warn = side_warning_level(room, side, "final")
    draft = (room["drafts"].get(side) or {}).get("final") or {}
    room["final"][side] = {"text": draft.get("text") or AUTO_PLACEHOLDER, "submitted_at": now(),
                            "auto": True, "warning_level": warn, "writer": draft.get("writer") or ""}
    if room["selfcheck"][side] is None:
        room["selfcheck"][side] = {"text": draft.get("feedback") or AUTO_PLACEHOLDER, "submitted_at": now(),
                                    "auto": True, "warning_level": warn}


def force_submit_selfcheck(room, side):
    if room["selfcheck"][side] is not None:
        return
    warn = side_warning_level(room, side, "final")
    draft = (room["drafts"].get(side) or {}).get("final") or {}
    room["selfcheck"][side] = {"text": draft.get("feedback") or AUTO_PLACEHOLDER, "submitted_at": now(),
                                "auto": True, "warning_level": warn}


def qa_start(room):
    """자유토론에 들어갈 때 체스 시계 세팅 (처음이면 팀마다 9분, '이전 단계'로 돌아온 경우엔 최소 1분씩 보장)"""
    qa = room["qa"]
    qa.setdefault("timeout_counts", {"pro": 0, "con": 0})
    if "bank" not in qa or not qa.get("messages"):
        qa["bank"] = {"pro": qa_bank(), "con": qa_bank()}
        qa["current_turn"] = "pro"
    else:
        for sd in ("pro", "con"):
            qa["bank"][sd] = max(qa["bank"].get(sd, 0), 60)
        qa["current_turn"] = qa.get("current_turn") or "pro"
    qa["turn_started_at"] = now()


def qa_bank_left(room, side):
    """이 팀의 체스 시계에 남은 초 (지금 이 팀 차례면 진행 중인 시간까지 빼서)"""
    qa = room["qa"]
    bank = (qa.get("bank") or {}).get(side, qa_bank())
    if room["phase"] == "qa" and qa.get("current_turn") == side and qa.get("turn_started_at"):
        bank -= now() - qa["turn_started_at"]
    return max(0, bank)


def qa_turn_limit(room):
    """지금 턴이 쓸 수 있는 최대 길이 = min(3분, 이 팀 시계에 남은 시간)"""
    qa = room["qa"]
    return min(QA_TURN_CAP, (qa.get("bank") or {}).get(qa["current_turn"], qa_bank()))


def qa_end_turn(room, used):
    """턴 종료: 쓴 시간만큼 이 팀 시계에서 빼고, 시간이 남은 팀에게 차례를 넘김. 둘 다 0이면 다음 단계."""
    qa = room["qa"]
    cur = qa["current_turn"]
    qa.setdefault("bank", {"pro": qa_bank(), "con": qa_bank()})
    qa["bank"][cur] = max(0, qa["bank"][cur] - used)
    opp = other_side(cur)
    nxt = opp if qa["bank"][opp] > 0.5 else (cur if qa["bank"][cur] > 0.5 else None)
    if nxt is None:
        set_phase(room, "final")
        room["forced"] = True
        return
    qa["current_turn"] = nxt
    qa["turn_started_at"] = qa["turn_started_at"] + used


def tick_qa_turn(room):
    """자유토론(체스 시계): 한 턴이 최대 길이(3분 또는 남은 시계)를 다 쓰면
    그때까지 써 둔 초안을 자동 전송하고 차례를 넘긴다. 양 팀 시계가 모두 0이 되면 다음 단계로."""
    if room["phase"] != "qa":
        return
    qa = room["qa"]
    if "bank" not in qa:
        qa_start(room)
        return
    if qa["turn_started_at"] is None:
        qa["turn_started_at"] = now()
        return
    qa.setdefault("timeout_counts", {"pro": 0, "con": 0})
    guard = 0
    while room["phase"] == "qa" and now() - qa["turn_started_at"] >= qa_turn_limit(room) and guard < 50:
        side = qa["current_turn"]
        limit = qa_turn_limit(room)
        draft = (room["drafts"].get(side) or {}).get("qa") or {}
        text = (draft.get("text") or "").strip() or QA_TIMEOUT_TEXT
        qa["messages"].append({"side": side, "text": text, "auto": True, "ts": now(),
                               "writer": draft.get("writer") or ""})
        qa["timeout_counts"][side] = qa["timeout_counts"].get(side, 0) + 1
        room["drafts"].setdefault(side, {})["qa"] = {}
        qa_end_turn(room, limit)
        guard += 1


def qa_turn_status(room):
    """지금 턴의 남은 시간(최대 3분 또는 남은 시계)과 경고 여부 (30초 이하)"""
    qa = room["qa"]
    if qa.get("turn_started_at") is None or room["phase"] != "qa":
        return {"remaining": QA_TURN_CAP, "warning": False, "level": 0}
    rem = max(0, qa_turn_limit(room) - (now() - qa["turn_started_at"]))
    return {"remaining": rem, "warning": rem <= QA_TURN_WARN, "level": 1 if rem <= QA_TURN_WARN else 0}


def qa_clock(room):
    return {sd: qa_bank_left(room, sd) for sd in ("pro", "con")}


def advance_if_expired(room):
    if not room["pro"] or not room["con"]:
        return
    phase = room["phase"]

    if phase == "qa":
        tick_qa_turn(room)     # 체스 시계: 양 팀 시계가 모두 0이 되면 tick 안에서 다음 단계로
        return

    if phase == "prep":
        # 응답 준비(읽기)는 연장 없이 시간 되면 그냥 자동으로 다음 단계로 진행한다.
        dur = PHASE_DURATION["prep"]
        if now() - room["phase_entered_at"] >= dur:
            set_phase(room, "qa")
            room["qa"]["current_turn"] = "pro"
            room["qa"]["turn_started_at"] = now()
            room["forced"] = True
        return

    if phase in ("claim", "final"):
        # 제한시간 + 1분(경고 유예)까지 지나면, 아직 제출 안 한 쪽은 그때까지 쓴 초안을
        # 그대로 자동 제출시키고, 둘 다 채워지면 다음 단계로 자동 진행한다.
        dur = PHASE_DURATION[phase]
        elapsed = now() - room["phase_entered_at"]
        if elapsed < dur + phase_grace(phase):
            return
        store = {"claim": room["claims"], "final": room["final"]}[phase]
        forcer = {"claim": force_submit_claim, "final": force_submit_final}[phase]
        for side in ("pro", "con"):
            if store[side] is None:
                forcer(room, side)
                room["forced"] = True
        if store["pro"] is not None and store["con"] is not None:
            set_phase(room, next_phase(phase))
            room["forced"] = True
        return


def phase_warning_level(room, phase):
    """지금 이 방이 '지정한 단계' 제한시간을 얼마나 넘겼는지 (0~2, 2가 최대=자동제출 시점).
    현재 실제 단계가 phase와 다르면(예: 이미 지나간 단계) 0을 반환한다."""
    dur = PHASE_DURATION.get(phase)
    if dur is None or phase in ("qa", "prep") or room["phase"] != phase:
        return 0
    elapsed = now() - room["phase_entered_at"]
    mx = PHASE_MAX_EXT.get(phase, MAX_EXTENSIONS)
    return min(mx, _ext_level(elapsed, dur, mx))


def side_warning_level(room, side, phase=None):
    """이 side가 화면(또는 기록)에 남겨야 할 경고 단계. 이미 제출/준비완료 했다면 0."""
    phase = phase or room["phase"]
    if phase == "claim" and room["claims"][side] is not None:
        return 0
    if phase == "prep" and room["prep_ready"][side]:
        return 0
    if phase == "final" and room["final"][side] is not None:
        return 0
    if phase == "selfcheck" and room["selfcheck"][side] is not None:
        return 0
    return phase_warning_level(room, phase)


def compute_phase_remaining(room):
    """화면에 보여줄 '단계 남은시간'. 어느 단계든 강제 종료는 없지만,
    표시되는 남은시간 자체는 0에서 멈추고 다시 채워지지 않는다(반복 없음)."""
    phase = room["phase"]
    dur = PHASE_DURATION.get(phase)
    if dur is None:
        return None
    elapsed = now() - room["phase_entered_at"]
    if phase == "qa":
        c = qa_clock(room)
        return c["pro"] + c["con"]                # 자유토론 남은 시간 = 두 팀 시계의 합
    if phase in ("claim", "final"):
        return _window_remaining(elapsed, dur, PHASE_MAX_EXT.get(phase, MAX_EXTENSIONS))   # 추가시간 구간이면 그 1분의 남은 시간
    return max(0, dur - elapsed)


def force_class_timeout(room):
    """수업 전체 시간 종료 -> 남은 모든 것을 즉시 마무리하고 done으로."""
    if not room["pro"] or not room["con"]:
        return
    if room["phase"] == "done":
        return
    for side in ("pro", "con"):
        force_submit_claim(room, side)
    for side in ("pro", "con"):
        force_submit_final(room, side)
    for side in ("pro", "con"):
        force_submit_selfcheck(room, side)
    set_phase(room, "done")
    room["forced"] = True


def tick_room(room, class_expired):
    if class_expired:
        force_class_timeout(room)
    else:
        advance_if_expired(room)


def remaining_seconds_of(s):
    """수업 전체 남은 시간. 수업 시간을 정하지 않았으면(기본) 전체 제한 없음 → None (각 단계 타이머만 작동)"""
    if not s["class_started_at"] or s.get("class_duration_min") is None:
        return None
    return max(0, s["class_duration_min"] * 60 - (now() - s["class_started_at"]))


def elapsed_seconds_of(s):
    return int(now() - s["class_started_at"]) if s.get("class_started_at") else None


# ---------------- PDF ----------------

_PDF_FONT = "NotoKR"
_PDF_FONT_BOLD = "NotoKR-Bold"
_pdf_font_ready = False


def _ensure_pdf_font():
    global _pdf_font_ready
    if not _pdf_font_ready:
        base_dir = RES_DIR
        pdfmetrics.registerFont(TTFont(_PDF_FONT, os.path.join(base_dir, "fonts", "NotoSansKR-Regular.ttf")))
        pdfmetrics.registerFont(TTFont(_PDF_FONT_BOLD, os.path.join(base_dir, "fonts", "NotoSansKR-Bold.ttf")))
        pdfmetrics.registerFontFamily(_PDF_FONT, normal=_PDF_FONT, bold=_PDF_FONT_BOLD,
                                       italic=_PDF_FONT, boldItalic=_PDF_FONT_BOLD)
        _pdf_font_ready = True


def _pdf_styles():
    common = dict(fontName=_PDF_FONT, borderPadding=8)
    return {
        "title": ParagraphStyle("title", fontName=_PDF_FONT, fontSize=18, leading=24, spaceAfter=4,
                                 textColor=colors.HexColor("#1E2761")),
        "sub": ParagraphStyle("sub", fontName=_PDF_FONT, fontSize=10.5, leading=15, spaceAfter=10,
                               textColor=colors.HexColor("#555555")),
        "h2": ParagraphStyle("h2", fontName=_PDF_FONT, fontSize=12.5, leading=17, spaceBefore=14, spaceAfter=5,
                              textColor=colors.HexColor("#1E2761")),
        # 배경색 있는 문단(body/chat/final/selfcheck 계열)은 전부 Paragraph에 직접 backColor를 줘서 그린다.
        # (Table로 감싸면 문단 하나가 한 페이지보다 길 때 페이지를 못 넘어가고 통째로 실패하므로 Table은 쓰지 않는다.
        #  대신 뒤에 spaceAfter를 충분히 둬서, 같은 스타일 문단이 연달아 붙을 때 배경 박스가 겹쳐 보이는 것도 방지한다.)
        "claim_pro": ParagraphStyle("claim_pro", fontSize=10.5, leading=15.5, spaceAfter=4,
                                     backColor=colors.HexColor("#FDE2E2"), **common),
        "claim_con": ParagraphStyle("claim_con", fontSize=10.5, leading=15.5, spaceAfter=4,
                                     backColor=colors.HexColor("#E2E9FD"), **common),
        "final_pro": ParagraphStyle("final_pro", fontSize=10.5, leading=15.5, spaceAfter=4,
                                     backColor=colors.HexColor("#FDE2E2"), **common),
        "final_con": ParagraphStyle("final_con", fontSize=10.5, leading=15.5, spaceAfter=4,
                                     backColor=colors.HexColor("#E2E9FD"), **common),
        "selfcheck_pro": ParagraphStyle("selfcheck_pro", fontSize=10.5, leading=15.5, spaceAfter=4,
                                         backColor=colors.HexColor("#FDE2E2"), **common),
        "selfcheck_con": ParagraphStyle("selfcheck_con", fontSize=10.5, leading=15.5, spaceAfter=4,
                                         backColor=colors.HexColor("#E2E9FD"), **common),
        "chat_pro": ParagraphStyle("chat_pro", fontSize=10, leading=14.5, spaceAfter=6,
                                    backColor=colors.HexColor("#FDE2E2"), **common),
        "chat_con": ParagraphStyle("chat_con", fontSize=10, leading=14.5, spaceAfter=6,
                                    backColor=colors.HexColor("#E2E9FD"), **common),
        "chat_pro_auto": ParagraphStyle("chat_pro_auto", fontSize=10, leading=14.5, spaceAfter=6,
                                         backColor=colors.HexColor("#FDE2E2"),
                                         textColor=colors.HexColor("#B00020"), **common),
        "chat_con_auto": ParagraphStyle("chat_con_auto", fontSize=10, leading=14.5, spaceAfter=6,
                                         backColor=colors.HexColor("#E2E9FD"),
                                         textColor=colors.HexColor("#B00020"), **common),
        "empty": ParagraphStyle("empty", fontSize=10.5, leading=15.5, spaceAfter=4,
                                 backColor=colors.HexColor("#F4F6FB"), **common),
        "meta": ParagraphStyle("meta", fontName=_PDF_FONT, fontSize=8.5, leading=12, spaceAfter=6,
                                textColor=colors.grey),
    }


PDF_AVAIL_WIDTH = A4[0] - 36 * mm  # 좌우 여백 18mm씩 제외


def _pdf_safe_char(ch):
    """embedded된 한글 폰트(NotoSansKR 서브셋)에 실제로 들어있는 문자인지 확인.
    여기 없는 문자(이모지 등)를 그대로 넘기면 PDF 생성이 통째로 실패한다."""
    o = ord(ch)
    if o in (0x0A, 0x0D, 0x09, 0x20):
        return True
    if 0x21 <= o <= 0x7E:  # ASCII 출력 가능 문자
        return True
    if 0xAC00 <= o <= 0xD7A3:  # 한글 완성형
        return True
    if 0x3130 <= o <= 0x318F:  # 한글 자모
        return True
    if o in (0x00B7, 0x203B, 0x2192, 0x2190, 0x2194, 0x2605, 0x2606,
             0x2026, 0x2014, 0x2013, 0x2713, 0x26A0):  # · ※ → ← ↔ ★ ☆ … — – ✓ ⚠
        return True
    if 0x2460 <= o <= 0x2469:  # ①~⑩
        return True
    return False


def _pdf_safe(text):
    if not text:
        return ""
    return "".join(ch if _pdf_safe_char(ch) else "?" for ch in text)


def _esc(t):
    t = _pdf_safe(t or "")
    return t.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\n", "<br/>")


def generate_room_pdf_bytes(room_id, room, topic):
    _ensure_pdf_font()
    styles = _pdf_styles()
    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=A4, topMargin=18 * mm, bottomMargin=18 * mm,
                             leftMargin=18 * mm, rightMargin=18 * mm)
    story = [Paragraph(f"{room_id}조 토론 기록", styles["title"])]
    status = "완료" if room["phase"] == "done" else f"진행 중 ({PHASE_LABEL_KO.get(room['phase'], room['phase'])})"
    story.append(Paragraph(f"주제: {_esc(topic) or '(미지정)'}  ·  상태: {status}", styles["sub"]))
    story.append(Paragraph(f"찬성팀: {_esc(room.get('pro_name')) or '-'}  ·  반대팀: {_esc(room.get('con_name')) or '-'}",
                            styles["sub"]))
    story.append(HRFlowable(width="100%", color=colors.HexColor("#CADCFC"), thickness=1, spaceAfter=8))

    any_content = False

    def meta_line(writer, ts, auto, warning_level=0):
        bits = []
        if writer:
            bits.append(f"작성자: {_esc(writer)}")
        if ts:
            bits.append(time.strftime("%H:%M:%S", time.localtime(ts)))
        if auto:
            bits.append("⚠ 시간 초과 자동 처리")
        if warning_level:
            bits.append(f"⚠ 작성 중 시간 초과 경고 {warning_level}회")
        story.append(Paragraph(" · ".join(bits), styles["meta"]))

    for side in ("pro", "con"):
        c = room["claims"].get(side)
        if c:
            any_content = True
            st = styles["claim_pro"] if side == "pro" else styles["claim_con"]
            story.append(Paragraph(f"[주장] {SIDE_KO_PY[side]}", styles["h2"]))
            story.append(Paragraph(f"<b>핵심 주장:</b> {_esc(c.get('claim'))}", st))
            story.append(Paragraph(f"<b>근거:</b> {_esc(c.get('reason'))}", st))
            story.append(Paragraph(f"<b>출처:</b> {_esc(c.get('source'))}", st))
            if c.get("claim2"):
                story.append(Paragraph(f"<b>⚔ 보조 주장:</b> {_esc(c.get('claim2'))}", st))
                story.append(Paragraph(f"<b>⚔ 보조 근거:</b> {_esc(c.get('reason2'))}", st))
            meta_line(c.get("writer"), c.get("submitted_at"), c.get("auto"), c.get("warning_level", 0))

    qa_tc = room["qa"].get("timeout_counts", {}) or {}
    if room["qa"]["messages"] or qa_tc.get("pro") or qa_tc.get("con"):
        any_content = True
        story.append(Paragraph("자유토론", styles["h2"]))
        if qa_tc.get("pro") or qa_tc.get("con"):
            story.append(Paragraph(
                f"⚠ 자유토론 과정에서 시간 초과 경고 누적: 찬성 {qa_tc.get('pro', 0)}회 · 반대 {qa_tc.get('con', 0)}회",
                styles["meta"]))
        for i, m in enumerate(room["qa"]["messages"], 1):
            ts = time.strftime("%H:%M:%S", time.localtime(m["ts"]))
            key = f"chat_{m['side']}" + ("_auto" if m.get("auto") else "")
            st = styles.get(key, styles["chat_pro"])
            who = f" · ✍ {_esc(m.get('writer'))}" if m.get("writer") else ""
            story.append(Paragraph(f"<b>[{i}] {SIDE_KO_PY[m['side']]}{who}</b> ({ts}): {_esc(m['text'])}", st))

    for side in ("pro", "con"):
        f = room["final"].get(side)
        if f:
            any_content = True
            st = styles["final_pro"] if side == "pro" else styles["final_con"]
            story.append(Paragraph(f"[최종 의견] {SIDE_KO_PY[side]}", styles["h2"]))
            story.append(Paragraph(_esc(f.get("text")), st))
            meta_line(f.get("writer"), f.get("submitted_at"), f.get("auto"), f.get("warning_level", 0))

    if room["selfcheck"].get("pro") or room["selfcheck"].get("con"):
        story.append(Paragraph("자기 피드백", styles["h2"]))
        for side in ("pro", "con"):
            sc = room["selfcheck"].get(side)
            if sc:
                any_content = True
                st = styles["selfcheck_pro"] if side == "pro" else styles["selfcheck_con"]
                story.append(Paragraph(f"<b>{SIDE_KO_PY[side]}</b>: {_esc(sc.get('text'))}", st))
                meta_line(None, sc.get("submitted_at"), sc.get("auto"), sc.get("warning_level", 0))

    if not any_content:
        story.append(Paragraph("아직 제출된 내용이 없습니다.", styles["empty"]))

    story.append(Spacer(1, 14))
    story.append(Paragraph(f"생성 시각: {time.strftime('%Y-%m-%d %H:%M:%S')}", styles["meta"]))
    doc.build(story)
    return buf.getvalue()


# ---------------- pages ----------------

@app.route("/")
def index():
    return render_template("index.html")


@app.route("/room")
def room_page():
    return render_template("room.html")


@app.route("/teacher")
def teacher_page():
    return render_template("teacher.html")


# ---------------- student APIs ----------------

@app.route("/api/topics", methods=["GET"])
def api_topics():
    with LOCK:
        s = load_state()
    return jsonify({"topics": s["topics"], "active_topic": s["active_topic"]})


# ===== 교사 화면 잠금: /teacher 와 /api/teacher/* 는 이 컴퓨터에서만 열림 (같은 와이파이의 학생 기기는 403) =====
TEACHER_ANYWHERE = os.environ.get("DEBATE_TEACHER_ANYWHERE") == "1"        # 태블릿 등 다른 기기에서 꼭 써야 할 때만 (권장 안 함)
_LOCAL = {"addrs": None}


def local_addrs(refresh=False):
    """이 컴퓨터가 가진 주소들 (127.0.0.1 + 와이파이/랜 IP). 선생님이 IP 주소로 접속해도 이 컴퓨터로 인식하기 위함"""
    if _LOCAL["addrs"] is None or refresh:
        a = {"127.0.0.1", "::1"}
        try:
            a.update(socket.gethostbyname_ex(socket.gethostname())[2])
        except Exception:
            pass
        try:
            u = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            u.connect(("10.255.255.255", 1))          # 실제로 보내지 않음: 내 대표 IP를 알아내기만 함
            a.add(u.getsockname()[0]); u.close()
        except Exception:
            pass
        _LOCAL["addrs"] = a
    return _LOCAL["addrs"]


INTERNET_MODE = False        # main()이 정함. True면 학생은 인터넷(Cloudflare 터널) 주소로 접속 · 닉네임만 입력 · 접속 코드 필요
# 터널·프록시를 거친 요청에는 이런 머리글이 붙음. 터널은 요청을 이 컴퓨터(127.0.0.1)에서 온 것처럼 전달하기 때문에
# 주소만 보면 학생 요청도 '이 컴퓨터'로 보임 → 머리글과 접속 주소(Host)까지 확인해야 교사 화면이 안 열림
_PROXY_HEADERS = ("X-Forwarded-For", "X-Forwarded-Host", "X-Forwarded-Proto", "X-Real-Ip", "Forwarded", "Cf-Connecting-Ip",
                  "Cf-Ray", "Cf-Visitor", "Cf-Ipcountry", "Cdn-Loop", "True-Client-Ip", "Via")


def _host_only(h):
    """'127.0.0.1:5000' → '127.0.0.1', '[::1]:5000' → '::1'"""
    h = (h or "").strip().lower()
    if h.startswith("["):
        return h[1:].split("]")[0]
    return h.rsplit(":", 1)[0] if h.count(":") == 1 else h


def _local_hosts():
    h = {"127.0.0.1", "localhost", "::1", socket.gethostname().lower()} | {x.lower() for x in local_addrs()}
    return h


@app.before_request
def guard_teacher():
    p = request.path
    if TEACHER_ANYWHERE or not (p == "/teacher" or p.startswith("/api/teacher/")):
        return None
    deny = lambda why: Response(f"교사 화면은 선생님 컴퓨터에서만 열 수 있어요. ({why}) 선생님 컴퓨터에서 http://127.0.0.1:5000/teacher 로 접속하세요.",
                                status=403, mimetype="text/plain; charset=utf-8")
    if any(h in request.headers for h in _PROXY_HEADERS):
        return deny("인터넷 중계를 거친 접속")
    host = _host_only(request.host)
    if host and host not in _local_hosts():
        return deny("다른 주소로 접속")
    ra = (request.remote_addr or "").replace("::ffff:", "")
    if ra in local_addrs() or ra in local_addrs(refresh=True):
        return None
    return deny("학생 기기")


# =====================================================================================
#  학번·이름 암호화 (인터넷 모드): 학생 브라우저가 이 컴퓨터의 '공개 열쇠'로 잠가서 보내고,
#  '비밀 열쇠'는 이 컴퓨터(config.json)에만 있음 → 중계 서버(Cloudflare)에는 읽을 수 없는 암호문만 지나감
#  표준 RSA-OAEP(SHA-256). 브라우저의 Web Crypto와 호환. 추가 프로그램 설치 필요 없음
# =====================================================================================
ENC = {"key": None}
_ENC_LOCK = threading.Lock()
_SMALL_PRIMES = [p for p in range(3, 2000) if all(p % q for q in range(2, int(p ** 0.5) + 1))]


def _is_probable_prime(n, rounds=24):
    for p in _SMALL_PRIMES:
        if n == p:
            return True
        if n % p == 0:
            return False
    d, r = n - 1, 0
    while d % 2 == 0:
        d //= 2; r += 1
    for _ in range(rounds):
        a = secrets.randbelow(n - 3) + 2
        x = pow(a, d, n)
        if x in (1, n - 1):
            continue
        for _ in range(r - 1):
            x = x * x % n
            if x == n - 1:
                break
        else:
            return False
    return True


def _gen_prime(bits):
    while True:
        c = secrets.randbits(bits) | (1 << (bits - 1)) | (1 << (bits - 2)) | 1
        if _is_probable_prime(c):
            return c


def rsa_generate(bits=2048):
    e = 65537
    while True:
        p, q = _gen_prime(bits // 2), _gen_prime(bits // 2)
        if p == q:
            continue
        phi = (p - 1) * (q - 1)
        if phi % e == 0 or (p * q).bit_length() != bits:
            continue
        return {"n": p * q, "e": e, "d": pow(e, -1, phi)}


def _mgf1(seed, length):
    out, counter = b"", 0
    while len(out) < length:
        out += hashlib.sha256(seed + counter.to_bytes(4, "big")).digest(); counter += 1
    return out[:length]


def rsa_oaep_decrypt(key, ct):
    """RSA-OAEP(SHA-256, 빈 라벨) 풀기. 잘못된 암호문이면 ValueError"""
    k = (key["n"].bit_length() + 7) // 8
    if len(ct) != k:
        raise ValueError("길이 오류")
    c = int.from_bytes(ct, "big")
    if c >= key["n"]:
        raise ValueError("범위 오류")
    em = pow(c, key["d"], key["n"]).to_bytes(k, "big")
    hlen = 32
    masked_seed, masked_db = em[1:1 + hlen], em[1 + hlen:]
    seed = bytes(a ^ b for a, b in zip(masked_seed, _mgf1(masked_db, hlen)))
    db = bytes(a ^ b for a, b in zip(masked_db, _mgf1(seed, k - hlen - 1)))
    if em[0] != 0 or not hmac.compare_digest(db[:hlen], hashlib.sha256(b"").digest()):
        raise ValueError("형식 오류")
    rest = db[hlen:]
    i = rest.find(b"\x01")
    if i < 0 or any(rest[:i]):
        raise ValueError("형식 오류")
    return rest[i + 1:]


def rsa_oaep_encrypt(n, e, msg):
    """(자동 검사용) 브라우저와 같은 방식으로 잠그기"""
    k = (n.bit_length() + 7) // 8
    hlen = 32
    db = hashlib.sha256(b"").digest() + b"\x00" * (k - len(msg) - 2 * hlen - 2) + b"\x01" + msg
    seed = secrets.token_bytes(hlen)
    masked_db = bytes(a ^ b for a, b in zip(db, _mgf1(seed, k - hlen - 1)))
    masked_seed = bytes(a ^ b for a, b in zip(seed, _mgf1(masked_db, hlen)))
    return pow(int.from_bytes(b"\x00" + masked_seed + masked_db, "big"), e, n).to_bytes(k, "big")


def _b64u(b):
    return base64.urlsafe_b64encode(b).rstrip(b"=").decode("ascii")


def ensure_enc_key():
    """이 컴퓨터의 열쇠 (처음 한 번 만들어 config.json에 저장 — 앱을 껐다 켜도 같은 열쇠라 수업 중 재시작해도 문제없음)"""
    with _ENC_LOCK:
        if ENC["key"]:
            return ENC["key"]
        k = _read_config_raw().get("enc_key") or {}
        try:
            key = {"n": int(k["n"], 16), "e": int(k["e"]), "d": int(k["d"], 16)}
        except Exception:
            new = rsa_generate()                                   # 느린 PC에서는 몇 초 걸릴 수 있음 (이 동안 선생님이 설정을 저장할 수 있음)
            with CFG_LOCK:
                raw = _read_config_raw()                           # ← 지금 파일을 새로 읽어서 (그 사이 저장된 동의·AI 키 보존)
                k = raw.get("enc_key") or {}
                try:
                    key = {"n": int(k["n"], 16), "e": int(k["e"]), "d": int(k["d"], 16)}
                except Exception:
                    key = new
                    raw["enc_key"] = {"n": format(key["n"], "x"), "e": key["e"], "d": format(key["d"], "x")}
                    try:
                        tmp = CONFIG_FILE + ".tmp"
                        with open(tmp, "w", encoding="utf-8") as f:
                            json.dump(raw, f, ensure_ascii=False, indent=2)
                        os.replace(tmp, CONFIG_FILE)
                    except Exception:
                        pass
        ENC["key"] = key
        return key


def enc_public_jwk():
    key = ENC["key"]
    if not key:
        return None
    k = (key["n"].bit_length() + 7) // 8
    return {"kty": "RSA", "n": _b64u(key["n"].to_bytes(k, "big")), "e": _b64u(key["e"].to_bytes(3, "big")), "alg": "RSA-OAEP-256"}


def decrypt_member(enc_b64):
    """학생 기기가 잠근 {"sid","name"} 풀기 → (학번, 이름)"""
    key = ENC["key"] or ensure_enc_key()
    ct = base64.b64decode(str(enc_b64), validate=True)
    d = json.loads(rsa_oaep_decrypt(key, ct).decode("utf-8"))
    return str(d.get("sid") or "").strip(), str(d.get("name") or "").strip()


_CODE_FAILS = {}


def client_ip():
    """접속한 기기의 주소 (터널을 거치면 Cloudflare가 붙여 주는 값, 학생이 위조할 수 없음)"""
    return (request.headers.get("Cf-Connecting-Ip") or request.remote_addr or "?").strip()


def ensure_join_code(s):
    """인터넷 모드: 수업마다 새로 만드는 4자리 접속 코드 (짧은 주소가 추측돼도 코드 없이는 입장 불가). 바뀌었으면 True"""
    if INTERNET_MODE and not s.get("join_code"):
        s["join_code"] = f"{random.randint(0, 9999):04d}"
        return True
    return False


def check_join_code(s, data):
    """인터넷 모드에서 입장·이어서 입장 때 접속 코드 확인. 문제 있으면 응답을, 괜찮으면 None"""
    if not INTERNET_MODE:
        return None
    ip, t = client_ip(), now()
    fails = [x for x in _CODE_FAILS.get(ip, []) if t - x < 300]
    if len(fails) >= 60:                                       # 같은 학교는 공용 주소를 쓸 수 있어 넉넉하게
        return jsonify({"ok": False, "locked": True, "error": "접속 코드를 너무 많이 틀렸어요. 5분 뒤에 다시 해 보세요."})
    if ensure_join_code(s):
        save_state(s)
    given = str(data.get("code") or "").strip().encode("utf-8")
    if not hmac.compare_digest(given, s["join_code"].encode("utf-8")):
        fails.append(t); _CODE_FAILS[ip] = fails
        return jsonify({"ok": False, "bad_code": True, "error": "접속 코드가 맞지 않아요. 선생님이 알려 준 4자리 숫자를 확인하세요."})
    return None


@app.route("/api/config", methods=["GET"])
def api_config():
    """입장 화면이 모양을 정할 때 쓰는 정보 (조 수 · 인터넷 모드면 닉네임만 입력 + 접속 코드)"""
    roster = False
    with LOCK:
        s = load_state()
        rooms = {"room_count": room_count(s), "max_rooms": MAX_ROOMS}
        if INTERNET_MODE:
            if ensure_join_code(s):
                save_state(s)
            roster = bool(s.get("roster"))
    if not INTERNET_MODE:
        return jsonify({"internet": False, "nick_only": False, "need_code": False, "enc": None, **rooms})
    if roster:                                                   # 선생님이 명단을 등록 → 학생은 닉네임만 (학번·이름이 아예 안 오감)
        return jsonify({"internet": True, "nick_only": True, "need_code": True, "enc": None, **rooms})
    if not ENC["key"]:
        threading.Thread(target=ensure_enc_key, daemon=True).start()
        return jsonify({"internet": True, "nick_only": False, "need_code": True, "enc": None, "enc_pending": True, **rooms})
    return jsonify({"internet": True, "nick_only": False, "need_code": True, "enc": enc_public_jwk(), **rooms})


@app.route("/api/join", methods=["POST"])
def api_join():
    data = request.json
    client_id = data.get("client_id")
    room_id = str(data.get("room"))
    side = data.get("side")
    members = []
    for m in (data.get("members") or [])[:3]:
        sid, nm, nick = str(m.get("sid") or "").strip(), str(m.get("name") or "").strip(), str(m.get("nick") or "").strip()
        if sid or nm or nick:
            if INTERNET_MODE:                          # 인터넷 모드: 평문 학번·이름은 무조건 버림. 학생 기기에서 잠근 암호문만 받아 여기서 풂
                sid = nm = ""
                if not nick:
                    return jsonify({"ok": False, "error": "팀원마다 닉네임을 입력하세요."})
                if m.get("enc"):
                    try:
                        sid, nm = decrypt_member(m["enc"])
                    except Exception:
                        return jsonify({"ok": False, "bad_enc": True,
                                        "error": "학번·이름을 안전하게 읽지 못했어요. 이 화면을 새로고침(F5)한 뒤 다시 입장해 주세요."})
                    if not re.fullmatch(r"\d{4,6}", sid) or not (1 <= len(nm) <= 20):
                        return jsonify({"ok": False, "error": "학번(숫자 5자리)과 이름을 확인해 주세요."})
            elif not (sid and nm and nick):
                return jsonify({"ok": False, "error": "팀원마다 학번·이름·닉네임을 모두 입력하세요."})
            if not INTERNET_MODE and not re.fullmatch(r"\d{4,6}", sid):
                return jsonify({"ok": False, "error": f"학번은 숫자 5자리로 입력하세요. ('{sid}')"})
            if not re.fullmatch(r"[0-9A-Za-z가-힣_]{1,10}", nick):
                return jsonify({"ok": False, "error": f"닉네임은 띄어쓰기·기호 없이 10자 이내로 정하세요. ('{nick}')"})
            if nm and (nick == nm or (len(nm) >= 3 and nick == nm[1:])):
                return jsonify({"ok": False, "error": f"닉네임에 실명을 쓰면 안 돼요. ('{nick}') 다른 닉네임으로 정하세요."})
            ok_, bad_ = clean_text_check(nick)
            if not ok_:
                return jsonify({"ok": False, "error": f"닉네임에 쓸 수 없는 표현이 있어요. ('{bad_}')"})
            members.append({"sid": sid[:6], "name": nm[:20], "nick": nick})
    if data.get("members") is not None and not members:
        return jsonify({"ok": False, "error": "팀원의 학번·이름·닉네임을 한 명 이상 입력하세요."})
    filled = [m["sid"] for m in members if m["sid"]]
    if len({m["nick"] for m in members}) < len(members) or len(set(filled)) < len(filled):
        return jsonify({"ok": False, "error": "우리 팀 안에 같은 학번이나 같은 닉네임이 있어요."})
    name = ", ".join(member_label(m) for m in members) or (data.get("name") or "").strip() or ("찬성팀" if side == "pro" else "반대팀")
    avatar = data.get("avatar") or {}
    emoji = (avatar.get("emoji") or "").strip()
    species = (data.get("species") or "").strip()
    color = (avatar.get("color") or "").strip()

    with LOCK:
        s = load_state()
        if room_id not in s["rooms"] or not room_in_use(s, room_id):
            return jsonify({"ok": False, "error": f"이 수업은 {room_count(s)}개 조로 진행해요. 1~{room_count(s)}조 중에서 골라 주세요."})
        room = s["rooms"][room_id]
        bad = check_join_code(s, data)
        if bad:
            return bad
        roster = s.get("roster") or []
        if INTERNET_MODE and roster:                                # 학생은 닉네임만 → 선생님이 등록한 명단에서 학번·이름 연결
            by = {r["nick"]: r for r in roster}
            by_ci = {}
            for r in roster:
                by_ci.setdefault(r["nick"].lower(), []).append(r)
            used = {}
            for rid2, r2 in s["rooms"].items():
                for sd2 in ("pro", "con"):
                    if (rid2, sd2) == (room_id, side):
                        continue
                    for m2 in (r2.get("members") or {}).get(sd2) or []:
                        used[m2.get("nick")] = r2.get(sd2)
            for m in members:
                hit = by.get(m["nick"])
                if not hit:                                         # 대소문자만 다른 경우(예: Fox/fox)는 같은 닉네임으로 봄
                    cands = by_ci.get(m["nick"].lower()) or []
                    hit = cands[0] if len(cands) == 1 else None
                if not hit:
                    return jsonify({"ok": False, "error": f"명단에 없는 닉네임이에요 ('{m['nick']}'). 선생님이 정해 준 닉네임을 그대로 입력했는지 확인하세요."})
                m["nick"], m["sid"], m["name"] = hit["nick"], hit["sid"], hit["name"]
                if used.get(m["nick"]) not in (None, client_id):
                    return jsonify({"ok": False, "error": f"'{m['nick']}' 닉네임은 이미 다른 팀에서 쓰고 있어요. 내 닉네임이 맞는지 확인하세요."})
            if len({m["nick"] for m in members}) < len(members):
                return jsonify({"ok": False, "error": "우리 팀 안에 같은 닉네임이 있어요."})
            name = ", ".join(member_label(m) for m in members)

        occupant = room[side]
        if occupant is not None and occupant != client_id:
            return jsonify({
                "ok": False,
                "error": f"이미 {room_id}조 {'찬성' if side=='pro' else '반대'}팀 자리가 사용 중입니다.",
                "occupied": True,  # 프론트에서 "이어서 입장하기" 버튼을 보여줄지 판단하는 신호
            })

        other_members = (room.get("members") or {}).get(other_side(side)) or []
        clash = {m["nick"] for m in members} & {m.get("nick") for m in other_members}
        if clash:
            return jsonify({"ok": False, "error": f"같은 조 상대 팀에 같은 닉네임이 있어요: {', '.join(clash)} — 다른 닉네임으로 바꿔 주세요."})
        # 다른 조와 학번이 겹쳐도 입장은 막지 않음 (오타 때문에 진짜 그 학생이 못 들어오는 일 방지) → 교사 명단 확인에서 빨간색 표시
        room[side] = client_id
        room[f"{side}_name"] = name
        room.setdefault("members", {"pro": [], "con": []})[side] = members
        if species in ("alpaca", "hippo", "lion", "leopard", "frog"):
            room["avatar"][side]["species"] = species
        if emoji:
            room["avatar"][side]["emoji"] = emoji
        if color:
            room["avatar"][side]["color"] = color
        s["clients"][client_id] = {"room": room_id, "side": side, "name": name}

        if room["pro"] and room["con"] and room["phase"] == "waiting" and s.get("class_started_at"):
            start_room_debate(room)           # 교사가 수업을 시작한 뒤에만 토론(최초 주장) 시작

        save_state(s)
        return jsonify({"ok": True, "room": room_id, "side": side})


@app.route("/api/rejoin", methods=["POST"])
def api_rejoin():
    """와이파이 끊김/기기 변경 등으로 원래 client_id를 잃어버린 학생이,
    이미 진행 중인 자리를 자기 것으로 다시 가져와서(=이어서 입장) 이어할 수 있게 한다.
    토론 내용(주장/자유토론/최종의견/자기피드백)은 client_id가 아니라 조·찬반에 저장되므로
    자리만 새 client_id로 바꿔주면 진행 상황이 그대로 유지된다."""
    data = request.json
    client_id = data.get("client_id")
    room_id = str(data.get("room"))
    side = data.get("side")

    with LOCK:
        s = load_state()
        if room_id not in s["rooms"]:
            return jsonify({"ok": False, "error": "존재하지 않는 조입니다."})
        room = s["rooms"][room_id]
        if side not in ("pro", "con"):
            return jsonify({"ok": False, "error": "잘못된 요청입니다."})
        bad = check_join_code(s, data)
        if bad:
            return bad

        old_client = room[side]
        # 원래 그 자리를 차지하고 있던 client_id 매핑은 지워서, 옛 기기가 계속 같은 자리로
        # 동시에 제출하는 충돌이 나지 않게 한다.
        if old_client and old_client in s["clients"] and old_client != client_id:
            del s["clients"][old_client]

        name = room.get(f"{side}_name") or ("찬성팀" if side == "pro" else "반대팀")
        room[side] = client_id
        s["clients"][client_id] = {"room": room_id, "side": side, "name": name}
        save_state(s)
        return jsonify({"ok": True, "room": room_id, "side": side})


@app.route("/api/state", methods=["GET"])
def api_state():
    kick_feedback()
    client_id = request.args.get("client_id")
    with LOCK:
        s = load_state()
        cinfo = s["clients"].get(client_id)
        remaining = remaining_seconds_of(s)

        resp = {
            "active_topic": s["active_topic"],
            "class_started_at": s["class_started_at"],
            "class_duration_min": s["class_duration_min"],
            "remaining_seconds": remaining,
            "elapsed_seconds": elapsed_seconds_of(s),
        }
        if not cinfo:
            resp["joined"] = False
            return jsonify(resp)

        room_id = cinfo["room"]
        side = cinfo["side"]
        room = s["rooms"][room_id]

        tick_room(room, remaining is not None and remaining <= 0)
        save_state(s)

        resp["joined"] = True
        resp["room"] = room_id
        resp["side"] = side
        resp["room_state"] = room
        resp["my_name"] = room.get(f"{side}_name")
        resp["opp_name"] = room.get(f"{other_side(side)}_name")
        resp["min_len"] = MIN_LEN
        resp["phase_duration"] = PHASE_DURATION
        resp["item_catalog"] = ITEM_CATALOG
        resp["my_tier"] = hp_tier(room["hit_counts"].get(side, 0))
        resp["opp_tier"] = hp_tier(room["hit_counts"].get(other_side(side), 0))
        resp["server_time"] = now()
        resp["phase_remaining_seconds"] = compute_phase_remaining(room)
        resp["my_warning_level"] = side_warning_level(room, side)
        resp["opp_warning_level"] = side_warning_level(room, other_side(side))
        if room["phase"] == "qa" and room["qa"]["turn_started_at"]:
            qts = qa_turn_status(room)
            resp["qa_turn_remaining_seconds"] = qts["remaining"]
            resp["qa_turn_warning"] = qts["warning"]
        else:
            resp["qa_turn_remaining_seconds"] = None
            resp["qa_turn_warning"] = False
        # 상대가 지금 실제로 타이핑 중인지 (최근 3.5초 안에 입력 신호가 있었는지)
        resp["opp_typing"] = room["phase"] == "qa" and (now() - TYPING.get(f"{room_id}|{other_side(side)}", 0)) < 3.5
        resp["members"] = [{"nick": member_label(m)} for m in ((room.get("members") or {}).get(side) or [])]   # 학번·이름은 학생 화면으로 보내지 않음
        resp["paste_block"] = bool(s.get("paste_block"))
        resp["seteuk_enabled"] = seteuk_enabled(s)
        resp["assign_mode"] = s.get("assign_mode")
        resp["my_random"] = bool(cinfo.get("random"))      # 이 학생이 랜덤 배정으로 자리가 정해졌는지 (안내는 이 학생에게만)
        # 학생에게 보내는 조 정보: 상대 팀 초안(블라인드 규칙)과 상대 팀 실명·학번은 빼고, 닉네임만
        rs = dict(room)
        rs["drafts"] = {side: (room.get("drafts") or {}).get(side) or {}}
        rs["members"] = {sd: [{"nick": member_label(m)} for m in ((room.get("members") or {}).get(sd) or [])] for sd in ("pro", "con")}
        rs["pro_name"] = ", ".join(member_label(m) for m in rs["members"]["pro"]) or room.get("pro_name")
        rs["con_name"] = ", ".join(member_label(m) for m in rs["members"]["con"]) or room.get("con_name")
        resp["room_state"] = rs
        resp["qa_turn_level"] = qa_turn_status(room).get("level", 0) if room["phase"] == "qa" else 0
        resp["qa_clock"] = qa_clock(room) if room["phase"] == "qa" else None
        resp["qa_bank_total"] = qa_bank()
        resp["qa_turn_cap"] = QA_TURN_CAP
        resp["phase_max_ext"] = PHASE_MAX_EXT.get(room["phase"], 0)
        resp["phase_window_total"] = (EXTENSION_SECONDS if resp["my_warning_level"] else PHASE_DURATION.get(room["phase"])) \
            if room["phase"] in ("claim", "final") else PHASE_DURATION.get(room["phase"])
        resp["showcase_open"] = showcase_is_open(s)
        return jsonify(resp)


@app.route("/api/typing", methods=["POST"])
def api_typing():
    """자유토론 중 입력창에 글자를 치고 있다는 신호 (상대 화면에 '입력 중이에요!' 표시용).
    몇 초만 의미 있는 값이라 파일에 저장하지 않고 메모리에만 둠 (타이핑할 때마다 디스크 쓰기 방지)"""
    data = request.json or {}
    with LOCK:
        s = load_state()
        cinfo = s["clients"].get(data.get("client_id"))
        rm = s["rooms"][cinfo["room"]] if cinfo else None
        # 내 차례일 때만 기록: 상대 차례에 미리 써 두는 것은 상대 화면에 '입력 중'으로 보이지 않게
        if rm and rm["phase"] == "qa" and (rm["qa"]["current_turn"] == cinfo["side"] or (rm.get("extra_turn_active") or {}).get(cinfo["side"])):
            TYPING[f"{cinfo['room']}|{cinfo['side']}"] = now()
    return jsonify({"ok": True})


@app.route("/api/draft/save", methods=["POST"])
def api_draft_save():
    data = request.json
    client_id = data.get("client_id")
    phase = data.get("phase")
    fields = data.get("fields", {})
    with LOCK:
        s = load_state()
        cinfo = s["clients"].get(client_id)
        if not cinfo:
            return jsonify({"ok": False})
        room = s["rooms"][cinfo["room"]]
        side = cinfo["side"]
        room["drafts"].setdefault(side, {})
        room["drafts"][side][phase] = fields
        save_state(s)
        return jsonify({"ok": True})


@app.route("/api/claim/submit", methods=["POST"])
def api_claim_submit():
    data = request.json
    client_id = data.get("client_id")
    claim_text = (data.get("claim") or "").strip()
    reason_text = (data.get("reason") or "").strip()
    source_text = (data.get("source") or "").strip()
    writer = (data.get("writer") or "").strip()
    claim2_text = (data.get("claim2") or "").strip()
    reason2_text = (data.get("reason2") or "").strip()

    with LOCK:
        s = load_state()
        cinfo = s["clients"].get(client_id)
        if not cinfo:
            return jsonify({"ok": False, "error": "참여 정보가 없습니다."})
        room = s["rooms"][cinfo["room"]]
        side = cinfo["side"]

        if room["phase"] != "claim":
            return jsonify({"ok": False, "error": "지금은 주장 작성 단계가 아닙니다."})
        if room["claims"][side] is not None:
            return jsonify({"ok": False, "error": "이미 제출했습니다. 상대 팀을 기다려주세요."})
        if not seteuk_enabled(s):                       # 개인별 생기부를 끄면 발언마다 작성자를 고르지 않음
            writer = ""
        elif not writer:
            return jsonify({"ok": False, "error": "✍ 이번 턴 작성자를 선택하세요."})
        if writer and not writer_ok(room, side, writer):
            return jsonify({"ok": False, "error": "작성자는 우리 팀원 중에서 선택하세요."})

        ml = MIN_LEN["claim"]
        if len(claim_text.replace(" ", "")) < ml["claim"]:
            return jsonify({"ok": False, "error": f"핵심 주장이 너무 짧습니다. 공백 제외 최소 {ml['claim']}자 이상."})
        if len(reason_text.replace(" ", "")) < ml["reason"]:
            return jsonify({"ok": False, "error": f"근거가 너무 짧습니다. 공백 제외 최소 {ml['reason']}자 이상."})
        if len(source_text.replace(" ", "")) < ml["source"]:
            return jsonify({"ok": False, "error": "출처를 입력하세요."})

        use_double = room["double_claim_active"].get(side, False)
        if use_double and (claim2_text or reason2_text):
            if len(claim2_text.replace(" ", "")) < ml["claim"]:
                return jsonify({"ok": False, "error": f"보조 주장이 너무 짧습니다. 공백 제외 최소 {ml['claim']}자 이상."})
            if len(reason2_text.replace(" ", "")) < ml["reason"]:
                return jsonify({"ok": False, "error": f"보조 근거가 너무 짧습니다. 공백 제외 최소 {ml['reason']}자 이상."})

        ok, bad = clean_text_check(claim_text, reason_text, source_text, claim2_text, reason2_text)
        if not ok:
            return jsonify({"ok": False, "error": f"부적절한 표현이 포함되어 제출할 수 없습니다. ('{bad}')"})

        entry = {
            "claim": claim_text, "reason": reason_text, "source": source_text,
            "writer": writer, "submitted_at": now(), "auto": False,
            "warning_level": side_warning_level(room, side, "claim"),
        }
        if use_double and claim2_text and reason2_text:
            entry["claim2"] = claim2_text
            entry["reason2"] = reason2_text
        room["claims"][side] = entry
        if room["claims"]["pro"] is not None and room["claims"]["con"] is not None:
            set_phase(room, next_phase("claim"))
        save_state(s)
        return jsonify({"ok": True})


@app.route("/api/prep/ready", methods=["POST"])
def api_prep_ready():
    data = request.json
    client_id = data.get("client_id")
    with LOCK:
        s = load_state()
        cinfo = s["clients"].get(client_id)
        if not cinfo:
            return jsonify({"ok": False, "error": "참여 정보가 없습니다."})
        room = s["rooms"][cinfo["room"]]
        side = cinfo["side"]
        if room["phase"] != "prep":
            return jsonify({"ok": False, "error": "지금은 응답 준비 단계가 아닙니다."})
        room["prep_ready"][side] = True
        if room["prep_ready"]["pro"] and room["prep_ready"]["con"]:
            set_phase(room, "qa")
            room["qa"]["current_turn"] = "pro"
            room["qa"]["turn_started_at"] = now()
        save_state(s)
        return jsonify({"ok": True})


@app.route("/api/qa/send", methods=["POST"])
def api_qa_send():
    data = request.json
    client_id = data.get("client_id")
    text = (data.get("text") or "").strip()
    writer = (data.get("writer") or "").strip()

    with LOCK:
        s = load_state()
        cinfo = s["clients"].get(client_id)
        if not cinfo:
            return jsonify({"ok": False, "error": "참여 정보가 없습니다."})
        room = s["rooms"][cinfo["room"]]
        side = cinfo["side"]

        tick_qa_turn(room)
        if not seteuk_enabled(s):                       # 개인별 생기부를 끄면 발언마다 작성자를 고르지 않음
            writer = ""
        elif (room.get("members") or {}).get(side) and not writer:
            return jsonify({"ok": False, "error": "✍ 이번 턴 작성자를 선택하세요."})
        if writer and not writer_ok(room, side, writer):
            return jsonify({"ok": False, "error": "작성자는 우리 팀원 중에서 선택하세요."})  # 혹시 이미 시간초과된 턴이 있으면 먼저 정리

        if room["phase"] != "qa":
            return jsonify({"ok": False, "error": "지금은 자유토론 단계가 아닙니다."})
        out_of_turn_bonus = False
        if room["qa"]["current_turn"] != side:
            if room["extra_turn_active"].get(side):
                out_of_turn_bonus = True
            else:
                return jsonify({"ok": False, "error": "지금은 상대방 차례입니다."})
        if len(text.replace(" ", "")) < MIN_LEN["qa_message"]:
            return jsonify({"ok": False, "error": f"메시지가 너무 짧습니다. 공백 제외 최소 {MIN_LEN['qa_message']}자 이상."})
        ok, bad = clean_text_check(text)
        if not ok:
            return jsonify({"ok": False, "error": f"부적절한 표현이 포함되어 전송할 수 없습니다. ('{bad}')"})

        room["qa"]["messages"].append({"side": side, "text": text, "auto": False, "ts": now(), "writer": writer})
        room["drafts"].setdefault(side, {})["qa"] = {}
        TYPING[f"{cinfo['room']}|{side}"] = 0                       # 보냈으니 "입력 중" 표시 해제
        apply_attack(room, side, text)
        if out_of_turn_bonus:
            room["extra_turn_active"][side] = False  # 턴 순서는 그대로 유지, 보너스 발언만 소모
        else:
            used = min(now() - room["qa"]["turn_started_at"], qa_turn_limit(room))
            qa_end_turn(room, used)           # 쓴 시간만큼 우리 팀 시계에서 빼고 차례 넘김
        save_state(s)
        return jsonify({"ok": True})


@app.route("/api/item/use", methods=["POST"])
def api_item_use():
    data = request.json
    client_id = data.get("client_id")
    item_id = data.get("item_id")

    with LOCK:
        s = load_state()
        cinfo = s["clients"].get(client_id)
        if not cinfo:
            return jsonify({"ok": False, "error": "참여 정보가 없습니다."})
        room = s["rooms"][cinfo["room"]]
        side = cinfo["side"]

        if item_id not in ITEM_CATALOG:
            return jsonify({"ok": False, "error": "존재하지 않는 아이템입니다."})
        if item_id not in room["items"][side]:
            return jsonify({"ok": False, "error": "이 팀이 가진 아이템이 아닙니다."})
        if item_id in room["items_used"][side]:
            return jsonify({"ok": False, "error": "이미 사용한 아이템입니다."})

        result_msg = ITEM_CATALOG[item_id]["desc"]

        if item_id == "double_claim":
            if room["phase"] != "claim":
                return jsonify({"ok": False, "error": "이중 주장은 주장 펼치기 단계에서만 사용할 수 있습니다."})
            room["double_claim_active"][side] = True
        elif item_id == "time_bank":
            if room["phase"] == "qa":       # 자유토론은 체스 시계(18분 고정·팀별 공정)라 시간 늘리기 불가
                return jsonify({"ok": False, "error": "자유토론은 체스 시계 방식이라 시간을 늘릴 수 없어요."})
            room["phase_entered_at"] += 120  # 경과시간을 2분 되돌려서, 남은시간을 +2분 효과로
        elif item_id == "extra_turn":
            if room["phase"] != "qa":
                return jsonify({"ok": False, "error": "질문 스틸은 자유토론 단계에서만 사용할 수 있습니다."})
            room["extra_turn_active"][side] = True
        elif item_id == "hint":
            hint_text = random.choice(HINT_BANK)
            room["hint_revealed"][side] = True
            room["hint_text"][side] = hint_text
            result_msg = hint_text
        elif item_id == "shield":
            room["shield_active"][side] = True

        room["items_used"][side].append(item_id)
        save_state(s)
        return jsonify({"ok": True, "message": result_msg})


@app.route("/api/final/submit", methods=["POST"])
def api_final_submit():
    data = request.json
    client_id = data.get("client_id")
    text = (data.get("text") or "").strip()
    feedback = (data.get("feedback") or "").strip()
    writer = (data.get("writer") or "").strip()

    with LOCK:
        s = load_state()
        cinfo = s["clients"].get(client_id)
        if not cinfo:
            return jsonify({"ok": False, "error": "참여 정보가 없습니다."})
        room = s["rooms"][cinfo["room"]]
        side = cinfo["side"]

        if room["phase"] != "final":
            return jsonify({"ok": False, "error": "지금은 자기 단련의 시간이 아닙니다."})
        if room["final"][side] is not None:
            return jsonify({"ok": False, "error": "이미 제출했습니다. 상대 팀을 기다려주세요."})
        if not seteuk_enabled(s):                       # 개인별 생기부를 끄면 발언마다 작성자를 고르지 않음
            writer = ""
        elif (room.get("members") or {}).get(side) and not writer:
            return jsonify({"ok": False, "error": "✍ 이번 턴 작성자를 선택하세요."})
        if writer and not writer_ok(room, side, writer):
            return jsonify({"ok": False, "error": "작성자는 우리 팀원 중에서 선택하세요."})
        if len(text.replace(" ", "")) < MIN_LEN["final"]["text"]:
            return jsonify({"ok": False, "field": "text", "error": f"최종 결론을 조금 더 구체적으로 작성해주세요. 공백 제외 최소 {MIN_LEN['final']['text']}자 이상."})
        if len(feedback.replace(" ", "")) < MIN_LEN["selfcheck"]["text"]:
            return jsonify({"ok": False, "field": "feedback", "error": f"자기 피드백을 조금 더 구체적으로 작성해주세요. 공백 제외 최소 {MIN_LEN['selfcheck']['text']}자 이상."})
        ok, bad = clean_text_check(text, feedback)
        if not ok:
            return jsonify({"ok": False, "error": f"부적절한 표현이 포함되어 제출할 수 없습니다. ('{bad}')"})

        warn = side_warning_level(room, side, "final")
        room["final"][side] = {"text": text, "submitted_at": now(), "auto": False, "warning_level": warn, "writer": writer}
        room["selfcheck"][side] = {"text": feedback, "submitted_at": now(), "auto": False, "warning_level": warn, "writer": writer}
        if room["final"]["pro"] is not None and room["final"]["con"] is not None:
            set_phase(room, next_phase("final"))
        save_state(s)
        return jsonify({"ok": True})



# ---------------- 토론의 순간들 + 따봉 투표 + 시상식 ----------------

def _both_joined(room):
    return bool(room.get("pro")) and bool(room.get("con"))


def showcase_rooms(s):
    return [(rid, r) for rid, r in sorted(s["rooms"].items(), key=lambda x: int(x[0]))
            if _both_joined(r) and r["phase"] == "done" and r["final"].get("pro") and r["final"].get("con")]


VOTE_SECONDS = 120          # 따봉 투표는 열린 뒤 2분이면 자동 마감 → 시상식


def vote_seconds(s):
    """따봉 투표 시간: 6개 조까지는 2분, 조가 많으면 조당 7초씩 늘려 최대 3분 (여러 조의 최종 결론을 읽을 시간)"""
    n = len(showcase_rooms(s))
    return VOTE_SECONDS if n <= 6 else min(180, VOTE_SECONDS + (n - 6) * 7)


def showcase_enabled(s):
    """교사 선택: 동료평가(따봉 투표·시상식) 사용 여부 (기본 켜짐)"""
    return s.get("showcase_enabled", True)


def feedback_enabled(s):
    """교사 선택: 팀별 AI 피드백 사용 여부 (기본 켜짐)"""
    return s.get("feedback_enabled", True)


def showcase_tick(s):
    """투표가 열린 시각을 기록하고, 2분이 지나면 자동으로 시상식 공개. 바뀐 게 있으면 True"""
    if not showcase_enabled(s) or not showcase_is_open(s):
        return False
    sc = s.setdefault("showcase", {"open": False, "revealed": False, "votes": {}})
    changed = False
    if not sc.get("opened_at"):
        sc["opened_at"] = now(); changed = True
    if not sc.get("revealed") and now() - sc["opened_at"] >= vote_seconds(s) and showcase_rooms(s):
        sc["revealed"] = True; changed = True
    return changed


def vote_left(s):
    sc = s.get("showcase") or {}
    if not showcase_enabled(s) or sc.get("revealed") or not sc.get("opened_at"):
        return None
    return max(0, vote_seconds(s) - (now() - sc["opened_at"]))


def confirm_status(s):
    """'자기피드백을 확인했습니다'를 누른 팀 수 (토론에 참여한 모든 조의 찬성·반대)"""
    sc = s.get("showcase") or {}
    conf = sc.get("confirmed") or {}
    teams = [f"{rid}|{sd}" for rid, r in s["rooms"].items() if _both_joined(r) for sd in ("pro", "con")]
    return {"done": sum(1 for k in teams if k in conf), "total": len(teams), "waiting": [k for k in teams if k not in conf]}


def showcase_is_open(s):
    """따봉 투표 시작 조건: 모든 조가 토론을 마치고, 모든 팀이 '자기피드백을 확인했습니다'를 누름 (또는 교사가 바로 시작)"""
    if not showcase_enabled(s):
        return False
    sc = s.get("showcase") or {}
    if sc.get("open"):
        return True
    active = [r for r in s["rooms"].values() if _both_joined(r)]
    if not active or not all(r["phase"] == "done" for r in active):
        return False
    cs = confirm_status(s)
    return cs["total"] > 0 and cs["done"] >= cs["total"]


def pick_highlights(room, n=3):
    """자유토론에서 '왔다 갔다' 한 장면 3개: 근거(숫자·출처)와 내용이 가장 풍부한 연속 3개 발언"""
    msgs = [m for m in room["qa"]["messages"] if not m.get("auto")] or list(room["qa"]["messages"])
    if len(msgs) <= n:
        return msgs
    def score(m):
        return min(len(m["text"]), 120) + (60 if _is_crit_message(m["text"]) else 0)
    best_i = max(range(len(msgs) - n + 1), key=lambda i: sum(score(m) for m in msgs[i:i + n]))
    return msgs[best_i:best_i + n]


def showcase_winner(s):
    """따봉을 가장 많이 받은 조 (동점이면 근거 제시 발언이 많은 조 → 조 번호순)"""
    votes = (s.get("showcase") or {}).get("votes") or {}
    rooms = showcase_rooms(s)
    if not rooms:
        return None
    counts = {}
    for target in votes.values():
        t = str(target).split("|")[0]
        counts[t] = counts.get(t, 0) + 1
    cands = []
    for rid, r in rooms:
        crit = sum(1 for m in r["qa"]["messages"] if not m.get("auto") and _is_crit_message(m["text"]))
        cands.append((counts.get(rid, 0), crit, -int(rid), rid))
    cands.sort(reverse=True)
    votes_n, _, _, rid = cands[0]
    r = s["rooms"][rid]
    teams = {}
    for side in ("pro", "con"):
        teams[side] = {"species": (r.get("avatar", {}).get(side) or {}).get("species") or ("alpaca" if side == "pro" else "hippo"),
                       "members": [{"nick": member_label(m)} for m in ((r.get("members") or {}).get(side) or [])],   # 학생 화면엔 닉네임만
                       "team_name": r.get(f"{side}_name") or "", "text": r["final"][side]["text"]}
    return {"room": rid, "votes": votes_n, "teams": teams,
            "members": teams["pro"]["members"] + teams["con"]["members"]}


@app.route("/api/showcase", methods=["GET"])
def api_showcase():
    client_id = request.args.get("client_id")
    with LOCK:
        s = load_state()
        if showcase_tick(s):
            save_state(s)
        sc = s.setdefault("showcase", {"open": False, "revealed": False, "votes": {}})
        cinfo = s["clients"].get(client_id) or {}
        my_key = f"{cinfo.get('room')}|{cinfo.get('side')}" if cinfo else None
        rooms = []
        counts = {}
        for t in sc["votes"].values():
            t = str(t).split("|")[0]
            counts[t] = counts.get(t, 0) + 1
        for rid, r in showcase_rooms(s):
            item = {"room": rid, "topic": s.get("active_topic"), "highlights": [], "finals": {},
                    "votes": counts.get(rid, 0) if sc.get("revealed") else None}
            # 투표는 최종 결론만 보고 함 → 자유토론 장면(highlights)은 학생 화면으로 보내지 않음
            for side in ("pro", "con"):
                f = r["final"][side]
                item["finals"][side] = {"text": f["text"], "species": (r["avatar"].get(side) or {}).get("species"),
                                        "members": [{"nick": member_label(m)} for m in ((r.get("members") or {}).get(side) or [])]}
            rooms.append(item)
        total = len(rooms) * 2
        joined = [r for r in s["rooms"].values() if _both_joined(r)]
        return jsonify({"open": showcase_is_open(s), "revealed": bool(sc.get("revealed")), "rooms": rooms, "opened_at": sc.get("opened_at"),
                        "enabled": showcase_enabled(s), "feedback_enabled": feedback_enabled(s),
                        "my_confirmed": bool(cinfo and f"{cinfo.get('room')}|{cinfo.get('side')}" in (sc.get("confirmed") or {})),
                        "confirmed_teams": confirm_status(s)["done"], "total_teams": confirm_status(s)["total"],
                        "vote_left": vote_left(s), "vote_seconds": vote_seconds(s),
                        "done_rooms": sum(1 for r in joined if r["phase"] == "done"), "joined_rooms": len(joined),
                        "my_key": my_key, "my_room": str(cinfo.get("room")) if cinfo else None,
                        "my_vote": (str(sc["votes"].get(my_key)).split("|")[0] if sc["votes"].get(my_key) else None),
                        "voted": len(sc["votes"]), "total": total,
                        "winner": showcase_winner(s) if sc.get("revealed") else None})


@app.route("/api/showcase/confirm", methods=["POST"])
def api_showcase_confirm():
    """학생: '자기피드백을 확인했습니다' — 마지막 팀이 누르면 따봉 투표 시작"""
    data = request.json or {}
    with LOCK:
        s = load_state()
        cinfo = s["clients"].get(data.get("client_id"))
        if not cinfo:
            return jsonify({"ok": False, "error": "참여 정보가 없습니다."})
        room = s["rooms"][str(cinfo["room"])]
        if room["phase"] != "done":
            return jsonify({"ok": False, "error": "우리 조 토론이 끝난 뒤에 누를 수 있어요."})
        sc = s.setdefault("showcase", {"open": False, "revealed": False, "votes": {}})
        sc.setdefault("confirmed", {})[f"{cinfo['room']}|{cinfo['side']}"] = now()
        save_state(s)
        return jsonify({"ok": True, "open": showcase_is_open(s), **{k: v for k, v in confirm_status(s).items() if k != "waiting"}})


@app.route("/api/showcase/vote", methods=["POST"])
def api_showcase_vote():
    data = request.json or {}
    with LOCK:
        s = load_state()
        sc = s.setdefault("showcase", {"open": False, "revealed": False, "votes": {}})
        cinfo = s["clients"].get(data.get("client_id"))
        if not cinfo:
            return jsonify({"ok": False, "error": "참여 정보가 없습니다."})
        if not showcase_is_open(s) or sc.get("revealed"):
            return jsonify({"ok": False, "error": "지금은 투표 시간이 아닙니다."})
        my_key = f"{cinfo['room']}|{cinfo['side']}"
        target = str(data.get("target") or "").split("|")[0]       # 조 번호 (예전 'rid|side' 형식도 조로 처리)
        room_ids = [rid for rid, _ in showcase_rooms(s)]
        voters = [f"{rid}|{sd}" for rid in room_ids for sd in ("pro", "con")]
        if my_key not in voters:
            return jsonify({"ok": False, "error": "우리 조 토론을 마친 뒤에 투표할 수 있어요."})
        if target not in room_ids:
            return jsonify({"ok": False, "error": "투표 대상이 올바르지 않습니다."})
        if target == str(cinfo["room"]):
            return jsonify({"ok": False, "error": "우리 조에는 따봉을 누를 수 없어요 😊"})
        if my_key in sc["votes"]:
            return jsonify({"ok": False, "error": "이미 따봉을 눌렀어요. (팀당 1번)"})
        sc["votes"][my_key] = target
        if len(room_ids) > 1 and len(sc["votes"]) >= len(voters):   # 모든 팀이 투표하면 바로 시상식
            sc["revealed"] = True
            save_state(s)
        save_state(s)
        return jsonify({"ok": True})


@app.route("/api/teacher/showcase", methods=["POST"])
def api_teacher_showcase():
    action = (request.json or {}).get("action")
    with LOCK:
        s = load_state()
        sc = s.setdefault("showcase", {"open": False, "revealed": False, "votes": {}})
        if action == "next":
            # 교사 '다음 단계 ▶' (전체 진행): 모든 조가 끝났으면 → 투표 마감·시상식 / 시상식을 안 쓰면 피드백은 이미 공개
            comp = class_completion(s)
            if not comp["all_done"]:
                wait = ", ".join(f"{x}조" for x in comp["not_done"]) or "입장한 조 없음"
                return jsonify({"ok": False, "error": f"아직 토론 중인 조가 있어요 ({wait}). 기다리거나 [🏁 토론 전체 종료]를 누르세요."})
            if not showcase_enabled(s):
                return jsonify({"ok": True, "message": "투표·시상식을 쓰지 않는 수업이라, 각 조 화면에 AI 피드백이 이미 공개돼 있어요."})
            if sc.get("revealed"):
                return jsonify({"ok": True, "message": "시상식이 이미 진행됐어요."})
            if not showcase_is_open(s):              # 아직 '자기피드백 확인'을 안 누른 팀이 있어도 교사가 투표를 바로 시작
                sc["open"] = True
                save_state(s)
                return jsonify({"ok": True, "message": "👍 따봉 투표를 시작합니다. (2분 뒤 자동 마감)"})
            sc["open"] = True
            sc["revealed"] = True
            save_state(s)
            return jsonify({"ok": True, "message": "🏆 투표를 마감하고 시상식을 진행합니다."})
        if action == "toggle":
            body = request.json or {}
            s["showcase_enabled"] = bool(body.get("enabled", not showcase_enabled(s)))
            save_state(s)
            return jsonify({"ok": True, "enabled": s["showcase_enabled"]})
        if action == "toggle_seteuk":
            body = request.json or {}
            s["seteuk_enabled"] = bool(body.get("enabled", not seteuk_enabled(s)))
            save_state(s)
            return jsonify({"ok": True, "enabled": s["seteuk_enabled"]})
        if action == "toggle_paste":
            body = request.json or {}
            s["paste_block"] = bool(body.get("enabled", not s.get("paste_block")))
            save_state(s)
            return jsonify({"ok": True, "enabled": s["paste_block"]})
        if action == "toggle_feedback":
            body = request.json or {}
            s["feedback_enabled"] = bool(body.get("enabled", not feedback_enabled(s)))
            save_state(s)
            return jsonify({"ok": True, "enabled": s["feedback_enabled"]})
        if action == "finish_all":
            # 진행 중인 조는 쓴 만큼 자동 제출해 완료로, 한 팀만 들어온 조·빈 조는 제외 → 바로 투표 공개
            finished = []
            for rid, room in sorted(s["rooms"].items(), key=lambda x: int(x[0])):
                if not _both_joined(room) or room["phase"] == "done":
                    continue
                for _ in range(6):
                    ph = room["phase"]
                    if ph in ("waiting", "claim"):
                        for side in ("pro", "con"):
                            force_submit_claim(room, side)
                        set_phase(room, "prep")
                    elif ph in ("prep", "qa"):
                        set_phase(room, "final")
                    elif ph == "final":
                        for side in ("pro", "con"):
                            force_submit_final(room, side)
                        set_phase(room, "done")
                    else:
                        break
                room["forced"] = True
                finished.append(rid)
            s["class_finished"] = True
            save_state(s)
            done = [rid for rid, r in s["rooms"].items() if _both_joined(r) and r["phase"] == "done"]
            return jsonify({"ok": True, "finished": finished, "done_rooms": sorted(done, key=int),
                            "message": f"토론을 모두 마쳤습니다. 완료된 조: {', '.join(sorted(done, key=int)) or '없음'} — 학생들이 자기피드백을 확인하면 투표가 시작돼요"
                                       + (f" (방금 강제 완료: {', '.join(finished)}조)" if finished else "")})
        elif action == "open":
            sc["open"] = True
        elif action == "reveal":
            sc["open"] = True
            sc["revealed"] = True
        elif action == "feedback":                  # 실패했던 조 다시 시도 (키를 넣은 뒤 등)
            fbs = s.setdefault("team_feedback", {"items": {}, "failed": {}})
            fbs["failed"] = {}
            fbs["status"], fbs["error"] = "running", None
        elif action == "reset":
            s["showcase"] = {"open": False, "revealed": False, "votes": {}}
            s["team_feedback"] = {"items": {}, "failed": {}}
        save_state(s)
        return jsonify({"ok": True})


# ---------------- AI 분석: 조별 총평 · 우수팀 · 학생별 생기부(세특) 초안 ----------------

CONFIG_FILE = os.path.join(DATA_DIR, "config.json")
DEFAULT_MODEL = "claude-sonnet-5"
# AI 서비스별 기본 모델 (교사 화면에서 바꿀 수 있음)
PROVIDERS = {
    "claude": {"label": "Claude (Anthropic)", "model": "claude-sonnet-5", "key_hint": "sk-ant-로 시작", "console": "console.anthropic.com"},
    "gemini": {"label": "Gemini (Google)", "model": "gemini-3.5-flash-lite", "key_hint": "AQ. 또는 AIza로 시작", "console": "aistudio.google.com"},
    "openai": {"label": "GPT (OpenAI)", "model": "gpt-5.6-sol", "key_hint": "sk- 또는 sk-proj-로 시작", "console": "platform.openai.com"},
    "groq": {"label": "Groq", "model": "llama-3.3-70b-versatile", "key_hint": "gsk_로 시작", "console": "console.groq.com/keys"},
}
# 여러 키를 넣으면 이 순서로 사용: Gemini 먼저 → 오류·지연 시 다음 서비스로 자동 전환
PROVIDER_ORDER = ["gemini", "groq", "claude", "openai"]
AI_TIMEOUT = 60             # 이 시간 안에 응답이 없으면 '너무 느림'으로 보고 다음 서비스로
AI_COOLDOWN = 120           # 방금 실패한 서비스는 2분 동안 뒤로 미룸 (매번 느린 곳부터 기다리지 않게)
PROVIDER_HEALTH = {}        # 서비스 → 이 시각까지 뒤로 미룸


def detect_provider(key):
    """키 모양으로 어느 서비스 키인지 추정"""
    k = (key or "").strip()
    if k.startswith("sk-ant-"):
        return "claude"
    if k.startswith("AQ.") or k.startswith("AIza"):
        return "gemini"
    if k.startswith("gsk_"):
        return "groq"
    if k.startswith("sk-"):
        return "openai"
    return None
DEFAULT_STANDARDS = """[과학탐구실험 — 선생님이 사용하는 성취기준 원문으로 확인·수정해서 쓰세요]
- (과학적 탐구 능력) 실험·조사·토론 등을 통해 증거를 수집·해석·평가할 수 있다.
- (과학적 사고력) 과학적 주장과 증거의 관계를 탐색하고, 논증을 비판적으로 검토할 수 있다.
- (문제 해결·참여) 과학기술과 관련된 개인·사회 문제를 과학적으로 해결하고 참여·실천할 수 있다.
- (의사소통) 모둠 토의에서 근거를 들어 과학적 주장을 하고, 다른 의견과 비교하여 결론을 도출할 수 있다."""


def load_config():
    try:
        with open(CONFIG_FILE, encoding="utf-8") as f:
            c = json.load(f)
    except Exception:
        c = {}
    c.setdefault("keys", {})
    c.setdefault("models", {})
    old = c.pop("api_key", None)                      # 예전 설정(키 하나) → 서비스별로 옮김
    if old:
        c["keys"].setdefault(detect_provider(old) or ("claude" if old != "mock" else "claude"), old)
    if c.get("model") and not c["models"].get("claude") and str(c["model"]).startswith("claude"):
        c["models"]["claude"] = c["model"]
    c.pop("model", None)
    env = {"claude": "ANTHROPIC_API_KEY", "gemini": "GEMINI_API_KEY", "openai": "OPENAI_API_KEY", "groq": "GROQ_API_KEY"}
    if c["models"].get("gemini") == "gemini-3.8-flash":      # 예전 기본값(무료 하루 약 20회) → Flash-Lite(약 500회)
        c["models"]["gemini"] = "gemini-3.5-flash-lite"
    for p, info in PROVIDERS.items():
        if not c["keys"].get(p) and os.environ.get(env[p]):
            c["keys"][p] = os.environ[env[p]]
        c["models"].setdefault(p, info["model"])
    if c.get("provider") not in PROVIDERS:
        c["provider"] = next((p for p in PROVIDER_ORDER if c["keys"].get(p)), "gemini")
    c.setdefault("standards", DEFAULT_STANDARDS)
    if c["standards"].startswith("[통합과학2"):      # 예전 기본값은 새 기본값(과학탐구실험)으로 교체
        c["standards"] = DEFAULT_STANDARDS
    # 현재 선택된 서비스의 키/모델 (분석 코드에서 사용)
    c["api_key"] = c["keys"].get(c["provider"], "")
    c["model"] = c["models"][c["provider"]]
    vm = c.setdefault("verified_map", {})
    c["verified_list"] = [p for p in PROVIDER_ORDER if c["keys"].get(p) and vm.get(p) == _sig_for(p, c["models"][p], c["keys"][p])]
    c["verified_ok"] = bool(c["verified_list"])       # 등록한 키 중 하나라도 연결 테스트를 통과하면 수업 시작 가능
    return c


def _sig_for(p, model, key):
    """연결 테스트를 통과한 조합(서비스·모델·키) — 하나라도 바뀌면 다시 테스트 필요"""
    import hashlib
    return hashlib.sha256(f"{p}|{model}|{key}".encode()).hexdigest()[:16]


def _verify_sig(c):
    return _sig_for(c["provider"], c["model"], c["api_key"])


def ai_is_mock(cfg):
    """모의 모드: 환경변수 또는 사용 순서 첫 번째 키가 'mock'"""
    if os.environ.get("DEBATE_AI_MOCK") == "1":
        return True
    chain = provider_chain(cfg)
    return bool(chain) and chain[0][1] == "mock"


def provider_chain(cfg):
    """실제로 쓸 순서: Gemini → Groq → Claude → GPT 중 키가 있는 것. 방금 실패해 쉬는 중인 서비스는 맨 뒤로"""
    if "keys" not in cfg:                               # (단일 설정으로 부른 경우)
        return [(cfg["provider"], cfg.get("api_key", ""), cfg.get("model"))]
    ps = [p for p in PROVIDER_ORDER if cfg["keys"].get(p)]
    ps.sort(key=lambda p: 1 if PROVIDER_HEALTH.get(p, 0) > now() else 0)   # 안정 정렬: 순서 유지, 쉬는 곳만 뒤로
    return [(p, cfg["keys"][p], cfg["models"][p]) for p in ps]


CFG_LOCK = threading.RLock()      # 설정 파일(config.json)을 고치는 작업은 한 번에 하나씩


def _read_config_raw():
    try:
        with open(CONFIG_FILE, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def save_config(c):
    """설정 저장. 한 번에 하나씩 · 통째로 바꿔치기(중간에 꺼져도 파일이 깨지지 않게).
    이 함수를 부른 쪽이 모르는 값(암호 열쇠)은 지금 파일에 있으면 그대로 보존"""
    with CFG_LOCK:
        cur = _read_config_raw()
        out = dict(c)
        if cur.get("enc_key") and not out.get("enc_key"):
            out["enc_key"] = cur["enc_key"]
        tmp = CONFIG_FILE + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(out, f, ensure_ascii=False, indent=2)
        os.replace(tmp, CONFIG_FILE)


class AIError(Exception):
    def __init__(self, msg, code=None):
        super().__init__(msg)
        self.code = code

    @property
    def transient(self):
        """잠깐 기다리면 풀리는 오류인지 (서버 바쁨·한도·네트워크)"""
        return self.code in (408, 429, 500, 502, 503, 504, "network")


def _http_json(url, body, headers, timeout=180):
    import urllib.request, urllib.error
    req = urllib.request.Request(url, data=json.dumps(body).encode("utf-8"), method="POST",
                                 headers={"content-type": "application/json", **headers})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:   # timeout 넘으면 '느림' → 다음 서비스
            return json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        detail = ""
        try:
            err = json.loads(e.read().decode("utf-8", "replace"))
            er = err.get("error") if isinstance(err, dict) else None
            detail = (er.get("message") if isinstance(er, dict) else er) or str(err)
        except Exception:
            pass
        raise AIError(_friendly_error(e.code, str(detail)[:300]), e.code)
    except urllib.error.URLError as e:
        raise AIError(f"인터넷 연결을 확인하세요. ({e.reason})", "network")
    except (TimeoutError, ConnectionError) as e:
        raise AIError(f"AI 서비스 응답이 늦어요. ({e})", "network")


def _friendly_error(code, detail):
    hint = {401: "API 키가 올바르지 않거나, 선택한 서비스용 키가 아닙니다. (서비스 선택과 키 종류가 맞는지 확인하세요)",
            403: "이 키로는 해당 모델/서비스를 쓸 권한이 없습니다. (결제 등록·API 사용 설정·키 제한을 확인하세요)",
            404: "모델 이름이 올바르지 않습니다. 모델 칸을 기본값으로 되돌려 보세요.",
            429: "사용량 한도를 넘었거나 크레딧이 부족합니다. 잠시 후 다시 시도하거나 결제·한도를 확인하세요.",
            400: "요청 형식 오류입니다. 모델 이름을 확인하세요.",
            500: "AI 서비스 내부 오류입니다. 잠시 후 자동으로 다시 시도합니다.",
            502: "AI 서비스 연결이 불안정합니다. 잠시 후 자동으로 다시 시도합니다.",
            503: "AI 서비스에 요청이 몰려 일시적으로 바쁩니다(키 문제 아님). 잠시 후 자동으로 다시 시도합니다.",
            504: "AI 서비스 응답이 늦습니다. 잠시 후 자동으로 다시 시도합니다."}.get(code, "AI 서비스 오류가 발생했습니다.")
    return f"HTTP {code}: {hint}" + (f" — 서비스 응답: {detail}" if detail else "")


CONSENT_VERSION = 2            # 안내 내용이 바뀌면 올려서 다시 동의받기


def consent_ok(cfg=None):
    if os.environ.get("DEBATE_CONSENT") == "1":                 # 자동 테스트용
        return True
    c = (cfg or load_config()).get("consent") or {}
    if INTERNET_MODE and not c.get("internet"):              # 인터넷 중계를 거치는 방식은 안내가 달라서 따로 동의
        return False
    return c.get("version") == CONSENT_VERSION and bool(c.get("agreed_at"))


def _exit_app():
    flush_state()                      # 종료 전에 아직 디스크에 안 쓴 변경 저장
    os._exit(0)


@app.route("/api/teacher/consent", methods=["GET", "POST"])
def api_consent():
    cfg = load_config()
    if request.method == "POST":
        d = request.json or {}
        if d.get("agree"):
            with CFG_LOCK:
                cfg = load_config()
                cfg["consent"] = {"version": CONSENT_VERSION, "agreed_at": now(), "internet": bool(INTERNET_MODE) or bool((cfg.get("consent") or {}).get("internet"))}
                save_config({k: v for k, v in cfg.items() if k not in COMPUTED_CFG})
            return jsonify({"ok": True, "agreed": True})
        threading.Timer(1.0, _exit_app).start()                 # '동의하지 않음' → 앱(서버) 종료
        return jsonify({"ok": True, "agreed": False, "exiting": True})
    return jsonify({"agreed": consent_ok(cfg), "version": CONSENT_VERSION, "agreed_at": (cfg.get("consent") or {}).get("agreed_at"), "internet": INTERNET_MODE})


COMPUTED_CFG = ("api_key", "model", "verified_ok", "verified_list", "_used", "_timeout", "_json")


def _call_llm(cfg, system, user, max_tokens=4000, retries=2):
    """등록된 AI를 순서대로(Gemini 먼저) 사용. 오류가 나거나 60초 안에 응답이 없으면 다음 서비스로 자동 전환.
    서비스가 하나뿐이면 일시적 오류(503·429·네트워크)를 3초·8초 뒤 재시도. 실제로 쓴 서비스는 cfg['_used']에 기록"""
    if not consent_ok():
        raise AIError("개인정보 처리 안내에 먼저 동의해 주세요. (교사 화면 첫 화면)", "consent")     # 동의 전에는 학생 정보가 외부로 나가지 않음
    chain = provider_chain(cfg)
    if not chain or not chain[0][1]:
        raise AIError("등록된 AI 키가 없습니다. 교사 화면 ② AI 연결에서 키를 넣어 주세요.")
    per_retries = retries if len(chain) == 1 else 1      # 여러 개면 빨리 다음 서비스로
    errors, last = [], None
    for p, key, model in chain:
        c2 = dict(cfg, provider=p, api_key=key, model=model)
        for attempt in range(per_retries + 1):
            try:
                out = _call_llm_once(c2, system, user, max_tokens)
                PROVIDER_HEALTH.pop(p, None)
                cfg["_used"] = f"{PROVIDERS[p]['label']} · {model}"
                return out
            except AIError as e:
                last = e
                if e.transient and attempt < per_retries:
                    time.sleep((3, 8, 15)[attempt]); continue
                PROVIDER_HEALTH[p] = now() + (AI_COOLDOWN if e.transient else 600)   # 잠시 뒤로 미룸
                errors.append(f"{PROVIDERS[p]['label']}: {e}")
                break
    if len(chain) == 1:
        raise last
    raise AIError("등록된 AI가 모두 실패했습니다 — " + " / ".join(errors), last.code if last else None)


def _gemini_gen_config(model, max_tokens):
    """Flash-Lite는 기본적으로 생각을 거의 안 해서 빠름. 일반 Gemini 3 모델은 생각 수준을 low로 낮춰 지연을 줄임"""
    gc = {"maxOutputTokens": max(max_tokens * 2, 2048)}
    if "lite" not in model and model.startswith("gemini-3"):
        gc["thinkingConfig"] = {"thinkingLevel": "low"}
        gc["maxOutputTokens"] = max(max_tokens * 4, 8192)
    return gc


def _call_llm_once(cfg, system, user, max_tokens=4000):
    """선택한 AI 서비스 1회 호출. cfg['_json']이면 서비스의 'JSON 출력 모드'를 켬
    (Gemini·Groq·GPT는 문법이 깨진 JSON을 낼 수 없게 됨). 모델이 이 모드를 거부(400)하면 모드 없이 한 번 더"""
    if cfg.get("_json"):
        try:
            return _call_llm_once_raw(cfg, system, user, max_tokens, True)
        except AIError as e:
            if e.code != 400:
                raise
    return _call_llm_once_raw(cfg, system, user, max_tokens, False)


def _call_llm_once_raw(cfg, system, user, max_tokens, json_mode):
    p, key, model = cfg.get("provider", "claude"), (cfg.get("api_key") or "").strip(), cfg.get("model")
    if not key:
        raise AIError(f"{PROVIDERS[p]['label']} API 키가 없습니다. 교사 화면에서 키를 입력하고 저장하세요.")
    if p == "claude":
        data = _http_json("https://api.anthropic.com/v1/messages",
                          {"model": model, "max_tokens": max_tokens, "system": system, "messages": [{"role": "user", "content": user}]},
                          {"x-api-key": key, "anthropic-version": "2023-06-01"}, timeout=cfg.get("_timeout", AI_TIMEOUT))
        return "".join(b.get("text", "") for b in data.get("content", []) if b.get("type") == "text")
    if p == "gemini":
        # 새 형식 키(AQ.)도 동작하도록 구글 기본 주소 + x-goog-api-key 헤더 사용 (OpenAI 호환 주소는 AQ. 키에서 401이 날 수 있음)
        data = _http_json(f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent",
                          {"systemInstruction": {"parts": [{"text": system}]},
                           "contents": [{"role": "user", "parts": [{"text": user}]}],
                           "generationConfig": {**_gemini_gen_config(model, max_tokens), **({"responseMimeType": "application/json"} if json_mode else {})}},
                          {"x-goog-api-key": key}, timeout=cfg.get("_timeout", AI_TIMEOUT))
        cands = data.get("candidates") or []
        if not cands:
            fb = (data.get("promptFeedback") or {}).get("blockReason")
            raise AIError(f"Gemini가 답을 주지 않았습니다.{' (차단 사유: ' + fb + ')' if fb else ''}")
        parts = (cands[0].get("content") or {}).get("parts") or []
        return "".join(x.get("text", "") for x in parts if not x.get("thought"))
    if p == "groq":           # OpenAI 호환 방식 (https://api.groq.com/openai/v1)
        data = _http_json("https://api.groq.com/openai/v1/chat/completions",
                          {"model": model, "messages": [{"role": "system", "content": system}, {"role": "user", "content": user}],
                           "max_completion_tokens": min(max(max_tokens * 2, 1024), 8000), **({"response_format": {"type": "json_object"}} if json_mode else {})},
                          {"authorization": f"Bearer {key}"}, timeout=cfg.get("_timeout", AI_TIMEOUT))
        return ((data.get("choices") or [{}])[0].get("message") or {}).get("content") or ""
    if p == "openai":
        data = _http_json("https://api.openai.com/v1/chat/completions",
                          {"model": model, "messages": [{"role": "system", "content": system}, {"role": "user", "content": user}],
                           "max_completion_tokens": max(max_tokens * 4, 8192), **({"response_format": {"type": "json_object"}} if json_mode else {})},   # 추론 토큰 여유
                          {"authorization": f"Bearer {key}"}, timeout=cfg.get("_timeout", AI_TIMEOUT))
        return ((data.get("choices") or [{}])[0].get("message") or {}).get("content") or ""
    raise AIError("알 수 없는 AI 서비스입니다.")


_call_claude = _call_llm      # 예전 이름 호환


def _parse_json(text):
    """AI 답에서 JSON 꺼내기 — 앞뒤 설명·```json 표시·끝의 쉼표처럼 가벼운 모델이 자주 하는 실수는 너그럽게"""
    t = re.sub(r"```(?:json)?", "", str(text or "")).strip()
    i, j = t.find("{"), t.rfind("}")
    if i < 0 or j <= i:
        raise AIError("AI 답에서 결과(JSON)를 찾지 못했습니다.")
    body = t[i:j + 1]
    try:
        return json.loads(body)
    except Exception:
        fixed = re.sub(r",\s*([}\]])", r"\1", body)                   # 끝에 남은 쉼표
        try:
            return json.loads(fixed)
        except Exception:
            pass
        try:
            return json.loads(re.sub(r",\s*([}\]])", r"\1", _escape_inner_quotes(body)))   # 문장 속 따옴표
        except Exception:
            raise AIError("AI 답의 형식이 올바르지 않았습니다.")


def _escape_inner_quotes(s):
    """문자열 값 안에 그대로 쓴 따옴표(") 고치기: 문자열 안에서 만난 따옴표 뒤에 , : } ] 가 오지 않으면 '문장 속 따옴표'로 보고 \" 로 바꿈"""
    out, in_str, i, n = [], False, 0, len(s)
    while i < n:
        ch = s[i]
        if not in_str:
            out.append(ch)
            if ch == '"':
                in_str = True
        elif ch == "\\":
            out.append(s[i:i + 2]); i += 2; continue
        elif ch == '"':
            j = i + 1
            while j < n and s[j] in " \t\r\n":
                j += 1
            if j >= n or s[j] in ",:}]":
                out.append(ch); in_str = False
            else:
                out.append('\\"')
        elif ch == "\n":
            out.append("\\n")
        else:
            out.append(ch)
        i += 1
    return "".join(out)


_TEAM_KEYS = {"pro": ("pro", "찬성", "찬성팀", "affirmative", "pro_team", "Pro"), "con": ("con", "반대", "반대팀", "negative", "con_team", "Con")}


def _team_part(g, sd):
    """{pro:…, con:…} 대신 {찬성팀:…}, {teams:{…}}, [찬성, 반대] 처럼 와도 해당 팀 부분을 찾음"""
    if isinstance(g, list):
        return g[0 if sd == "pro" else 1] if len(g) == 2 and all(isinstance(x, dict) for x in g) else {}
    if not isinstance(g, dict):
        return {}
    for src in (g, g.get("teams") if isinstance(g.get("teams"), dict) else {}):
        for k in _TEAM_KEYS[sd]:
            if isinstance(src.get(k), dict):
                return src[k]
    return {}


def _ask_json(call, check, what, lenient_last=False):
    """AI에게 묻고 JSON으로 읽기. 형식이 틀리면 한 번 더 '형식 그대로만' 다시 요청 (가벼운 모델 대비)
    lenient_last: 두 번째 답이 JSON이긴 한데 확인(check)만 통과 못 하면 예전처럼 그 답을 그대로 씀"""
    reminder = ""
    for attempt in (1, 2):
        g = None
        try:
            g = _parse_json(call(reminder))
            check(g)
            return g
        except AIError as e:
            if attempt == 2 and lenient_last and g is not None and e.code is None:
                return g
            if e.code is not None or attempt == 2:                   # 서버 오류·한도 등은 그대로 위로 (다른 서비스로 전환은 _call_llm이 처리)
                raise
            reminder = (f"\n\n[다시 요청] 앞의 답은 {what} 형식에 맞지 않았어요. 설명이나 다른 글 없이, 위에서 알려 준 JSON 형식 그대로만 답하세요. "
                        '팀 이름 키는 반드시 "pro"(찬성)와 "con"(반대)을 쓰세요.')


def room_transcript_for_ai(rid, r, topic):
    lines = [f"[{rid}조] 토론 주제: {topic}"]
    for side in ("pro", "con"):
        mem = ", ".join(member_label(m) for m in (r.get("members") or {}).get(side) or []) or (r.get(f"{side}_name") or "")
        lines.append(f"{SIDE_KO_PY[side]} 팀원: {mem}")
    for side in ("pro", "con"):
        c = r["claims"].get(side)
        if c:
            lines.append(f"\n<최초 주장 · {SIDE_KO_PY[side]} · 작성자 {c.get('writer','')}>\n핵심 주장: {c.get('claim')}\n근거: {c.get('reason')}\n출처: {c.get('source')}")
    lines.append("\n<자유토론>")
    for i, m in enumerate(r["qa"]["messages"], 1):
        auto = " (시간 초과 자동 전송)" if m.get("auto") else ""
        lines.append(f"{i}. {SIDE_KO_PY[m['side']]} · 작성자 {m.get('writer','') or '미기록'}{auto}: {m['text']}")
    for side in ("pro", "con"):
        f, sc = r["final"].get(side), r["selfcheck"].get(side)
        if f:
            lines.append(f"\n<최종 결론 · {SIDE_KO_PY[side]} · 작성자 {f.get('writer','')}>\n{f.get('text')}")
        if sc:
            lines.append(f"<자기 피드백 · {SIDE_KO_PY[side]}>\n{sc.get('text')}")
    return "\n".join(lines)


SETEUK_MAX_BYTES = 400
# 세특 참고 레퍼런스: 기록 폴더에 선생님이 고친 파일이 있으면 그걸, 없으면 프로그램에 들어 있는 기본 파일
REFERENCE_FILE = (os.path.join(DATA_DIR, "seteuk_reference.md") if os.path.exists(os.path.join(DATA_DIR, "seteuk_reference.md"))
                  else os.path.join(RES_DIR, "seteuk_reference.md"))


def load_reference():
    try:
        with open(REFERENCE_FILE, encoding="utf-8") as f:
            return f.read()
    except Exception:
        return ""


def neis_bytes(text):
    """나이스 기준 바이트: 한글 3바이트, 영문·숫자·공백 1바이트, 줄바꿈 2바이트"""
    t = (text or "").replace("\r", "")
    return len(t.encode("utf-8")) + t.count("\n")


def fit_bytes(text, limit=SETEUK_MAX_BYTES):
    """문장 단위로 잘라 limit 바이트 이내로 맞춤 (문장 중간에서 자르지 않음)"""
    text = " ".join((text or "").split())
    if neis_bytes(text) <= limit:
        return text
    sents = [x.strip() for x in re.split(r"(?<=[.])\s+", text) if x.strip()]
    out = ""
    for sen in sents:
        cand = (out + " " + sen).strip()
        if neis_bytes(cand) > limit:
            break
        out = cand
    if not out:   # 첫 문장부터 너무 길면 글자 단위로 자르고 마침표
        out = sents[0] if sents else text
        while neis_bytes(out + "함.") > limit and out:
            out = out[:-1]
        out = out.rstrip(" ,") + ("" if out.endswith(".") else "함.")
    return out


RUBRIC = [
    ("주장 명확성", "자신의 입장과 주장이 명확하게 드러남.", "입장이 불분명하거나 같은 주장을 단순 반복함."),
    ("근거 제시", "주장과 관련된 구체적인 사실, 자료, 사례 또는 과학적 원리를 근거로 제시함.", "근거가 부족하거나 주장과 직접적인 관련이 없음."),
    ("논리적 설명", "제시한 근거가 왜 자신의 주장을 뒷받침하는지 설명함.", "주장과 근거의 연결이 약하거나 논리적 비약이 있음."),
    ("반론 대응", "상대방의 주장이나 근거를 파악하고 이에 맞게 반박하거나 자신의 주장을 보완함.", "상대방의 주장을 고려하지 않고 자신의 주장만 반복함."),
    ("소통과 토론 참여", "상대방의 발언을 바탕으로 질문하거나 응답하며 토론의 흐름에 맞게 발언함.", "상대방의 발언과 관계없는 답변을 하거나 토론에 소극적으로 참여함."),
]
RUBRIC_NAMES = [r[0] for r in RUBRIC]
RUBRIC_TEXT = "\n".join(f"{i}. {n}\n   - 잘함: {g}\n   - 아쉬움: {b}" for i, (n, g, b) in enumerate(RUBRIC, 1)) + (
    "\n판단할 때 단순히 발언의 길이나 어려운 용어의 사용 여부로 평가하지 말고, "
    "실제로 주장·근거·논리·반론 대응이 이루어졌는지를 중심으로 판단하라.")

FEEDBACK_SYSTEM = """당신은 고등학교 1학년 과학 토론을 마친 팀에게 피드백을 주는 사람입니다.

[말투] 인터넷 방송에서 친구랑 수다 떨듯, 능청스럽고 뻔뻔하게, 살짝 '킹받는'(얄밉지만 웃긴) 말투로 유쾌하게.
- 학생들이 실제로 쓴 발언을 짚으며 "이건 왜 이렇게 한 거야?", "아니 근데 이건 좀…" 처럼 장난스럽게 묻되, 지적 내용은 객관적인 사실에 근거한다.
- 설명할 때는 어려운 말 대신 일상생활 속 엉뚱하고 하찮은 비유를 쓴다. 예: 라면 물 조절 실패, 짝 안 맞는 양말, 정리 안 된 방, 충전 안 된 휴대폰, 뚜껑 안 닫힌 물병.
- 특정 실존 인물을 흉내 낸다고 말하거나 그 사람의 실제 말을 지어내지 않는다. 비속어·비하·인신공격은 절대 쓰지 않는다(놀리는 대상은 '발언 내용'이지 학생이 아니다).

[어휘] 중학교 3학년~고등학교 1학년이 쓰는 일상 어휘만 쓴다. 엔트로피, 알고리즘, 파라미터 같은 전문 용어는 쓰지 말고 일상적인 비유(예: 방 정리가 안 된 상태)로 풀어서 말한다.

[칭찬 제한 — 가장 중요]
- 무조건적인 칭찬·동조·감탄은 하지 않는다.
- good에는 사실에 기반한 장점 딱 1개, improve에는 구체적인 개선점 딱 1개만 쓴다(여러 개를 나열하지 않는다).
- 5가지 기준의 comment는 칭찬이나 감탄 없이 '관찰한 사실'만 한 문장으로 쓴다.
- closing에는 "뭐, 그래도 처음 치고 이 정도면 나쁘지 않네. 알아서 잘 고쳐봐~" 같은 느낌으로 무심하게 툭 던지는 한 문장을 쓴다. 정답을 알려 주지 말고 학생이 스스로 방향을 찾게 한다.

[판단 원칙]
- 오직 제공된 이 팀의 실제 발언만 근거로 판단하고, 발언에 없는 내용을 지어내지 않는다.
- 발언의 길이나 어려운 말이 아니라 주장·근거·논리·반론 대응이 실제로 이루어졌는지로 판단한다. 애매하면 '아쉬움'.
- 학생을 '여러분'이라고 부르고 반말이 섞인 친근한 존댓말(~해요/~네)을 쓴다.
- 출력은 설명 없이 JSON 하나만. comment는 1문장, good·improve는 각 1~2문장, closing은 1문장."""

_BAD_XML = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\ufffe\uffff]")


def as_text(v):
    """AI 답 정리: 묶음(목록·사전)·빈 값·제어문자가 섞여도 사람이 읽는 한 덩어리 글자로"""
    if v is None:
        return ""
    if isinstance(v, (list, tuple)):
        return "\n".join(t for t in (as_text(x) for x in v) if t)
    if isinstance(v, dict):
        return " ".join(t for t in (as_text(x) for x in v.values()) if t)
    return _BAD_XML.sub("", str(v)).strip()


def as_list(v):
    """'잘한 점/아쉬운 점'은 항상 글자 목록으로"""
    if v is None:
        return []
    items = v if isinstance(v, (list, tuple)) else [v]
    return [t for t in (as_text(x) for x in items) if t]


NO_RECORD = "관찰 가능한 발언 기록이 부족함."
AI_MISSING = "⚠ AI 초안 누락 — 이 학생은 발언 기록이 있으니 다시 분석하거나 직접 작성하세요."

AI_SYSTEM = """당신은 고등학교 과학탐구실험 교사를 돕는 평가 보조자입니다. 학생 토론 기록을 읽고 교사가 검토할 세부능력 및 특기사항(세특) 초안을 만듭니다.
반드시 지킬 것:
1. 학생별 세특은 그 학생이 '작성자'로 기록된 발언만 근거로 한다. 학생이 실제로 쓴 내용 이상의 사실·자료·활동을 만들어내지 않는다.
2. 한 학생당 400바이트 이내(나이스 기준: 한글 1자 3바이트, 공백·숫자·영문 1바이트)로 쓴다. 바이트는 세기 어려우니 한글 100~120자(공백 포함)를 넘기지 않게 글자 수를 세어서 쓴다.
3. 문체는 '~임.', '~함.'으로 끝나는 명사형 종결만 쓴다. 학생 이름은 문장에 넣지 않는다.
4. 제시된 과학탐구실험 성취기준에 비추어 객관적으로 우수한 부분에만 긍정적 표현(돋보임, 우수함, 뛰어남 등)으로 끝낸다. 평범한 부분은 관찰된 행동 사실만 기술한다.
5. '토론에 적극적으로 참여함' 같은 빈 표현 대신, 어떤 쟁점에서 어떤 근거로 무엇을 했는지(질문 제기, 근거 요구, 자료 비교, 출처 확인, 반박, 주장 수정 등)를 쓴다.
6. 작성한 발언이 없거나 판단하기에 너무 적으면 record에 "관찰 가능한 발언 기록이 부족함."이라고만 쓴다.
7. 참고 레퍼런스는 기록 방식 참고용이다. 레퍼런스 문장을 그대로 베끼지 않는다.
8. 출력은 설명 없이 JSON 하나만."""


def student_statements(r, label):
    """이 학생이 작성자로 기록된 발언만 모음 (생기부 근거)"""
    out = []
    for side in ("pro", "con"):
        c = r["claims"].get(side)
        if c and writer_has(c.get("writer"), label) and not c.get("auto"):
            out.append(f"[최초 주장] 핵심 주장: {c.get('claim')} / 근거: {c.get('reason')} / 출처: {c.get('source')}")
    for m in r["qa"]["messages"]:
        if writer_has(m.get("writer"), label) and not m.get("auto"):
            out.append(f"[자유토론] {m['text']}")
    for side in ("pro", "con"):
        f, sc = r["final"].get(side), r["selfcheck"].get(side)
        if f and writer_has(f.get("writer"), label) and not f.get("auto"):
            out.append(f"[최종 결론] {f.get('text')}")
            if sc and not sc.get("auto"):
                out.append(f"[자기 피드백] {sc.get('text')}")
    return out


def room_statements_text(r):
    """조 전체 토론 기록 (두 팀 함께, 시간 순서) — 조당 AI 호출 1번으로 찬성·반대를 같이 분석"""
    lines = []
    for sd in ("pro", "con"):
        c = r["claims"].get(sd)
        if c:
            lines.append(f"[{SIDE_KO_PY[sd]} 최초 주장] 주장: {c.get('claim')} / 근거: {c.get('reason')} / 출처: {c.get('source')}"
                         + (" (시간 초과 자동 제출)" if c.get("auto") else ""))
    for i, m in enumerate(r["qa"]["messages"], 1):
        lines.append(f"[자유토론 {i} · {SIDE_KO_PY[m['side']]}] {m['text']}" + (" (시간 초과 자동 전송)" if m.get("auto") else ""))
    for sd in ("pro", "con"):
        f, sc = r["final"].get(sd), r["selfcheck"].get(sd)
        if f:
            lines.append(f"[{SIDE_KO_PY[sd]} 최종 결론] {f.get('text')}")
        if sc:
            lines.append(f"[{SIDE_KO_PY[sd]} 자기 피드백] {sc.get('text')}")
    return "\n".join(lines)


def _mock_team_feedback(rid, side, r):
    mine = [m for m in r["qa"]["messages"] if m["side"] == side and not m.get("auto")]
    crit = any(_is_crit_message(m["text"]) for m in mine)
    return {"criteria": [
        {"name": "주장 명확성", "result": "잘함", "comment": "아니 근데 입장을 첫 문장에 딱 박아 둔 건 맞네요. 이건 인정."},
        {"name": "근거 제시", "result": "잘함" if crit else "아쉬움", "comment": "숫자나 조사 자료를 들어 주장을 뒷받침했어요." if crit else "주장을 받쳐 줄 자료나 사례가 더 필요했어요."},
        {"name": "논리적 설명", "result": "아쉬움", "comment": "자료랑 주장 사이가 짝 안 맞는 양말 같아요. 이 자료가 왜 이 주장을 받쳐 주는지 한 문장만 붙여 봐요."},
        {"name": "반론 대응", "result": "잘함" if len(mine) >= 2 else "아쉬움", "comment": "상대 팀이 말한 내용을 받아서 대답했어요." if len(mine) >= 2 else "상대 팀 주장에 직접 답하는 발언이 적었어요."},
        {"name": "소통과 토론 참여", "result": "잘함", "comment": "차례마다 상대 발언을 이어받아 토론에 꾸준히 참여했어요."}],
        "good": "입장을 끝까지 안 바꾼 건 사실이에요. (모의 결과)",
        "improve": "상대가 찌른 질문에 답 안 하고 딴 얘기로 넘어간 거, 이건 왜 그런 거예요? 질문에 먼저 답하고 주장을 이어 가 봐요. (모의 결과)"}


RUBRIC_KEYWORDS = {"주장 명확성": ["명확", "주장"], "근거 제시": ["근거"], "논리적 설명": ["논리"],
                   "반론 대응": ["반론", "반박"], "소통과 토론 참여": ["소통", "참여"]}


def _match_rubric(name):
    n = str(name).replace(" ", "")
    for key in ("반론 대응", "소통과 토론 참여", "논리적 설명", "근거 제시", "주장 명확성"):   # 구체적인 것부터
        if any(k in n for k in RUBRIC_KEYWORDS[key]):
            return key
    return None


def _clean_feedback(g):
    """AI 결과 검증: 5개 기준이 순서대로, 판정은 잘함/아쉬움만"""
    by = {}
    for c in (g.get("criteria") or []):
        key = _match_rubric(c.get("name", ""))
        if key and key not in by:
            res = str(c.get("result", "")).strip()
            by[key] = {"name": key, "result": "잘함" if res.startswith("잘") else "아쉬움",
                       "comment": str(c.get("comment", "")).strip() or "발언 기록으로 판단하기 어려워요."}
    if len(by) < 3:
        raise AIError("AI가 5가지 기준에 맞게 답하지 않았습니다. 다시 시도해 주세요.")
    crit = [by.get(n) or {"name": n, "result": "아쉬움", "comment": "이 기준은 발언 기록만으로 판단하기 어려웠어요."} for n in RUBRIC_NAMES]
    closing = as_text(g.get("closing"))[:160] or DEFAULT_CLOSING
    return {"criteria": crit, "good": as_text(g.get("good")), "improve": as_text(g.get("improve")), "closing": closing}


DEFAULT_CLOSING = "뭐, 그래도 처음 치고 이 정도면 나쁘지 않네. 알아서 잘 고쳐봐~"


_FB_WORKER = {"started": False}
_FB_LOCK = threading.Lock()


def _fb_update(**kw):
    """상태가 실제로 바뀔 때만 저장"""
    with LOCK:
        st = load_state()
        fb = st.setdefault("team_feedback", {"items": {}, "failed": {}})
        if any(fb.get(k) != v for k, v in kw.items()):
            fb.update(kw)
            save_state(st)


FB_MAX_ATTEMPTS = 3        # 일시적 오류(서버 바쁨 등)로 실패한 조는 자동으로 최대 3번까지 다시 시도


def _rooms_needing_feedback(st):
    if not feedback_enabled(st):
        return []
    fb = st.get("team_feedback") or {}
    items, failed = fb.get("items") or {}, fb.get("failed") or {}
    out = []
    for rid, r in sorted(st["rooms"].items(), key=lambda x: int(x[0])):
        if not (_both_joined(r) and r["phase"] == "done"):
            continue
        if all(f"{rid}|{sd}" in items for sd in ("pro", "con")):
            continue
        fl = failed.get(rid)
        if isinstance(fl, dict):
            if not (fl.get("transient") and fl.get("attempts", 0) < FB_MAX_ATTEMPTS and now() >= fl.get("next_at", 0)):
                continue                      # 키 문제 등은 교사가 '다시 시도'를 누를 때까지 대기
        elif fl:
            continue
        out.append((rid, r))
    return out


FB_PARALLEL = MAX_ROOMS    # 조별 피드백은 끝난 조 모두 동시에 (한도에 걸리면 자동으로 잠시 뒤 다시)
FB_INFLIGHT = set()        # 지금 만드는 중인 조


def _mock_delay():
    """(시험용) 모의 AI가 실제 AI처럼 N초 걸리는 것을 흉내 — 환경변수 DEBATE_MOCK_LATENCY, 기본 0"""
    try:
        d = float(os.environ.get("DEBATE_MOCK_LATENCY", "0"))
    except ValueError:
        d = 0
    if d > 0:
        time.sleep(d)


def _feedback_one(rid, r, topic, mp, cfg, mock):
    """한 조(찬성·반대)의 피드백을 AI 호출 1번으로 만들어 저장. 실명·학번은 닉네임으로 바꿔서 보냄"""
    engine = "모의" if mock else " → ".join(PROVIDERS[p]["label"].split(" ")[0] for p, _, _ in provider_chain(cfg))
    try:
        if mock:
            _mock_delay()
            both = {sd: _mock_team_feedback(rid, sd, r) for sd in ("pro", "con")}
        else:
            prompt = (f"토론 주제: {topic}\n\n"
                      f"다음 5가지 기준으로 찬성팀과 반대팀의 발언을 각각 판단하세요:\n{RUBRIC_TEXT}\n\n"
                      f"토론 기록(두 팀 발언, 시간 순서):\n{room_statements_text(r)}\n\n"
                      "각 팀 피드백은 그 팀 학생들이 읽습니다. 다음 JSON 형식으로만 답하세요:\n"
                      '{"pro":{"criteria":[{"name":"주장 명확성","result":"잘함 또는 아쉬움","comment":"한두 문장"},'
                      '{"name":"근거 제시",...},{"name":"논리적 설명",...},{"name":"반론 대응",...},{"name":"소통과 토론 참여",...}],'
                      '"good":"사실에 기반한 장점 딱 1개(1~2문장)","improve":"구체적인 개선점 딱 1개(1~2문장)",'
                      '"closing":"무심하게 툭 던지는 마지막 한 문장"},'
                      '"con":{...찬성과 같은 형식...}}')
            c2 = dict(cfg, _json=True)                    # JSON 출력 모드 (형식이 깨진 결과 방지)
            def _check(g):
                for sd in ("pro", "con"):
                    _clean_feedback(_team_part(g, sd))                 # 5가지 기준이 3개도 안 되면 AIError → 한 번 더 요청
            g = _ask_json(lambda extra: _call_llm(c2, FEEDBACK_SYSTEM, scrub(prompt + extra, mp), max_tokens=3200), _check, "팀 피드백")
            both = {sd: _team_part(g, sd) for sd in ("pro", "con")}
            engine = c2.get("_used", engine)             # 자동 전환됐으면 실제로 답한 서비스
        cleaned = {}
        for sd in ("pro", "con"):
            fbx = _clean_feedback(both[sd])
            fbx.update({"room": rid, "side": sd, "generated_at": now()})
            cleaned[sd] = fbx
        with LOCK:
            st = load_state()
            fbs = st.setdefault("team_feedback", {"items": {}, "failed": {}})
            for sd in ("pro", "con"):
                fbs.setdefault("items", {})[f"{rid}|{sd}"] = cleaned[sd]
            (fbs.get("failed") or {}).pop(rid, None)
            left = [x for x in _rooms_needing_feedback(st) if x[0] not in FB_INFLIGHT or x[0] == rid]
            left = [x for x in left if x[0] != rid]
            fbs.update(status="running" if left or len(FB_INFLIGHT) > 1 else "done", progress=f"{rid}조 완료", error=None, engine=engine)
            save_state(st)
    except Exception as e:
        transient = isinstance(e, AIError) and e.transient
        with LOCK:
            st = load_state()
            fbs = st.setdefault("team_feedback", {"items": {}, "failed": {}})
            prev = (fbs.setdefault("failed", {}).get(rid) or {})
            attempts = (prev.get("attempts", 0) if isinstance(prev, dict) else 0) + 1
            retry = transient and attempts < FB_MAX_ATTEMPTS
            quota = isinstance(e, AIError) and e.code == 429 and ("quota" in str(e).lower() or "per day" in str(e).lower() or "exhausted" in str(e).lower())
            msg = f"{rid}조 피드백 생성 오류 — {e}" + (" (오늘 무료 사용량을 다 쓴 것 같아요. 한국 시간 오후 4~5시에 초기화됩니다)" if quota else "") \
                  + (f" (30초 뒤 자동 재시도 {attempts}/{FB_MAX_ATTEMPTS - 1})" if retry else "")
            fbs["failed"][rid] = {"msg": msg, "attempts": attempts, "transient": transient, "next_at": now() + 30 * attempts}
            fbs.update(status="error", error=msg)
            save_state(st)
    finally:
        FB_INFLIGHT.discard(rid)


def _feedback_worker():
    """토론을 마친 조가 생기면 바로 피드백을 만든다 (2개 조씩 동시에). 교사가 피드백을 끄면 AI를 부르지 않음"""
    while True:
        try:
            with LOCK:
                st = load_state()
                need = [x for x in _rooms_needing_feedback(st) if x[0] not in FB_INFLIGHT]
                topic = st.get("active_topic") or ""
                mp = pii_map(st)
            if not need or len(FB_INFLIGHT) >= FB_PARALLEL:
                _FB_WAKE.wait(1.5); _FB_WAKE.clear(); continue          # 일이 생기면 바로 깨어남 (아니면 1.5초 뒤 다시 확인: 재시도 시각 대비)
            cfg = load_config()
            mock = ai_is_mock(cfg)
            if not mock and not any(cfg["keys"].values()):
                _fb_update(status="no_key", error="AI 키가 없어 조별 피드백을 만들지 못하고 있습니다. 교사 화면에서 키를 넣으면 바로 이어서 만듭니다.")
                time.sleep(3); continue
            for rid, r in need[:FB_PARALLEL - len(FB_INFLIGHT)]:
                FB_INFLIGHT.add(rid)
                _fb_update(status="running", progress=f"{rid}조 분석 중...", error=None)
                threading.Thread(target=_feedback_one, args=(rid, r, topic, mp, cfg, mock), daemon=True).start()
            time.sleep(0.5)
        except Exception:
            time.sleep(3)


def kick_feedback():
    """피드백 작업자를 (한 번만) 시작"""
    with _FB_LOCK:
        if not _FB_WORKER["started"]:
            _FB_WORKER["started"] = True
            threading.Thread(target=_feedback_worker, daemon=True).start()


def class_completion(s):
    """입장한 모든 조가 최종 제출(done)을 마쳤는지"""
    joined = [(rid, r) for rid, r in sorted(s["rooms"].items(), key=lambda x: int(x[0])) if _both_joined(r)]
    not_done = [rid for rid, r in joined if r["phase"] != "done"]
    return {"joined": len(joined), "done": len(joined) - len(not_done), "not_done": not_done,
            "all_done": bool(joined) and not not_done}


def _mock_room_result(rid, r):
    out = {"teams": {}, "students": []}
    for side in ("pro", "con"):
        out["teams"][side] = {"good": [f"{SIDE_KO_PY[side]}은 최초 주장에 출처를 제시함"], "improve": ["상대 근거에 대한 직접 반박이 부족함"]}
        for m in (r.get("members") or {}).get(side) or []:
            lab = member_label(m)
            n = sum(1 for x in r["qa"]["messages"] if writer_has(x.get("writer"), lab) and not x.get("auto"))
            rec = (f"자유토론에서 {n}회 발언하며 상대 주장의 전제를 질문함. 통계 자료를 근거로 입장을 제시함."
                   if n else "관찰 가능한 발언 기록이 부족함.")
            out["students"].append({"sid": m.get("sid"), "name": m.get("name"), "side": side, "record": rec, "count": n})
    return out


REPORT_RUNNING = set()     # 지금 생기부를 만드는 중인 반(아이디)


def run_ai_report(aid="current", only_failed=False):
    """백그라운드: 그 반의 끝난 조마다 분석 → 세특 초안 → (실명·학번은 AI에 안 보냄) → 결과 저장"""
    def set_status(**kw):
        src_update(aid, lambda st: st.setdefault("ai_report", {}).update(kw))
    try:
        cfg = load_config()
        mock = ai_is_mock(cfg)
        if not mock and not any(cfg["keys"].values()):
            set_status(status="error", error="등록된 AI 키가 없습니다. 교사 화면 맨 위 ② AI 연결에서 키를 넣어 주세요.")
            return
        st = src_load(aid)
        topic = st.get("active_topic") or ""
        mp = pii_map(st)                               # 실명·학번 → 닉네임 (AI 전송 직전 한 번 더 치환)
        ask = lambda system, user, **kw: _call_llm(dict(cfg, _json=True), system, scrub(user, mp), **kw)   # JSON 출력 모드
        rooms = [(rid, r) for rid, r in sorted(st["rooms"].items(), key=lambda x: int(x[0]))
                 if _both_joined(r) and r["phase"] == "done"]
        prev = (st.get("ai_report") or {}).get("result") or {}
        done_rooms = set(prev.get("rooms_done") or []) if only_failed else set()
        result = {"groups": [g for g in prev.get("groups", []) if g["room"] in done_rooms],
                  "students": [x for x in prev.get("students", []) if x["room"] in done_rooms],
                  "best": None, "rooms_done": sorted(done_rooms, key=int), "rooms_failed": {}, "generated_at": now()}
        reference = load_reference()
        todo = [(rid, r) for rid, r in rooms if rid not in done_rooms]
        def process_room(rid, r):
            """한 조 분석 (여러 조를 동시에 돌림)"""
            groups = []
            if mock:
                _mock_delay()
                g = _mock_room_result(rid, r)
            else:
                own = []
                for sd in ("pro", "con"):
                    for m in (r.get("members") or {}).get(sd) or []:
                        lab = member_label(m); st_list = student_statements(r, lab)
                        own.append(f"- {lab} ({SIDE_KO_PY[sd]}): " + (" | ".join(st_list) if st_list else "(작성자로 기록된 발언 없음)"))
                prompt = (f"과학탐구실험 성취기준:\n{cfg['standards']}\n\n"
                          f"팀별 잘한 점/아쉬운 점은 다음 5가지 기준으로 판단하세요:\n{RUBRIC_TEXT}\n\n"
                          f"참고 레퍼런스(기록 방식 참고용, 문장 복사 금지):\n{reference}\n\n"
                          f"토론 전체 기록(맥락 파악용):\n{room_transcript_for_ai(rid, r, topic)}\n\n"
                          "학생별로 본인이 작성자로 기록된 발언(세특의 유일한 근거, 학생은 닉네임으로 표시):\n" + "\n".join(own) + "\n\n"
                          "다음 JSON 형식으로만 답하세요:\n"
                          '{"teams":{"pro":{"good":["잘한 점"],"improve":["아쉬운 점"]},"con":{"good":[],"improve":[]}},'
                          '"students":[{"nick":"닉네임","side":"pro 또는 con","record":"한글 100~120자(공백 포함, 400바이트 이내), ~임./~함. 체"}]}\n'
                          "students에는 위 학생 목록을 빠짐없이 넣으세요. 세특 문장에 닉네임을 쓰지 마세요.")
                def _check_rep(g):
                    if not isinstance(g, dict) or not isinstance(g.get("students"), list) or not g["students"]:
                        raise AIError("AI 답에 학생별 세특(students)이 없습니다.")
                g = _ask_json(lambda extra: ask(AI_SYSTEM, prompt + extra), _check_rep, "생기부", lenient_last=True)
            for side in ("pro", "con"):
                t = _team_part(g.get("teams") if isinstance(g.get("teams"), dict) else g, side)
                groups.append({"room": rid, "side": side, "team": as_text(r.get(f"{side}_name")),
                                         "good": as_list(t.get("good")), "improve": as_list(t.get("improve"))})
            ai_by = {}
            for x in (g.get("students") or []):
                if not isinstance(x, dict):
                    continue
                for key in ("nick", "sid", "name"):
                    if x.get(key):
                        ai_by.setdefault(as_text(x[key]), x)
            rows = []
            for sd in ("pro", "con"):
                for m in (r.get("members") or {}).get(sd) or []:
                    lab = member_label(m)
                    stmts = student_statements(r, lab)
                    rec = as_text((ai_by.get(lab) or ai_by.get(str(m.get("sid", "")).strip()) or {}).get("record"))
                    if not stmts:
                        rec = NO_RECORD                  # 쓴 발언이 없으면 지어내지 않음
                    elif not rec:
                        rec = AI_MISSING                 # 발언은 했는데 AI가 빠뜨림 → '기록 부족'과 구분해 교사에게 알림
                    rows.append({"nick": lab, "sid": str(m.get("sid", "")).strip(), "name": str(m.get("name", "")).strip(),
                                 "room": rid, "side": sd, "count": len(stmts), "record": rec})
            # 400바이트 넘는 초안은 조마다 '한 번에 모아서' 줄이기 요청 (학생마다 따로 부르지 않음)
            long_rows = [x for x in rows if x["record"] not in (NO_RECORD, AI_MISSING) and neis_bytes(x["record"]) > SETEUK_MAX_BYTES]
            if long_rows and not mock:
                try:
                    req = "\n".join(f'{{"nick":"{x["nick"]}","record":{json.dumps(x["record"], ensure_ascii=False)}}}' for x in long_rows)
                    out = ask(AI_SYSTEM, f"다음 세특을 내용 추가 없이 각각 {SETEUK_MAX_BYTES}바이트(한글 약 120자) 이내로 줄이세요. ~임./~함. 체 유지.\n"
                                         f'JSON 배열로만 답하세요: [{{"nick":"닉네임","record":"줄인 세특"}}]\n\n{req}', max_tokens=1500)
                    got = out.strip()
                    try:
                        arr = json.loads(got[got.index("["): got.rindex("]") + 1])
                        short = {as_text(x.get("nick")): as_text(x.get("record")) for x in arr if isinstance(x, dict)}
                    except Exception:
                        short = {long_rows[0]["nick"]: got} if len(long_rows) == 1 else {}
                    for x in long_rows:
                        if short.get(x["nick"]):
                            x["record"] = short[x["nick"]]
                except Exception:
                    pass                                  # 실패해도 아래에서 문장 단위로 잘라 400바이트 이내로 맞춤
            for x in rows:
                if x["record"] != AI_MISSING:
                    x["record"] = fit_bytes(x["record"])
                x["bytes"] = neis_bytes(x["record"])
            return groups, rows

        # 모든 조를 동시에 분석 (예전엔 한 조씩 차례로 → 6개 조면 6배 기다림). 끝나는 대로 합치고, 한 조가 실패해도 나머지는 계속
        from concurrent.futures import ThreadPoolExecutor, as_completed
        set_status(progress=f"{len(todo)}개 조를 동시에 분석 중...", result=result)
        with ThreadPoolExecutor(max_workers=min(MAX_ROOMS, max(1, len(todo)))) as ex:
            futs = {ex.submit(process_room, rid, r): rid for rid, r in todo}
            for fut in as_completed(futs):
                rid = futs[fut]
                try:
                    groups, rows = fut.result()
                    result["groups"].extend(groups)
                    result["students"].extend(rows)
                    result["rooms_done"] = sorted(set(result["rooms_done"]) | {rid}, key=int)
                except Exception as e:                   # 한 조가 실패해도 나머지 조는 계속 → 실패한 조만 다시
                    result["rooms_failed"][rid] = str(e)
                set_status(progress=f"{len(result['rooms_done'])}/{len(rooms)}조 완료 (여러 조를 동시에 분석 중)", result=result)
        result["groups"].sort(key=lambda g: (int(g["room"]), 0 if g["side"] == "pro" else 1))
        result["students"].sort(key=lambda x: (x["sid"], x["name"]))    # 학번 → 이름순
        failed = result["rooms_failed"]
        set_status(status="done" if not failed else "partial", progress="완료" if not failed else f"{', '.join(failed)}조 실패 — [실패한 조 다시]를 누르세요",
                   result=result, error=None if not failed else "; ".join(f"{k}조: {v}" for k, v in failed.items()))
    except Exception as e:
        set_status(status="error", error=f"AI 분석 중 오류: {e}")
    finally:
        REPORT_RUNNING.discard(aid)


def _apply_ai_config(cfg, d):
    """AI 설정 화면에서 보낸 키·모델·성취기준을 설정에 반영하고 저장 (CFG_LOCK 안에서 호출)"""
    p = d.get("provider") if d.get("provider") in PROVIDERS else cfg["provider"]
    key = (d.get("api_key") or "").strip()
    switched = False
    if key:
        guessed = detect_provider(key)
        if guessed and guessed != p and not d.get("provider_fixed"):
            p, switched = guessed, True               # 키 모양이 다른 서비스면 그 서비스로 자동 전환
        cfg["keys"][p] = key
    cfg["provider"] = p
    if (d.get("model") or "").strip() and not switched:   # 자동 전환 시엔 이전 서비스의 모델 이름을 가져오지 않음
        cfg["models"][p] = d["model"].strip()
    if d.get("reset_model"):
        cfg["models"][p] = PROVIDERS[p]["model"]
    if d.get("clear_key"):                            # 이 서비스 키 지우기
        cfg["keys"].pop(p, None)
        cfg.get("verified_map", {}).pop(p, None)
    if d.get("standards") is not None:
        cfg["standards"] = d["standards"]
    save_config({k: v for k, v in cfg.items() if k not in COMPUTED_CFG})


@app.route("/api/teacher/ai/config", methods=["GET", "POST"])
def api_ai_config():
    cfg = load_config()
    if request.method == "POST":
        CFG_LOCK.acquire()
        try:
            cfg = load_config()
            _apply_ai_config(cfg, request.json or {})
        finally:
            CFG_LOCK.release()
        cfg = load_config()
    hint = lambda k: ((k[:6] + "…" + k[-4:]) if len(k) > 12 else ("mock" if k == "mock" else "")) if k else ""
    order = [p for p in PROVIDER_ORDER if cfg["keys"].get(p)]
    return jsonify({"provider": cfg["provider"], "model": cfg["model"], "standards": cfg["standards"],
                    "verified_ok": cfg["verified_ok"], "verified_list": cfg["verified_list"],
                    "order": order, "cooling": [p for p in order if PROVIDER_HEALTH.get(p, 0) > now()],
                    "has_key": bool(cfg["api_key"]), "key_hint": hint(cfg["api_key"]),
                    "providers": {p: {**info, "saved": bool(cfg["keys"].get(p)), "saved_hint": hint(cfg["keys"].get(p, "")),
                                      "model_now": cfg["models"][p], "verified": p in cfg["verified_list"]}
                                  for p, info in PROVIDERS.items()}})


@app.route("/api/team_feedback", methods=["GET"])
def api_team_feedback():
    """학생용: 우리 조(찬성·반대) 피드백 — 시상식이 열린 뒤에만 공개"""
    kick_feedback()
    client_id = request.args.get("client_id")
    with LOCK:
        s = load_state()
        cinfo = s["clients"].get(client_id)
        if not cinfo:
            return jsonify({"ok": False, "error": "참여 정보가 없습니다."})
        fb = s.get("team_feedback") or {}
        rid = str(cinfo["room"])
        revealed = bool((s.get("showcase") or {}).get("revealed"))
        room_done = s["rooms"][rid]["phase"] == "done"
        items = {sd: (fb.get("items") or {}).get(f"{rid}|{sd}") for sd in ("pro", "con")}
        ready = all(items.values())
        return jsonify({"ok": True, "room": rid, "my_side": cinfo["side"], "revealed": revealed, "ready": ready,
                        "enabled": feedback_enabled(s),
                        "status": fb.get("status"), "failed": (fb.get("failed") or {}).get(rid),
                        "retrying": bool(isinstance((fb.get("failed") or {}).get(rid), dict) and (fb.get("failed") or {}).get(rid).get("transient")
                                         and (fb.get("failed") or {}).get(rid).get("attempts", 0) < FB_MAX_ATTEMPTS),
                        "items": items if room_done else None,       # 우리 조가 끝나면 바로 공개
                        "rubric": [{"name": n, "good": g, "bad": b} for n, g, b in RUBRIC]})


def team_ranking(st):
    """토론 1등 '팀' 정하기 (조가 아니라 조+찬반 팀 단위, AI를 다시 부르지 않음)
    5가지 기준 '잘함' 개수 → (동점) 근거(숫자·출처)가 담긴 자유토론 발언 수 → 그 조의 따봉 수 → 조 번호"""
    items = ((st.get("team_feedback") or {}).get("items") or {})
    votes = {}
    for v in ((st.get("showcase") or {}).get("votes") or {}).values():
        k = str(v).split("|")[0]; votes[k] = votes.get(k, 0) + 1
    total_votes = sum(votes.values())
    rows = []
    for rid, r in sorted(st["rooms"].items(), key=lambda x: int(x[0])):
        if not (_both_joined(r) and r["phase"] == "done"):
            continue
        for sd in ("pro", "con"):
            it = items.get(f"{rid}|{sd}")
            if not it:
                continue
            good = [c.get("name") for c in (it.get("criteria") or []) if c.get("result") == "잘함"]
            crit = sum(1 for m in r["qa"]["messages"] if m.get("side") == sd and not m.get("auto") and _is_crit_message(m["text"]))
            reasons = [f"5가지 기준 중 '잘함' {len(good)}개" + (f" ({', '.join(good)})" if good else ""),
                       f"근거(숫자·출처)가 담긴 자유토론 발언 {crit}개"]
            if total_votes:
                reasons.append(f"{rid}조 따봉 {votes.get(rid, 0)}표 (전체 {total_votes}표)")
            rows.append({"room": rid, "side": sd, "team": SIDE_KO_PY[sd], "members": [member_label(m) for m in ((r.get("members") or {}).get(sd) or [])],
                         "good_n": len(good), "crit": crit, "votes": votes.get(rid, 0), "good": as_text(it.get("good")), "reasons": reasons})
    rows.sort(key=lambda x: (-x["good_n"], -x["crit"], -x["votes"], int(x["room"]), 0 if x["side"] == "pro" else 1))
    for i, x in enumerate(rows, 1):
        x["rank"] = i
    return rows


def ai_connected():
    """AI 키가 등록돼 있는지 (모의 모드 포함)"""
    if os.environ.get("DEBATE_AI_MOCK") == "1":
        return True
    try:
        return bool(provider_chain(load_config()))
    except Exception:
        return False


@app.route("/api/teacher/team_feedback_full", methods=["GET"])
def api_team_feedback_full():
    """교사 화면 ②: 모든 조·팀의 AI 피드백 전체 + 토론 1등 팀과 이유"""
    with LOCK:
        st = load_state()
    fbs = st.get("team_feedback") or {}
    items, failed = fbs.get("items") or {}, fbs.get("failed") or {}
    rooms = []
    for rid, r in sorted(st["rooms"].items(), key=lambda x: int(x[0])):
        if not (_both_joined(r) and r["phase"] == "done"):
            continue
        teams = {}
        for sd in ("pro", "con"):
            it = items.get(f"{rid}|{sd}") or {}
            teams[sd] = {"team": SIDE_KO_PY[sd], "members": [member_label(m) for m in ((r.get("members") or {}).get(sd) or [])],
                         "ready": bool(it), "good": as_text(it.get("good")), "improve": as_text(it.get("improve")), "closing": as_text(it.get("closing")),
                         "criteria": [{"name": c.get("name"), "result": c.get("result"), "comment": as_text(c.get("comment"))} for c in (it.get("criteria") or [])]}
        fail = failed.get(rid) or {}
        rooms.append({"room": rid, "pro": teams["pro"], "con": teams["con"], "failed": as_text(fail.get("msg")) if fail and not teams["pro"]["ready"] else ""})
    ranking = team_ranking(st)
    return jsonify({"enabled": feedback_enabled(st), "ai_connected": ai_connected(), "consent": consent_ok(),
                    "rooms": rooms, "best": ranking[0] if ranking else None, "ranking": ranking})


@app.route("/api/teacher/team_feedback", methods=["GET"])
def api_teacher_team_feedback():
    kick_feedback()
    with LOCK:
        s = load_state()
        fb = s.get("team_feedback") or {}
        items = fb.get("items") or {}
        joined = [rid for rid, r in s["rooms"].items() if _both_joined(r)]
        done_rooms = [rid for rid in joined if s["rooms"][rid]["phase"] == "done"]
        ready_rooms = sorted([rid for rid in done_rooms if all(f"{rid}|{sd}" in items for sd in ("pro", "con"))], key=int)
        return jsonify({"status": fb.get("status"), "progress": fb.get("progress"), "error": fb.get("error"),
                        "engine": fb.get("engine"), "ready_rooms": ready_rooms, "done_rooms": len(done_rooms),
                        "joined_rooms": len(joined), "failed": fb.get("failed") or {},
                        "revealed": bool((s.get("showcase") or {}).get("revealed")), "enabled": feedback_enabled(s)})


def _test_one(cfg, p):
    """그 서비스 하나만 짧게 호출 (자동 전환 없이) → 성공하면 연결 확인 기록"""
    key, model = cfg["keys"].get(p, ""), cfg["models"][p]
    label = PROVIDERS[p]["label"]
    if not key:
        return {"provider": p, "ok": False, "message": f"{label}: 키 없음"}
    if key == "mock":
        cfg.setdefault("verified_map", {})[p] = _sig_for(p, model, key)
        return {"provider": p, "ok": True, "message": f"✅ {label}: 모의 모드 키입니다 (실제 AI 호출 없음)."}
    c2 = dict(cfg, provider=p, api_key=key, model=model, _timeout=15)
    for attempt in range(2):
        try:
            a = time.time()
            out = _call_llm_once(c2, "짧게 답하세요.", "연결 확인입니다. '확인'이라고만 답하세요.", 50)
            cfg.setdefault("verified_map", {})[p] = _sig_for(p, model, key)
            PROVIDER_HEALTH.pop(p, None)
            warn = "" if consent_ok() else " ⚠ 단, 개인정보 처리 안내에 아직 동의하지 않아 피드백·생기부는 만들어지지 않아요 — 화면을 새로고침해 동의해 주세요."
            return {"provider": p, "ok": True, "message": f"✅ {label} · {model} 연결 성공 ({time.time() - a:.1f}초, 응답: {out.strip()[:10]}){warn}"}
        except AIError as e:
            if e.transient and attempt == 0:
                time.sleep(2); continue
            cfg.setdefault("verified_map", {}).pop(p, None)
            return {"provider": p, "ok": False, "message": f"❌ {label} 연결 실패 — {e}"}
        except Exception as e:
            return {"provider": p, "ok": False, "message": f"❌ {label} 연결 실패: {e}"}


def _save_verified(tested_cfg, providers):
    """연결 확인 결과(verified_map)만 지금 설정 파일에 반영 — 확인하는 동안 저장된 키·동의는 그대로"""
    vm = tested_cfg.get("verified_map") or {}
    with CFG_LOCK:
        cfg = load_config()
        cur = cfg.setdefault("verified_map", {})
        for p in providers:
            if p in vm and cfg["keys"].get(p) == tested_cfg["keys"].get(p):   # 그 사이 키가 바뀌었으면 옛 결과는 버림
                cur[p] = vm[p]
            else:
                cur.pop(p, None)
        save_config({k: v for k, v in cfg.items() if k not in COMPUTED_CFG})


@app.route("/api/teacher/ai/test", methods=["POST"])
def api_ai_test():
    """지금 선택한 서비스의 키·모델이 작동하는지 확인"""
    cfg = load_config()
    r = _test_one(cfg, cfg["provider"])
    _save_verified(cfg, [cfg["provider"]])
    return jsonify({"ok": r["ok"], "message": r["message"], "error": None if r["ok"] else r["message"]})


@app.route("/api/teacher/ai/test_all", methods=["POST"])
def api_ai_test_all():
    """저장된 키를 모두 테스트 (Gemini → Groq → Claude → GPT 순서)"""
    cfg = load_config()
    ps = [p for p in PROVIDER_ORDER if cfg["keys"].get(p)]
    results = [None] * len(ps)
    def run(i, p):
        results[i] = _test_one(cfg, p)
    th = [threading.Thread(target=run, args=(i, p)) for i, p in enumerate(ps)]   # 동시에 확인 → 가장 느린 것 기준 15초 이내
    [t.start() for t in th]; [t.join() for t in th]
    _save_verified(cfg, ps)
    return jsonify({"ok": any(r["ok"] for r in results), "results": results})


@app.route("/api/teacher/ai/run", methods=["POST"])
def api_ai_run():
    d = request.json or {}
    aid = d.get("source") or "current"
    if aid in REPORT_RUNNING:
        return jsonify({"ok": False, "error": "이미 이 반의 생기부를 만드는 중입니다."})
    try:
        st = src_load(aid)
    except Exception:
        return jsonify({"ok": False, "error": "보관된 반 기록을 찾을 수 없습니다."})
    if not seteuk_enabled(st):
        return jsonify({"ok": False, "error": "이 수업은 '개인별 생기부'를 끈 채로 진행해서 발언별 작성자 기록이 없어요. 생기부 대신 [📊 조별 피드백·1위 받기]를 이용하세요."})
    if aid == "current":
        comp = class_completion(st)
        if not comp["all_done"]:
            wait = ", ".join(f"{x}조" for x in comp["not_done"]) or "입장한 조 없음"
            return jsonify({"ok": False, "error": f"모든 조가 최종 제출을 마친 뒤에 만들 수 있습니다. (아직: {wait})"})
    if not any(_both_joined(r) and r["phase"] == "done" for r in st["rooms"].values()):
        return jsonify({"ok": False, "error": "토론을 마친 조가 없습니다."})
    only_failed = bool(d.get("only_failed")) and ((st.get("ai_report") or {}).get("result") or {}).get("rooms_failed")
    REPORT_RUNNING.add(aid)
    src_update(aid, lambda s2: s2.__setitem__("ai_report", {**(s2.get("ai_report") or {}), "status": "running", "progress": "시작...", "error": None}))
    threading.Thread(target=run_ai_report, args=(aid, bool(only_failed)), daemon=True).start()
    return jsonify({"ok": True})


@app.route("/api/teacher/ai/status", methods=["GET"])
def api_ai_status():
    aid = request.args.get("source") or "current"
    try:
        st = src_load(aid)
    except Exception:
        return jsonify({"status": "idle", "error": "기록 없음"})
    rep = dict(st.get("ai_report") or {"status": "idle"})
    if rep.get("status") == "running" and aid not in REPORT_RUNNING:     # 서버를 껐다 켜서 멈춘 작업
        rep["status"] = "partial" if (rep.get("result") or {}).get("rooms_done") else "idle"
    rep["completion"] = class_completion(st)
    return jsonify(rep)


def build_xlsx(sheets):
    """엑셀(.xlsx) 파일을 직접 만듦 — 추가 설치(openpyxl) 없이 동작. sheets = [(시트 이름, 제목줄, 행들, 열 너비들)]
    머리글은 굵게+노란 칸, 모든 칸 줄바꿈·위쪽 정렬 (엑셀·구글 시트에서 그대로 열림)"""
    from xml.sax.saxutils import escape
    def col(i):
        n, out = i + 1, ""
        while n:
            n, rem = divmod(n - 1, 26); out = chr(65 + rem) + out
        return out
    def cell(ref, v, style):
        if isinstance(v, bool):
            v = "예" if v else ""
        if isinstance(v, (int, float)):
            return f'<c r="{ref}" s="{style}"><v>{v}</v></c>'
        t = escape(as_text(v))
        return f'<c r="{ref}" s="{style}" t="inlineStr"><is><t xml:space="preserve">{t}</t></is></c>'
    mem = io.BytesIO()
    with zipfile.ZipFile(mem, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("[Content_Types].xml", '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                   '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
                   '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
                   '<Default Extension="xml" ContentType="application/xml"/>'
                   '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
                   '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>'
                   + "".join(f'<Override PartName="/xl/worksheets/sheet{i + 1}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>' for i in range(len(sheets)))
                   + '</Types>')
        z.writestr("_rels/.rels", '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                   '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
                   '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>')
        z.writestr("xl/workbook.xml", '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                   '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>'
                   + "".join(f'<sheet name="{escape(re.sub(r"[][:*?/\\\\]", "", n)[:31])}" sheetId="{i + 1}" r:id="rId{i + 1}"/>' for i, (n, *_r) in enumerate(sheets))
                   + '</sheets></workbook>')
        z.writestr("xl/_rels/workbook.xml.rels", '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                   '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
                   + "".join(f'<Relationship Id="rId{i + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet{i + 1}.xml"/>' for i in range(len(sheets)))
                   + f'<Relationship Id="rId{len(sheets) + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>')
        z.writestr("xl/styles.xml", '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                   '<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
                   '<fonts count="2"><font><sz val="11"/><name val="맑은 고딕"/></font><font><b/><sz val="11"/><name val="맑은 고딕"/></font></fonts>'
                   '<fills count="3"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill>'
                   '<fill><patternFill patternType="solid"><fgColor rgb="FFFFF1C2"/><bgColor indexed="64"/></patternFill></fill></fills>'
                   '<borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders>'
                   '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>'
                   '<cellXfs count="3"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>'
                   '<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0" applyAlignment="1"><alignment wrapText="1" vertical="top"/></xf>'
                   '<xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0" applyFont="1" applyFill="1" applyAlignment="1"><alignment wrapText="1" vertical="top"/></xf></cellXfs>'
                   '<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>'
                   '</styleSheet>')
        for i, (name, headers, rows, widths) in enumerate(sheets):
            cols = "".join(f'<col min="{k + 1}" max="{k + 1}" width="{w}" customWidth="1"/>' for k, w in enumerate(widths))
            body = [f'<row r="1">' + "".join(cell(f"{col(k)}1", h, 2) for k, h in enumerate(headers)) + "</row>"]
            for n, row in enumerate(rows, start=2):
                body.append(f'<row r="{n}">' + "".join(cell(f"{col(k)}{n}", v, 1) for k, v in enumerate(row)) + "</row>")
            z.writestr(f"xl/worksheets/sheet{i + 1}.xml", '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                       '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
                       f'<sheetViews><sheetView workbookViewId="0"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews>'
                       f'<cols>{cols}</cols><sheetData>{"".join(body)}</sheetData></worksheet>')
    return mem.getvalue()


def class_ranking(st):
    """1위 조 정하기 (AI를 다시 부르지 않음)
    ① 따봉 투표를 했으면: 득표 수 → (동점) 근거 담긴 발언 수 → 조 번호
    ② 투표가 없으면: 팀별 AI 피드백 5가지 기준 '잘함' 개수(찬성+반대) → 근거 담긴 발언 수 → 조 번호"""
    rooms = [(rid, r) for rid, r in sorted(st["rooms"].items(), key=lambda x: int(x[0])) if _both_joined(r) and r["phase"] == "done"]
    votes = {}
    for v in ((st.get("showcase") or {}).get("votes") or {}).values():
        k = str(v).split("|")[0]; votes[k] = votes.get(k, 0) + 1
    items = ((st.get("team_feedback") or {}).get("items") or {})
    rows = []
    for rid, r in rooms:
        good = {sd: [c["name"] for c in ((items.get(f"{rid}|{sd}") or {}).get("criteria") or []) if c.get("result") == "잘함"] for sd in ("pro", "con")}
        crit = sum(1 for m in r["qa"]["messages"] if not m.get("auto") and _is_crit_message(m["text"]))
        rows.append({"room": rid, "votes": votes.get(rid, 0), "good": good, "good_n": len(good["pro"]) + len(good["con"]), "crit": crit,
                     "has_fb": all(f"{rid}|{sd}" in items for sd in ("pro", "con"))})
    use_votes = sum(votes.values()) > 0
    rows.sort(key=lambda x: ((-x["votes"], -x["crit"], int(x["room"])) if use_votes else (-x["good_n"], -x["crit"], int(x["room"]))))
    for i, x in enumerate(rows, 1):
        x["rank"] = i
    return {"method": "votes" if use_votes else ("rubric" if any(x["has_fb"] for x in rows) else "crit"), "rows": rows, "total_votes": sum(votes.values())}


@app.route("/api/teacher/feedback_xlsx", methods=["GET"])
def api_feedback_xlsx():
    """교사용: 모든 조의 팀별 피드백을 한 파일로 + 1위 조와 그 근거 (학번·이름 없이 닉네임만)"""
    aid = request.args.get("source") or "current"
    try:
        st = src_load(aid)
    except Exception:
        return Response("보관된 반 기록을 찾을 수 없습니다.", status=404, mimetype="text/plain; charset=utf-8")
    try:
        items = ((st.get("team_feedback") or {}).get("items") or {})
        rk = class_ranking(st)
        if not rk["rows"]:
            return Response("토론을 마친 조가 없습니다.", status=404, mimetype="text/plain; charset=utf-8")
        fb_rows = []
        for x in sorted(rk["rows"], key=lambda y: int(y["room"])):
            r = st["rooms"][x["room"]]
            for sd in ("pro", "con"):
                it = items.get(f"{x['room']}|{sd}") or {}
                crit = {c.get("name"): c for c in (it.get("criteria") or [])}
                fb_rows.append([f"{x['room']}조", SIDE_KO_PY[sd], ", ".join(member_label(m) for m in ((r.get("members") or {}).get(sd) or [])),
                                as_text((r["final"].get(sd) or {}).get("text")), as_text((r["selfcheck"].get(sd) or {}).get("text")),
                                as_text(it.get("good")) or ("(AI 피드백 없음)" if not it else ""), as_text(it.get("improve"))]
                               + [(f"{crit[n].get('result')} — {as_text(crit[n].get('comment'))}" if n in crit else "") for n in RUBRIC_NAMES])
        top = rk["rows"][0]
        tr = team_ranking(st)
        how = {"votes": f"따봉 투표 결과 (총 {rk['total_votes']}표). 동점이면 근거(숫자·출처)가 담긴 발언이 많은 조가 앞섭니다.",
               "rubric": "따봉 투표가 없어 팀별 AI 피드백의 5가지 기준 '잘함' 개수(찬성+반대)로 정했습니다. 동점이면 근거가 담긴 발언 수로 정합니다.",
               "crit": "투표와 AI 피드백이 없어 근거(숫자·출처)가 담긴 발언 수로 정했습니다."}[rk["method"]]
        def reason(x):
            r = st["rooms"][x["room"]]
            parts = []
            if rk["method"] == "votes":
                parts.append(f"따봉 {x['votes']}표 (전체 {rk['total_votes']}표 중)")
            if x["has_fb"]:
                parts.append(f"5가지 기준 '잘함' {x['good_n']}개 — 찬성: {', '.join(x['good']['pro']) or '없음'} / 반대: {', '.join(x['good']['con']) or '없음'}")
            parts.append(f"근거(숫자·출처)가 담긴 자유토론 발언 {x['crit']}개")
            for sd in ("pro", "con"):
                g = as_text((items.get(f"{x['room']}|{sd}") or {}).get("good"))
                if g:
                    parts.append(f"{SIDE_KO_PY[sd]} 잘한 점: {g}")
            return "\n".join(parts)
        rank_rows = [[x["rank"], f"{x['room']}조", x["votes"] if rk["method"] == "votes" else "-", x["good_n"] if x["has_fb"] else "-", x["crit"], reason(x)] for x in rk["rows"]]
        sheets = [
            ("🏆 1위 조", ["항목", "내용"], [["🏆 1위", f"{top['room']}조 (찬성: {as_text(st['rooms'][top['room']].get('pro_name'))} / 반대: {as_text(st['rooms'][top['room']].get('con_name'))})"],
                                            ["선정 방법", how], ["근거", reason(top)]]
             + ([["🏆 토론 1등 팀", f"{tr[0]['room']}조 {tr[0]['team']} ({', '.join(tr[0]['members'])}) — 잘한 점: {tr[0]['good']}"],
                 ["1등 팀 이유", " · ".join(tr[0]["reasons"]) + " (5가지 기준 '잘함' 개수 → 근거 담긴 발언 수 → 따봉 순)"]] if tr else []), [14, 100]),
            ("조별 순위", ["순위", "조", "따봉", "'잘함' 개수", "근거 담긴 발언", "근거"], rank_rows, [6, 6, 7, 10, 12, 90]),
            ("조별 피드백", ["조", "팀", "팀원(닉네임)", "최종 결론(학생)", "자기 피드백(학생)", "AI: 잘한 점", "AI: 아쉬운 점"] + [f"기준: {n}" for n in RUBRIC_NAMES],
             fb_rows, [6, 7, 20, 40, 40, 40, 40] + [34] * len(RUBRIC_NAMES)),
        ]
        data = build_xlsx(sheets)
    except Exception as e:
        import traceback; traceback.print_exc()
        return Response(f"조별 피드백 파일을 만드는 중 문제가 생겼어요: {e}", status=500, mimetype="text/plain; charset=utf-8")
    fname = f"조별피드백_{st.get('class_name') or '반'}_{time.strftime('%Y%m%d')}.xlsx"
    return Response(data, mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    headers={"Content-Disposition": "attachment; filename=" + urllib_quote(fname) + "; filename*=UTF-8''" + urllib_quote(fname)})


@app.route("/api/teacher/ai/xlsx", methods=["GET"])
def api_ai_xlsx():
    aid = request.args.get("source") or "current"
    try:
        st = src_load(aid)
    except Exception:
        return Response("보관된 반 기록을 찾을 수 없습니다.", status=404, mimetype="text/plain; charset=utf-8")
    res = (st.get("ai_report") or {}).get("result")
    if not res or not res.get("students"):
        return Response("아직 생기부 결과가 없습니다. [생기부 만들기]를 먼저 눌러주세요.", status=404, mimetype="text/plain; charset=utf-8")
    try:
        # 학번·이름은 AI에 보낸 적 없음 → 여기(교사 PC)서 명단으로 복원. 명단 수정(오타 고침)도 반영
        roster = {(str(r0), sd0, member_label(m)): m for r0, rr in st["rooms"].items() for sd0 in ("pro", "con")
                  for m in ((rr.get("members") or {}).get(sd0) or [])}
        studs = []
        for x in res["students"]:
            m = roster.get((str(x.get("room")), x.get("side"), as_text(x.get("nick"))), {})
            rec = as_text(x.get("record"))
            studs.append({"sid": as_text(m.get("sid", x.get("sid", ""))), "name": as_text(m.get("name", x.get("name", ""))),
                          "nick": as_text(x.get("nick")), "room": as_text(x.get("room")), "side": x.get("side"),
                          "count": int(x.get("count") or 0), "record": rec, "bytes": neis_bytes(rec)})
        studs.sort(key=lambda x: (x["sid"], x["name"]))
        sheets = [
            ("생기부(세특) 초안", ["학번", "이름", "닉네임", "조", "입장", "작성 횟수", "세부능력 및 특기사항 (초안 · 교사 검토 필요)", "바이트(400 이내)"],
             [[x["sid"], x["name"], x["nick"], f"{x['room']}조", SIDE_KO_PY.get(x["side"], ""), x["count"], x["record"], x["bytes"]] for x in studs],
             [10, 10, 12, 6, 8, 9, 90, 12]),
            ("조별 총평", ["조", "팀", "팀원(닉네임)", "잘한 점", "아쉬운 점"],
             [[f"{as_text(g.get('room'))}조", SIDE_KO_PY.get(g.get("side"), ""), as_text(g.get("team")), as_text(g.get("good")), as_text(g.get("improve"))]
              for g in res.get("groups") or []], [6, 9, 36, 55, 55]),
        ]
        data = build_xlsx(sheets)
    except Exception as e:
        import traceback; traceback.print_exc()
        return Response(f"엑셀을 만드는 중 문제가 생겼어요: {e}\n(생기부 결과는 저장돼 있으니 [생기부 만들기]를 다시 누르거나 검은 창의 메시지를 알려주세요)",
                        status=500, mimetype="text/plain; charset=utf-8")
    fname = f"생기부_{st.get('class_name') or '반'}_{time.strftime('%Y%m%d')}.xlsx"
    return Response(data, mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    headers={"Content-Disposition": "attachment; filename=" + urllib_quote(fname) + "; filename*=UTF-8''" + urllib_quote(fname)})


# ---------------- teacher APIs ----------------

@app.route("/api/teacher/state", methods=["GET"])
def teacher_state():
    with LOCK:
        s = load_state()
        remaining = remaining_seconds_of(s)
        expired = remaining is not None and remaining <= 0
        for r in s["rooms"].values():
            tick_room(r, expired)
        showcase_tick(s)
        ensure_join_code(s)
        save_state(s)                     # 표시용 값을 붙이기 전에 저장 (파일에 쓸데없는 값이 쌓이지 않게)
        t = now()
        for rid, r in s["rooms"].items():
            r["phase_remaining_seconds"] = compute_phase_remaining(r)
            r["warning_levels"] = {"pro": side_warning_level(r, "pro"), "con": side_warning_level(r, "con")}
            if r["phase"] == "qa" and r["qa"]["turn_started_at"]:
                qts = qa_turn_status(r)
                r["qa_turn_remaining_seconds"] = qts["remaining"]
                r["qa_turn_warning"] = qts["warning"]
                r["qa_clock"] = qa_clock(r)
            else:
                r["qa_turn_remaining_seconds"] = None
                r["qa_turn_warning"] = False
        comp = class_completion(s)
        sc0 = s.get("showcase") or {}
        stage = ("before" if not s.get("class_started_at") else
                 "debate" if not comp["all_done"] else
                 "feedback" if not showcase_enabled(s) else
                 "ceremony" if sc0.get("revealed") else
                 "vote" if showcase_is_open(s) else "confirm")
        return jsonify({
            "class_stage": stage, "completion": comp, "confirm": confirm_status(s),
            "student_url": student_url(),
            "roster": roster_status(s),
            "internet": {"on": INTERNET_MODE, "code": s.get("join_code") or "", **{k: TUNNEL.get(k, "") for k in ("status", "url", "short", "short_msg", "msg")}},
            "topics": s["topics"], "active_topic": s["active_topic"],
            "class_started_at": s["class_started_at"], "remaining_seconds": remaining, "elapsed_seconds": elapsed_seconds_of(s),
            "class_duration_min": s["class_duration_min"],
            # 교사 표에 필요한 요약만 (발언·주장 전문은 안 보냄: 2초마다 받는 양을 크게 줄임). 전문은 PDF/기록 화면에서 따로 받음
            "rooms": {rid: {"phase": r["phase"], "pro": r["pro"], "con": r["con"], "pro_name": r.get("pro_name"), "con_name": r.get("con_name"),
                            "forced": r.get("forced"), "phase_remaining_seconds": r.get("phase_remaining_seconds"),
                            "warning_levels": r.get("warning_levels"), "qa_turn_remaining_seconds": r.get("qa_turn_remaining_seconds"),
                            "qa": {"n": len(r["qa"]["messages"]), "current_turn": r["qa"].get("current_turn"), "timeout_counts": r["qa"].get("timeout_counts")}}
                      for rid, r in s["rooms"].items()},
            "class_name": s.get("class_name") or "", "feedback_enabled": feedback_enabled(s), "paste_block": bool(s.get("paste_block")),
            "seteuk_enabled": seteuk_enabled(s), "room_count": room_count(s), "max_rooms": MAX_ROOMS,
            "time_cfg": time_cfg_minutes(s), "time_default": {k: v // 60 for k, v in DEFAULT_PHASE_DURATION.items()},
            "time_limits": TIME_LIMITS, "turn_cap_min": QA_TURN_CAP // 60,
            "assign_mode": s.get("assign_mode"),
            "entered": {"pro": sum(1 for r in s["rooms"].values() if r["pro"]), "con": sum(1 for r in s["rooms"].values() if r["con"])},
            "phase_duration": PHASE_DURATION,
            "server_time": t,
            "showcase": {"enabled": showcase_enabled(s), "vote_left": vote_left(s),
                         "open": showcase_is_open(s), "revealed": bool((s.get("showcase") or {}).get("revealed")),
                         "voted": len((s.get("showcase") or {}).get("votes") or {}), "total": len(showcase_rooms(s)) * 2,
                         "winner": showcase_winner(s)},
            "ai_status": (s.get("ai_report") or {}).get("status", "idle"),
        })


@app.route("/api/teacher/add_topic", methods=["POST"])
def teacher_add_topic():
    topic = (request.json.get("topic") or "").strip()
    with LOCK:
        s = load_state()
        if not topic:
            return jsonify({"ok": False, "error": "빈 주제는 추가할 수 없습니다."})
        if topic not in s["topics"]:
            s["topics"].append(topic)
        save_state(s)
    return jsonify({"ok": True})


@app.route("/api/teacher/set_topic", methods=["POST"])
def teacher_set_topic():
    topic = request.json.get("topic")
    with LOCK:
        s = load_state()
        s["active_topic"] = topic
        save_state(s)
    return jsonify({"ok": True})


@app.route("/api/teacher/start_class", methods=["POST"])
def teacher_start_class():
    """수업 시작: 토론 주제와 AI 연결(연결 테스트 통과)이 준비돼야 시작. 입장해 기다리던 조는 모두 동시에 토론 시작"""
    data = request.json or {}
    duration = data.get("duration_min")                 # 기본: 수업 전체 시간 제한 없음 (선택 시에만 사용)
    with LOCK:
        s = load_state()
        if not consent_ok():
            return jsonify({"ok": False, "need_consent": True, "error": "개인정보 처리 안내에 먼저 동의해 주세요. (교사 화면 첫 화면)"})
        if not s.get("active_topic"):
            return jsonify({"ok": False, "error": "토론 주제를 먼저 정해 주세요."})
        if data.get("class_name"):
            s["class_name"] = str(data["class_name"]).strip()[:20]
        if s.get("class_started_at") and not data.get("restart"):
            return jsonify({"ok": False, "need_new_class": True,
                            "error": "이전 수업 기록이 남아 있어요. [📦 지난 수업 보관하고 새 수업 준비]를 먼저 눌러 주세요."})
        cfg = load_config()
        ai_ready = cfg.get("verified_ok") or ai_is_mock(cfg)
        assign_info = None
        if data.get("assign") == "random":             # 찬반 랜덤 배정 (입장은 그대로, 상대 조만 무작위)
            waiting = [r for r in s["rooms"].values() if r["phase"] == "waiting"]
            n_pro, n_con = sum(1 for r in waiting if r["pro"]), sum(1 for r in waiting if r["con"])
            if not n_pro or not n_con:
                return jsonify({"ok": False, "need_teams": True,
                                "error": f"랜덤 배정은 찬성팀과 반대팀이 모두 입장한 뒤에 할 수 있어요. (지금 찬성 {n_pro}팀 · 반대 {n_con}팀) "
                                         "학생들이 입장한 뒤에 다시 눌러 주세요. 수업은 아직 시작되지 않았어요."})
            assign_info = random_assign(s)
        s["assign_mode"] = "random" if (assign_info and assign_info["pairs"]) else "as_chosen"
        s["class_started_at"] = now()
        s["class_duration_min"] = duration
        s["class_without_ai"] = not ai_ready          # AI 없이 시작해도 토론은 진행 (피드백만 '준비 중')
        started = []
        for rid, room in s["rooms"].items():
            if room["pro"] and room["con"] and room["phase"] == "waiting":
                start_room_debate(room)
                started.append(rid)
        save_state(s)
    out = {"ok": True, "started_rooms": sorted(started, key=int)}
    if assign_info:
        msg = f"🎲 찬반 랜덤 배정: {assign_info['pairs']}개 조를 새로 짝지었어요."
        if assign_info["left"]:
            msg += f" 상대가 없는 팀이 {len(assign_info['left'])}팀 있어요(찬반 팀 수가 달라 입장은 바꾸지 않았어요) — 교사 판단으로 조정해 주세요."
        if assign_info["renamed"]:
            msg += " 닉네임이 겹쳐 바꾼 팀: " + ", ".join(f"{o}→{n}({r}조)" for o, n, r in assign_info["renamed"])
        out.update(assign=assign_info, message=msg)
    return jsonify(out)


def random_assign(s):
    """찬반 랜덤 배정: 입장한 팀의 '찬성/반대'는 그대로 두고, 상대 조만 무작위로 다시 짝지음.
    - 찬반 팀 수가 다르면 남는 팀은 입장을 바꾸지 않고 대기(교사에게 안내) — 준비한 입장과 반대로 토론하는 일 방지
    - 한 조 안에서 닉네임이 겹치지 않게(작성자 기록·생기부가 섞이지 않게), 가능하면 원래 짝과 다시 만나지 않게"""
    teams = {"pro": [], "con": []}
    for rid, r in sorted(s["rooms"].items(), key=lambda x: int(x[0])):
        if r["phase"] != "waiting":
            continue
        for sd in ("pro", "con"):
            if r[sd]:
                teams[sd].append({"cid": r[sd], "members": [dict(m) for m in ((r.get("members") or {}).get(sd) or [])],
                                  "avatar": (r.get("avatar") or {}).get(sd), "from": rid})
    best = None
    for _ in range(400):
        random.shuffle(teams["pro"]); random.shuffle(teams["con"])
        pairs = list(zip(teams["pro"], teams["con"]))
        clash = sum(1 for a, b in pairs if {m.get("nick") for m in a["members"]} & {m.get("nick") for m in b["members"]})
        same = sum(1 for a, b in pairs if a["from"] == b["from"])
        score = clash * 100 + same
        if best is None or score < best[0]:
            best = (score, [(dict(a), dict(b)) for a, b in pairs])
        if score == 0:
            break
    pairs = best[1] if best else []
    n = len(pairs)
    left = teams["pro"][n:] + teams["con"][n:] if len(teams["pro"]) != len(teams["con"]) else []
    left = [t for t in (teams["pro"] + teams["con"]) if all(t["cid"] not in (a["cid"], b["cid"]) for a, b in pairs)]
    renamed = []
    waiting_ids = [rid for rid, r in sorted(s["rooms"].items(), key=lambda x: int(x[0])) if r["phase"] == "waiting"]
    for rid in waiting_ids:
        s["rooms"][rid] = empty_room()
    slots = iter(waiting_ids)
    placed = []
    for a, b in pairs:
        rid = next(slots)
        nicks_a = {m.get("nick") for m in a["members"]}
        for m in b["members"]:                         # 끝내 겹치면 반대팀 닉네임에 숫자를 붙임
            if m.get("nick") in nicks_a:
                old = m["nick"]; k = 2
                while f"{old}{k}" in nicks_a or f"{old}{k}" in {x.get('nick') for x in b["members"]}:
                    k += 1
                m["nick"] = f"{old}{k}"; renamed.append((old, m["nick"], rid))
        placed.append((rid, "pro", a)); placed.append((rid, "con", b))
    for t in left:
        rid = next(slots, None)
        if rid is None:
            break
        sd = "pro" if t in teams["pro"] else "con"
        placed.append((rid, sd, t))
    for rid, sd, t in placed:
        r = s["rooms"][rid]
        r[sd] = t["cid"]
        r["members"][sd] = t["members"]
        r[f"{sd}_name"] = ", ".join(member_label(m) for m in t["members"])
        if t.get("avatar"):
            r["avatar"][sd] = t["avatar"]
        cl = s["clients"].get(t["cid"]) or {}
        s["clients"][t["cid"]] = {**cl, "room": rid, "side": sd, "name": r[f"{sd}_name"], "random": True}   # 랜덤 배정으로 옮겨진 학생 표시
    return {"pairs": n, "left": [(t["from"], "pro" if t in teams["pro"] else "con") for t in left], "renamed": renamed,
            "same_room_pairs": sum(1 for a, b in pairs if a["from"] == b["from"])}


def start_room_debate(room):
    set_phase(room, "claim")
    for sd in ("pro", "con"):
        if not room["items"][sd]:
            room["items"][sd] = random.sample(list(ITEM_CATALOG.keys()), STARTING_ITEM_COUNT)


@app.route("/api/teacher/force_advance", methods=["POST"])
def teacher_force_advance():
    room_id = str(request.json.get("room"))
    with LOCK:
        s = load_state()
        room = s["rooms"][room_id]
        phase = room["phase"]
        if phase == "claim":
            for side in ("pro", "con"):
                force_submit_claim(room, side)
            set_phase(room, "prep")
        elif phase == "prep":
            set_phase(room, "qa")
            room["qa"]["current_turn"] = "pro"
            room["qa"]["turn_started_at"] = now()
        elif phase == "qa":
            set_phase(room, "final")
        elif phase == "final":
            for side in ("pro", "con"):
                force_submit_final(room, side)
            set_phase(room, "done")
        room["forced"] = True
        save_state(s)
    return jsonify({"ok": True})


@app.route("/api/teacher/force_back", methods=["POST"])
def teacher_force_back():
    """교사가 실수로 '다음 단계'를 눌렀을 때 되돌리는 버튼.
    단계를 하나 되돌리되, 그 단계에서 시간초과 등으로 '자동 처리'(auto=True)된
    placeholder 내용만 지워서 다시 쓸 수 있게 하고, 학생이 실제로 제출한 진짜 내용(auto=False)은
    절대 건드리지 않는다."""
    room_id = str(request.json.get("room"))
    with LOCK:
        s = load_state()
        if room_id not in s["rooms"]:
            return jsonify({"ok": False, "error": "존재하지 않는 조입니다."})
        room = s["rooms"][room_id]
        phase = room["phase"]

        if phase == "prep":
            set_phase(room, "claim")
            for side in ("pro", "con"):
                c = room["claims"][side]
                if c and c.get("auto"):
                    room["claims"][side] = None
        elif phase == "qa":
            set_phase(room, "prep")
            room["prep_ready"] = {"pro": False, "con": False}
        elif phase == "final":
            set_phase(room, "qa")
            room["qa"]["turn_started_at"] = now()  # 이 턴을 처음부터 다시 시작
        elif phase == "done":
            set_phase(room, "final")
            for side in ("pro", "con"):
                f = room["final"][side]
                if f and f.get("auto"):          # 자동 채움은 두 칸 모두 비워서 다시 쓰게
                    room["final"][side] = None
                    room["selfcheck"][side] = None
        else:
            return jsonify({"ok": False, "error": "이 단계에서는 더 이전으로 되돌릴 수 없습니다."})

        room["forced"] = True
        save_state(s)
    return jsonify({"ok": True})


@app.route("/api/teacher/force_lock_all", methods=["POST"])
def teacher_force_lock_all():
    with LOCK:
        s = load_state()
        for r in s["rooms"].values():
            force_class_timeout(r)
        save_state(s)
    return jsonify({"ok": True})


@app.route("/api/teacher/kick", methods=["POST"])
def teacher_kick():
    """방 전체를 초기화하지 않고, 특정 조의 찬성 또는 반대 자리 한쪽만 비운다.
    (예: 학생이 조/찬반을 잘못 선택해서 들어온 경우) 그동안 그 팀이 이미 제출한
    주장/자유토론/최종의견/자기피드백 내용은 그대로 남아있고, 자리만 비어서
    다른 학생(또는 같은 학생이 다시)이 새로 입장할 수 있게 된다."""
    data = request.json
    room_id = str(data.get("room"))
    side = data.get("side")
    with LOCK:
        s = load_state()
        if room_id not in s["rooms"]:
            return jsonify({"ok": False, "error": "존재하지 않는 조입니다."})
        if side not in ("pro", "con"):
            return jsonify({"ok": False, "error": "잘못된 요청입니다."})
        room = s["rooms"][room_id]
        old_client = room[side]
        if old_client and old_client in s["clients"]:
            del s["clients"][old_client]
        room[side] = None
        room[f"{side}_name"] = None
        save_state(s)
    return jsonify({"ok": True})


@app.route("/api/teacher/reset_room", methods=["POST"])
def teacher_reset_room():
    room_id = str(request.json.get("room"))
    with LOCK:
        s = load_state()
        s["clients"] = {cid: info for cid, info in s["clients"].items() if info["room"] != room_id}
        s["rooms"][room_id] = empty_room()
        save_state(s)
    return jsonify({"ok": True})


@app.route("/api/teacher/reset_all", methods=["POST"])
def teacher_reset_all():
    with LOCK:
        s = default_state()
        save_state(s)
    return jsonify({"ok": True})


@app.route("/api/teacher/new_class", methods=["POST"])
def api_new_class():
    """지난 수업 기록을 반별로 보관하고 새 수업 준비 (주제·AI 설정·동료평가/피드백 선택은 유지)"""
    with LOCK:
        s = load_state()
        archived = None
        if s.get("class_started_at") or any(r["pro"] or r["con"] for r in s["rooms"].values()):
            os.makedirs(ARCHIVE_DIR, exist_ok=True)
            started = s.get("class_started_at") or now()
            aid = time.strftime("%Y%m%d-%H%M", time.localtime(started)) + "_" + re.sub(r"[^0-9A-Za-z가-힣_\-]", "", s.get("class_name") or "반미정")
            base, n = aid, 2
            while os.path.exists(_arch_path(aid)):
                aid = f"{base}-{n}"; n += 1
            with ARCH_LOCK:
                _atomic_write_json(_arch_path(aid), {**s, "archived_at": now(), "archive_id": aid})
            archived = aid
        ns = default_state()
        for k in ("topics", "active_topic", "showcase_enabled", "feedback_enabled", "paste_block", "seteuk_enabled", "room_count", "time_cfg"):
            if k in s:
                ns[k] = s[k]
        save_state(ns)
        TYPING.clear()
    return jsonify({"ok": True, "archived": archived})


@app.route("/api/teacher/desktop_shortcut", methods=["GET", "POST"])
def api_desktop_shortcut():
    """교사 화면 ④: 바탕화면 바로가기 상태 보기(GET) / 다시 만들기(POST)"""
    if request.method == "POST":
        return jsonify(create_desktop_shortcut(force=True))
    rec = load_config().get("desktop_shortcut") or {}
    return jsonify({"windows": IS_WINDOWS, "made": bool(rec), "path": rec.get("path", "")})


@app.route("/api/teacher/time_cfg", methods=["POST"])
def api_time_cfg():
    """단계별 시간(분) 바꾸기 — 수업 시작 전에만. {"reset": true}면 토론앱 기본 시간으로"""
    d = request.json or {}
    with LOCK:
        s = load_state()
        if s.get("class_started_at"):
            return jsonify({"ok": False, "error": "수업이 시작된 뒤에는 시간을 바꿀 수 없어요. (다음 수업에서 바꿔 주세요)"})
        if d.get("reset"):
            s.pop("time_cfg", None)
        else:
            names = {"claim": "최초 주장", "prep": "최초 주장 읽기", "qa": "자유토론", "final": "자기 단련"}
            cur = time_cfg_minutes(s)
            for k in TIME_LIMITS:
                if k not in d:
                    continue
                lo, hi = TIME_LIMITS[k]
                try:
                    v = int(d[k])
                except (TypeError, ValueError):
                    return jsonify({"ok": False, "error": f"{names[k]} 시간은 숫자(분)로 적어 주세요."})
                if not lo <= v <= hi:
                    return jsonify({"ok": False, "error": f"{names[k]} 시간은 {lo}~{hi}분 사이로 정해 주세요."})
                cur[k] = v
            default = {k: v // 60 for k, v in DEFAULT_PHASE_DURATION.items()}
            if cur == default:
                s.pop("time_cfg", None)                     # 기본값과 같으면 '안 바꾼 상태'로
            else:
                s["time_cfg"] = cur
        save_state(s)
        apply_time_cfg(s)
        m = time_cfg_minutes(s)
    return jsonify({"ok": True, "time_cfg": m, "custom": m != {k: v // 60 for k, v in DEFAULT_PHASE_DURATION.items()}})


@app.route("/api/teacher/room_count", methods=["POST"])
def api_room_count():
    """이 수업을 몇 개 조로 할지 (1~MAX_ROOMS). 수업 시작 전에만 바꿀 수 있고, 이미 입장한 조보다 작게는 못 줄임"""
    try:
        n = int((request.json or {}).get("count"))
    except (TypeError, ValueError):
        return jsonify({"ok": False, "error": f"조 수는 1~{MAX_ROOMS} 사이 숫자로 적어 주세요."})
    if not 1 <= n <= MAX_ROOMS:
        return jsonify({"ok": False, "error": f"조 수는 1~{MAX_ROOMS}개까지 정할 수 있어요."})
    with LOCK:
        s = load_state()
        if n == room_count(s):
            return jsonify({"ok": True, "count": n})
        if s.get("class_started_at"):
            return jsonify({"ok": False, "error": "수업이 시작된 뒤에는 조 수를 바꿀 수 없어요. (다음 수업에서 바꿔 주세요)"})
        busy = sorted(int(k) for k, r in s["rooms"].items() if k.isdigit() and int(k) > n and (r.get("pro") or r.get("con")))
        if busy:
            return jsonify({"ok": False, "error": f"{busy[-1]}조에 이미 입장한 팀이 있어서 {n}개 조로 줄일 수 없어요."})
        s["room_count"] = n
        save_state(s)
    return jsonify({"ok": True, "count": n})


@app.route("/api/teacher/archives", methods=["GET"])
def api_archives():
    """지금 수업 + 보관된 반 목록 (생기부·PDF를 만들 대상)"""
    out = []
    def summ(aid, st):
        done = [rid for rid, r in st["rooms"].items() if _both_joined(r) and r["phase"] == "done"]
        studs = sum(len((r.get("members") or {}).get(sd) or []) for rid, r in st["rooms"].items() if rid in done for sd in ("pro", "con"))
        rep = st.get("ai_report") or {}
        status = rep.get("status") or "idle"
        if status == "running" and aid not in REPORT_RUNNING:
            status = "partial" if (rep.get("result") or {}).get("rooms_done") else "idle"
        blank = sum(1 for rid, r in st["rooms"].items() if rid in done for sd in ("pro", "con")
                    for m in ((r.get("members") or {}).get(sd) or []) if not (m.get("sid") and m.get("name")))
        return {"id": aid, "blank": blank, "seteuk": seteuk_enabled(st), "class_name": st.get("class_name") or "", "topic": st.get("active_topic") or "",
                "started_at": st.get("class_started_at"), "archived_at": st.get("archived_at"),
                "rooms_done": sorted(done, key=int), "students": studs, "report": status,
                "progress": rep.get("progress"), "error": rep.get("error")}
    out.append(summ("current", src_load("current")))
    if os.path.isdir(ARCHIVE_DIR):
        for fn in sorted(os.listdir(ARCHIVE_DIR), reverse=True):
            if fn.endswith(".json"):
                try:
                    out.append(summ(fn[:-5], src_load(fn[:-5])))
                except Exception:
                    pass
    return jsonify({"items": out})


@app.route("/api/teacher/roster", methods=["GET", "POST"])
def api_roster():
    """생기부 전에 학번·이름·닉네임 명단 확인·오타 수정 (닉네임은 기록의 열쇠라 바꾸지 않음)"""
    aid = request.args.get("source") or (request.json or {}).get("source") if request.method == "POST" else request.args.get("source")
    aid = aid or "current"
    if request.method == "POST":
        d = request.json or {}
        sid, nm = str(d.get("sid") or "").strip(), str(d.get("name") or "").strip()
        if not re.fullmatch(r"\d{4,6}", sid) or not nm:
            return jsonify({"ok": False, "error": "학번(숫자)과 이름을 확인해 주세요."})
        hit = {"n": 0}
        def fix(st):
            for m in ((st["rooms"].get(str(d.get("room"))) or {}).get("members") or {}).get(d.get("side")) or []:
                if member_label(m) == d.get("nick"):
                    m["sid"], m["name"] = sid, nm; hit["n"] += 1
        src_update(aid, fix)
        return jsonify({"ok": bool(hit["n"])} if hit["n"] else {"ok": False, "error": "해당 학생을 찾지 못했습니다."})
    st = src_load(aid)
    rows = [{"room": rid, "side": sd, "nick": member_label(m), "sid": m.get("sid", ""), "name": m.get("name", "")}
            for rid, r in sorted(st["rooms"].items(), key=lambda x: int(x[0])) for sd in ("pro", "con")
            for m in ((r.get("members") or {}).get(sd) or [])]
    sids = [x["sid"] for x in rows if x["sid"]]
    for x in rows:
        x["dup"] = bool(x["sid"]) and sids.count(x["sid"]) > 1
        x["blank"] = not (x["sid"] and x["name"])
    return jsonify({"rows": rows, "blank": sum(1 for x in rows if x["blank"])})


def roster_status(s):
    """등록된 명단 현황: 총 인원 · 입장한 인원 · 아직 입장 안 한 닉네임"""
    roster = s.get("roster") or []
    here = {m.get("nick") for r in s["rooms"].values() for sd in ("pro", "con") for m in ((r.get("members") or {}).get(sd) or [])}
    missing = [r["nick"] for r in roster if r["nick"] not in here]
    return {"count": len(roster), "joined": len(roster) - len(missing), "missing": missing[:40]}


def parse_roster_lines(text):
    """'학번 이름 닉네임' 줄들 해석 (엑셀·구글 시트에서 3칸 복사 → 탭/쉼표/공백 구분). → (해석된 줄들, 형식이 틀린 줄들)"""
    parsed, bad = [], []
    for ln in str(text or "").splitlines():
        if not ln.strip():
            continue
        toks = [t for t in re.split(r"[\t,]+|\s+", ln.strip()) if t]
        if toks and toks[0] in ("학번", "번호"):
            continue                                              # 제목 줄은 건너뜀
        if len(toks) < 3 or not re.fullmatch(r"\d{4,6}", toks[0]):
            bad.append(ln.strip()[:40]); continue
        parsed.append((toks[0], " ".join(toks[1:-1]), toks[-1]))
    return parsed, bad


@app.route("/api/teacher/roster_register", methods=["POST"])
def api_roster_register():
    """수업 전에 학급 명단(학번·이름·닉네임)을 이 컴퓨터에 등록 → 학생은 닉네임만 입력하고, 입장할 때 학번·이름이 자동으로 연결됨.
    (학번·이름은 인터넷을 거치지 않고, 학생 화면으로도 보내지 않음) 빈 내용을 보내면 명단 삭제"""
    text = str((request.json or {}).get("text") or "")
    parsed, bad = parse_roster_lines(text)
    roster, skipped, seen_nick, seen_sid = [], [f"형식이 틀린 줄: {b}" for b in bad], set(), set()
    for sid, name, nick in parsed:
        why = None
        if not re.fullmatch(r"[0-9A-Za-z가-힣_]{1,10}", nick):
            why = f"닉네임은 띄어쓰기·기호 없이 10자 이내여야 해요 ({nick})"
        elif nick == name or (len(name) >= 3 and nick == name[1:]):
            why = f"닉네임이 실명이에요 ({nick})"
        elif nick.lower() in seen_nick:
            why = f"닉네임이 겹쳐요 ({nick}) — 같은 닉네임이 둘이면 누가 누군지 구분할 수 없어요"
        elif sid in seen_sid:
            why = f"학번이 겹쳐요 ({sid})"
        if why:
            skipped.append(why); continue
        seen_nick.add(nick.lower()); seen_sid.add(sid)
        roster.append({"sid": sid[:6], "name": name[:20], "nick": nick})
    with LOCK:
        s = load_state()
        s["roster"] = roster
        applied, unmatched = 0, []
        by = {r["nick"]: r for r in roster}
        for r in s["rooms"].values():                              # 이미 입장해 있던 학생도 바로 연결
            for sd in ("pro", "con"):
                for m in (r.get("members") or {}).get(sd) or []:
                    hit = by.get(m.get("nick"))
                    if hit:
                        m["sid"], m["name"] = hit["sid"], hit["name"]; applied += 1
                    elif roster:
                        unmatched.append(m.get("nick"))
        save_state(s)
    return jsonify({"ok": True, "count": len(roster), "skipped": skipped, "applied_to_entered": applied, "unmatched_entered": unmatched})


@app.route("/api/teacher/roster_bulk", methods=["POST"])
def api_roster_bulk():
    """인터넷 모드용: '학번 이름 닉네임' 줄들을 한꺼번에 붙여 넣으면 닉네임으로 찾아 학번·이름을 연결 (엑셀·구글 시트에서 3칸 복사)"""
    d = request.json or {}
    aid = d.get("source") or "current"
    parsed, bad = parse_roster_lines(d.get("text"))
    res = {"matched": 0, "unmatched": [], "ambiguous": [], "bad": bad}
    def apply(st):
        idx = {}
        for rid, r in st["rooms"].items():
            for sd in ("pro", "con"):
                for m in (r.get("members") or {}).get(sd) or []:
                    idx.setdefault(member_label(m), []).append(m)
        for sid, name, nick in parsed:
            ms = idx.get(nick) or []
            if not ms:
                res["unmatched"].append(nick)
            elif len(ms) > 1:
                res["ambiguous"].append(nick)                      # 같은 닉네임이 여러 조에 있음 → 개별 입력
            else:
                ms[0]["sid"], ms[0]["name"] = sid[:6], name[:20]; res["matched"] += 1
    try:
        src_update(aid, apply)
    except Exception:
        return jsonify({"ok": False, "error": "기록을 찾을 수 없습니다."})
    return jsonify({"ok": True, **res})


@app.route("/api/teacher/room_pdf/<room_id>", methods=["GET"])
def api_teacher_room_pdf(room_id):
    try:
        s = src_load(request.args.get("source") or "current")
    except Exception:
        return jsonify({"ok": False, "error": "보관된 반 기록을 찾을 수 없습니다."}), 404
    if room_id not in s["rooms"]:
        return jsonify({"ok": False, "error": "존재하지 않는 조입니다."}), 404
    room = s["rooms"][room_id]
    topic = s["active_topic"]
    try:
        pdf_bytes = generate_room_pdf_bytes(room_id, room, topic)
    except Exception:
        import traceback
        print(f"[PDF 생성 오류] {room_id}조 개별 PDF 생성 실패:")
        traceback.print_exc()
        return jsonify({"ok": False, "error": f"{room_id}조 PDF 생성 중 오류가 발생했습니다. 교사 콘솔(검은 창)의 오류 메시지를 확인해주세요."}), 500
    return Response(pdf_bytes, mimetype="application/pdf",
                     headers={"Content-Disposition": ("inline" if request.args.get("inline") else "attachment") + f"; filename=room{room_id}_debate.pdf"})


@app.route("/api/teacher/all_pdfs", methods=["GET"])
def api_teacher_all_pdfs():
    try:
        s = src_load(request.args.get("source") or "current")
    except Exception:
        return jsonify({"ok": False, "error": "보관된 반 기록을 찾을 수 없습니다."}), 404
    topic = s["active_topic"]
    rooms_snapshot = {rid: json.loads(json.dumps(r)) for rid, r in s["rooms"].items()}
    mem = io.BytesIO()
    failed = []
    with zipfile.ZipFile(mem, "w", zipfile.ZIP_DEFLATED) as zf:
        for rid, room in rooms_snapshot.items():
            if not (room["claims"].get("pro") or room["claims"].get("con")):
                continue
            try:
                pdf_bytes = generate_room_pdf_bytes(rid, room, topic)
                zf.writestr(f"{rid}조_토론기록.pdf", pdf_bytes)
            except Exception:
                import traceback
                print(f"[PDF 생성 오류] {rid}조 PDF 생성 실패 (전체 다운로드 중, 이 조만 건너뜀):")
                traceback.print_exc()
                failed.append(rid)
                zf.writestr(f"{rid}조_토론기록_오류.txt",
                             f"{rid}조 PDF 생성 중 오류가 발생해 건너뛰었습니다.\n"
                             f"선생님 노트북의 서버 콘솔(검은 창)에서 정확한 오류 내용을 확인해주세요.")
    mem.seek(0)
    if failed:
        print(f"[PDF 생성 오류] 다음 조는 실패해서 오류 안내문으로 대체됨: {failed}")
    return Response(mem.getvalue(), mimetype="application/zip",
                     headers={"Content-Disposition": "attachment; filename=all_rooms_debate.zip"})


@app.route("/api/teacher/export", methods=["GET"])
def teacher_export():
    with LOCK:
        s = load_state()
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["조", "주제", "찬성팀명", "반대팀명", "단계", "발언팀", "작성자", "내용", "제출시각", "자동제출여부", "시간초과경고횟수"])
    for rid, room in s["rooms"].items():
        base = [rid, s["active_topic"], room.get("pro_name"), room.get("con_name")]
        for side in ("pro", "con"):
            c = room["claims"].get(side)
            if c:
                ts = time.strftime("%H:%M:%S", time.localtime(c["submitted_at"]))
                content = f"주장: {c.get('claim')} / 근거: {c.get('reason')} / 출처: {c.get('source')}"
                writer.writerow(base + ["주장", "찬성" if side == "pro" else "반대", c.get("writer", ""),
                                        content, ts, c.get("auto", False), c.get("warning_level", 0)])
        qa_tc = room["qa"].get("timeout_counts", {}) or {}
        for i, m in enumerate(room["qa"]["messages"], 1):
            ts = time.strftime("%H:%M:%S", time.localtime(m["ts"]))
            writer.writerow(base + [f"자유토론#{i}", "찬성" if m["side"] == "pro" else "반대", "",
                                    m["text"], ts, m.get("auto", False), ""])
        if qa_tc.get("pro") or qa_tc.get("con"):
            writer.writerow(base + ["자유토론(경고누적)", "찬성", "", "", "", "", qa_tc.get("pro", 0)])
            writer.writerow(base + ["자유토론(경고누적)", "반대", "", "", "", "", qa_tc.get("con", 0)])
        for side in ("pro", "con"):
            f = room["final"].get(side)
            if f:
                ts = time.strftime("%H:%M:%S", time.localtime(f["submitted_at"]))
                writer.writerow(base + ["최종의견", "찬성" if side == "pro" else "반대", "",
                                        f.get("text", ""), ts, f.get("auto", False), f.get("warning_level", 0)])
        for side in ("pro", "con"):
            sc = room["selfcheck"].get(side)
            if sc:
                ts = time.strftime("%H:%M:%S", time.localtime(sc["submitted_at"]))
                writer.writerow(base + ["자기피드백", "찬성" if side == "pro" else "반대", "",
                                        sc.get("text", ""), ts, sc.get("auto", False), sc.get("warning_level", 0)])
    mem = io.BytesIO(output.getvalue().encode("utf-8-sig"))
    return Response(mem, mimetype="text/csv",
                     headers={"Content-Disposition": "attachment; filename=debate_export.csv"})


# =====================================================================================
#  인터넷 모드: Cloudflare 터널(cloudflared) 자동 실행 + 짧은 주소 자동 생성
# =====================================================================================
CLOUDFLARED_URL = "https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-windows-amd64.exe"
SHORT_API = "https://xn--0p4b.xn--3e0b707e/api/v1/shorten"     # 숏.한국 (인증 없이 쓰는 공개 API, 한글 코드·만료 지원)
SHORT_WORDS = ["토론", "과학", "논증", "근거", "반박", "탐구", "실험", "우주", "원자", "에너지"]
TUNNEL_RESTART_DELAY = 2
TUNNEL = {"status": "off", "url": "", "short": "", "short_msg": "", "msg": "", "ready_url": ""}
_TUN = {"proc": None, "stop": False, "port": 5000}
_TRY_RE = re.compile(r"https://([a-z0-9][a-z0-9-]*)\.trycloudflare\.com", re.I)


def parse_tunnel_line(line):
    """cloudflared 출력 한 줄 → ("url", 주소) | ("ready", None) | ("err", 내용) | None
    주소: '|  https://xxxx.trycloudflare.com  |' 줄. 연결 완료: 'Registered tunnel connection' 줄"""
    m = _TRY_RE.search(line)
    if m and m.group(1).lower() != "api":
        return ("url", "https://" + m.group(1).lower() + ".trycloudflare.com")
    if "Registered tunnel connection" in line:
        return ("ready", None)
    if re.search(r"\bERR\b", line):
        return ("err", re.sub(r"^\S+\s+ERR\s+", "", line).strip()[:200])
    return None


def find_cloudflared():
    cands = [os.environ.get("DEBATE_CLOUDFLARED") or ""]
    for d in (DATA_DIR, RES_DIR, os.getcwd(), os.path.join(os.path.expanduser("~"), "Desktop", "tunnel")):
        for n in ("cloudflared.exe", "cloudflared"):
            cands.append(os.path.join(d, n))
    for c in cands:
        if c and os.path.isfile(c):
            return c
    return shutil.which("cloudflared")


def ensure_cloudflared():
    """cloudflared 위치 (없으면 윈도우에서는 처음 한 번 내려받음). → (경로, 오류 문구)"""
    p = find_cloudflared()
    if p:
        return p, None
    if os.name != "nt":
        return None, "cloudflared를 찾을 수 없어요. 설치한 뒤 다시 실행해 주세요."
    dest = os.path.join(DATA_DIR, "cloudflared.exe")
    TUNNEL.update(status="downloading", msg="인터넷 연결 도구(cloudflared)를 내려받는 중이에요. 처음 한 번만, 1분쯤 걸려요...")
    print("  ⏬ cloudflared를 내려받는 중... (처음 한 번만)")
    try:
        import urllib.request
        tmp = dest + ".part"
        with urllib.request.urlopen(CLOUDFLARED_URL, timeout=60) as r, open(tmp, "wb") as f:
            total, got, last = int(r.headers.get("Content-Length") or 0), 0, -1
            while True:                                            # 멈춘 것처럼 보이지 않게 진행 상황을 검은 창에 표시
                chunk = r.read(256 * 1024)
                if not chunk:
                    break
                f.write(chunk); got += len(chunk)
                pct = int(got * 100 / total) if total else int(got / 1024 / 1024)
                if pct // 10 != last // 10 or not total:
                    if not total and pct == last:
                        continue
                    last = pct
                    msg = f"{pct}% ({got / 1024 / 1024:.0f}/{total / 1024 / 1024:.0f}MB)" if total else f"{got / 1024 / 1024:.0f}MB"
                    TUNNEL.update(msg=f"인터넷 연결 도구를 내려받는 중이에요... {msg}")
                    print(f"     내려받는 중... {msg}")
        with open(tmp, "rb") as f:
            head = f.read(2)
        if head != b"MZ" or os.path.getsize(tmp) < 5_000_000:
            raise RuntimeError("내려받은 파일이 올바르지 않아요")
        os.replace(tmp, dest)
        return dest, None
    except Exception as e:
        return None, f"cloudflared를 내려받지 못했어요({type(e).__name__}). cloudflared.exe 파일을 이 앱과 같은 폴더에 직접 넣어 주세요."


def copy_to_clipboard(text):
    """주소를 자동으로 복사 (윈도우)"""
    if os.name != "nt":
        return
    try:
        subprocess.Popen(["powershell", "-NoProfile", "-Command", "Set-Clipboard -Value '" + text.replace("'", "''") + "'"],
                         creationflags=0x08000000, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except Exception:
        pass


def _post_json(url, body, timeout=10):
    import urllib.request, urllib.error
    req = urllib.request.Request(url, data=json.dumps(body).encode("utf-8"), headers={"Content-Type": "application/json"}, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return r.status, json.loads(r.read().decode("utf-8") or "{}")
    except urllib.error.HTTPError as e:
        try:
            return e.code, json.loads(e.read().decode("utf-8") or "{}")
        except Exception:
            return e.code, {}


def make_short_link(long_url, code=None):
    """긴 주소 → 짧은 주소 (숏.한국). 보내는 것은 '접속 주소'뿐이고 학생 정보·토론 내용은 없음. 24시간 뒤 만료.
    → (짧은 주소, 오류 문구). 코드가 겹치면 다른 코드로 다시 시도"""
    api = os.environ.get("DEBATE_SHORTENER_URL", SHORT_API)
    tries = [code] if code else [random.choice(SHORT_WORDS) + f"{random.randint(0, 99):02d}" for _ in range(6)]
    last = "알 수 없는 오류"
    for c in tries:
        try:
            status, js = _post_json(api, {"original_url": long_url, "custom_code": c, "expire_duration": "24h"})
        except Exception as e:
            return None, f"짧은 주소 서비스에 연결하지 못했어요({type(e).__name__})"
        d = (js or {}).get("data") or {}
        if status in (200, 201) and d.get("short_url"):
            return d["short_url"], None
        last = str((js or {}).get("message") or f"서비스 응답 오류(HTTP {status})")
        if "사용 중" in last:
            if code:
                return None, "이미 다른 사람이 쓰는 이름이에요. 다른 이름으로 해 보세요."
            continue                                              # 자동 이름이 겹침 → 다른 이름으로
        break
    if not code:                                                  # 이름 규칙 문제일 수 있어 이름 없이 한 번 더
        try:
            status, js = _post_json(api, {"original_url": long_url, "expire_duration": "24h"})
            d = (js or {}).get("data") or {}
            if status in (200, 201) and d.get("short_url"):
                return d["short_url"], None
        except Exception:
            pass
    return None, last


def _make_short_bg(url):
    short, err = make_short_link(url)
    if TUNNEL.get("url") != url:                                  # 그새 주소가 바뀌었으면 버림
        return
    if short:
        TUNNEL.update(short=short, short_msg="")
        print(f"  🔗 짧은 주소: {short}")
        copy_to_clipboard(short)
    else:
        TUNNEL.update(short="", short_msg=f"짧은 주소를 만들지 못했어요 — {err}")
        print(f"  ⚠ 짧은 주소를 만들지 못했어요: {err}")


def _on_tunnel_ready():
    url = TUNNEL["url"]
    if TUNNEL.get("ready_url") == url:
        return
    TUNNEL.update(status="on", msg="", ready_url=url)
    print(f"  🌐 인터넷 주소가 준비됐어요: {url}")
    copy_to_clipboard(url)
    threading.Thread(target=_make_short_bg, args=(url,), daemon=True).start()


def _tunnel_main(port):
    restarts = 0
    while not _TUN["stop"] and restarts <= 3:
        path, err = ensure_cloudflared()
        if not path:
            TUNNEL.update(status="failed", msg=err)
            print(f"  ⚠ {err}")
            return
        TUNNEL.update(status="starting", url="", short="", short_msg="", ready_url="", msg="인터넷 주소를 만드는 중이에요...")
        try:
            proc = subprocess.Popen([path, "tunnel", "--url", f"http://127.0.0.1:{port}"], stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                    text=True, encoding="utf-8", errors="replace")
        except Exception as e:
            TUNNEL.update(status="failed", msg=f"cloudflared를 실행하지 못했어요({type(e).__name__})")
            return
        _TUN["proc"] = proc
        last_err = ""
        for line in proc.stdout:
            ev = parse_tunnel_line(line)
            if not ev:
                continue
            kind, val = ev
            if kind == "url" and TUNNEL["url"] != val:
                TUNNEL.update(url=val, status="connecting", msg="연결을 확인하는 중이에요...")
            elif kind == "ready" and TUNNEL["url"]:
                _on_tunnel_ready()
            elif kind == "err":
                last_err = val
        proc.wait()
        if _TUN["stop"]:
            return
        restarts += 1
        TUNNEL.update(status="restarting", msg="인터넷 연결이 끊겨 주소를 새로 만드는 중이에요. (학생들에게 새 주소를 알려 주세요)")
        print("  ⚠ 인터넷 연결이 끊겼어요. 주소를 새로 만듭니다. (학생들에게 새 주소를 알려 주세요)")
        time.sleep(TUNNEL_RESTART_DELAY)
    TUNNEL.update(status="failed", msg="인터넷 연결을 만들지 못했어요. 학교 인터넷이 막았을 수 있어요. 이 컴퓨터를 다른 인터넷(휴대폰 핫스팟 등)에 연결하고 앱을 다시 켜 보세요.")


def start_tunnel(port):
    _TUN.update(stop=False, port=port)
    threading.Thread(target=_tunnel_main, args=(port,), daemon=True).start()


def stop_tunnel():
    _TUN["stop"] = True
    p = _TUN.get("proc")
    if p and p.poll() is None:
        try:
            p.terminate()
        except Exception:
            pass


atexit.register(stop_tunnel)


@app.route("/api/teacher/short", methods=["POST"])
def api_make_short():
    """교사: 짧은 주소 (다시) 만들기 — 원하는 이름(한글 가능)을 넣을 수도 있음"""
    if not INTERNET_MODE or not TUNNEL.get("url"):
        return jsonify({"ok": False, "error": "인터넷 주소가 아직 준비되지 않았어요."})
    code = re.sub(r"[^0-9A-Za-z가-힣_]", "", str((request.json or {}).get("code") or ""))[:20] or None
    short, err = make_short_link(TUNNEL["url"], code)
    if short:
        TUNNEL.update(short=short, short_msg="")
        copy_to_clipboard(short)
        return jsonify({"ok": True, "short": short})
    return jsonify({"ok": False, "error": err})


def decide_internet_mode():
    """앱은 언제나 인터넷 모드(Cloudflare 터널)로 켜짐. 같은 와이파이 방식은 배포판에서 뺐음.
    (개발용 자동 테스트만 환경변수 DEBATE_INTERNET=0 으로 터널 없이 켤 수 있음)"""
    if os.environ.get("DEBATE_INTERNET") == "0":
        return False
    return True


_IP_CACHE = {"ip": None, "at": 0}


def student_url():
    """교사 화면에 띄울 학생 접속 주소 (1분마다만 다시 확인). 인터넷 모드면 짧은 주소 → 긴 주소 순"""
    if INTERNET_MODE:
        return TUNNEL.get("short") or TUNNEL.get("url") or ""
    if not _IP_CACHE["ip"] or now() - _IP_CACHE["at"] > 60:
        _IP_CACHE.update(ip=primary_ip(), at=now())
    host = request.host or ""
    port = host.rsplit(":", 1)[1] if ":" in host else "80"
    return f"http://{_IP_CACHE['ip']}:{port}"


def primary_ip():
    """학생들이 접속할 이 컴퓨터의 주소 (와이파이/랜 IP)"""
    ips = [x for x in local_addrs(refresh=True) if x not in ("127.0.0.1", "::1") and ":" not in x and not x.startswith("169.254.")]
    for pref in ("192.168.", "10.", "172."):
        for x in ips:
            if x.startswith(pref):
                return x
    return ips[0] if ips else "127.0.0.1"


def _port_free(port):
    """그 번호에 실제로 응답하는 프로그램이 있는지로 판단 (방금 끈 서버의 '연결 흔적' 때문에 비었는데도 사용 중으로 착각하지 않게)"""
    t = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    t.settimeout(0.5)
    try:
        return t.connect_ex(("127.0.0.1", port)) != 0
    finally:
        t.close()


def _is_our_app(port):
    import urllib.request
    try:
        with urllib.request.urlopen(f"http://127.0.0.1:{port}/api/topics", timeout=2) as r:
            return "topics" in json.loads(r.read().decode("utf-8"))
    except Exception:
        return False


def _open_when_ready(url, port):
    """서버가 응답할 때까지 기다렸다가 교사 화면을 브라우저로 염"""
    import webbrowser
    for _ in range(60):
        if _is_our_app(port):
            break
        time.sleep(0.25)
    webbrowser.open(url)


def selftest():
    """exe를 만든 직후 점검: 화면 파일·그림·한글 PDF가 프로그램 안에 제대로 들어갔는지. 문제없으면 0"""
    try:
        for f in ("templates/index.html", "templates/room.html", "templates/teacher.html", "static/game/engine.js", "static/game/classroom.webp", "fonts/NotoSansKR-Regular.ttf"):
            assert os.path.isfile(os.path.join(RES_DIR, f)), f"없음: {f}"
        c = app.test_client()
        assert c.get("/").status_code == 200 and c.get("/static/game/face_lion.webp").status_code == 200
        room = default_state()["rooms"]["1"]
        room["claims"]["pro"] = {"claim": "한글 PDF 점검", "reason": "근거", "source": "출처", "writer": "", "submitted_at": now()}
        pdf = generate_room_pdf_bytes("1", room, "점검용 주제")
        assert pdf[:4] == b"%PDF" and len(pdf) > 1000
        print("SELFTEST OK — 화면·그림·한글 PDF 모두 정상")
        return 0
    except Exception as e:
        print(f"SELFTEST FAIL — {type(e).__name__}: {e}")
        return 1


def main():
    if "--selftest" in sys.argv:
        sys.exit(selftest())
    for stream in (sys.stdout, sys.stderr):        # 윈도우 검은 창이 이모지·한글을 못 찍어도 앱이 꺼지지 않게
        try:
            stream.reconfigure(errors="replace")
        except Exception:
            pass
    global INTERNET_MODE
    INTERNET_MODE = decide_internet_mode()
    import signal
    def _graceful(*_):                 # 종료 신호(Ctrl+Break·종료 요청)를 받으면 남은 변경을 저장하고 끝냄
        flush_state()
        os._exit(0)
    for _name in ("SIGTERM", "SIGBREAK"):
        _sig = getattr(signal, _name, None)
        if _sig is not None:
            try:
                signal.signal(_sig, _graceful)
            except Exception:
                pass
    port = int(os.environ.get("DEBATE_PORT", "5000"))
    auto_open = (os.name == "nt" or getattr(sys, "frozen", False) or os.environ.get("DEBATE_OPEN_BROWSER") == "1") \
        and os.environ.get("DEBATE_NO_BROWSER") != "1"
    if not _port_free(port):
        if _is_our_app(port):                      # 이미 켜져 있음 → 새로 켜지 않고 교사 화면만 다시 열기
            print(" 토론 앱이 이미 실행 중이에요. 교사 화면을 다시 엽니다.")
            if auto_open:
                import webbrowser
                webbrowser.open(f"http://127.0.0.1:{port}/teacher")
            time.sleep(2)
            return
        for p in range(5001, 5020):               # 다른 프로그램이 5000번을 쓰고 있으면 빈 번호로
            if _port_free(p):
                port = p
                break
    teacher_url = f"http://127.0.0.1:{port}/teacher"
    print("=" * 62)
    print("  🗣️  토론 수업 앱이 켜졌어요   (이 검은 창을 닫으면 앱이 꺼집니다)")
    print(f"  교사 화면 : {teacher_url}" + ("   ← 자동으로 열려요" if auto_open else ""))
    if INTERNET_MODE:
        print("  🌐 인터넷 모드: 학생은 같은 와이파이가 아니어도 접속할 수 있어요.")
        print("     교사 화면 맨 위에 '학생 접속 주소'와 '접속 코드'가 나와요. (주소는 잠시 뒤에 만들어져요)")
    else:
        print(f"  학생 접속 : http://{primary_ip()}:{port}   (같은 와이파이일 때)")
        print("  ※ 처음 실행 때 'Windows 보안 경고(방화벽)'가 뜨면 [액세스 허용]을 눌러 주세요.")
        print("     (학교 와이파이가 '공용 네트워크'면 공용에도 체크해야 학생이 접속할 수 있어요)")
    print(f"  기록 저장 위치: {DATA_DIR}")
    print("=" * 62)
    if IS_WINDOWS and os.environ.get("DEBATE_NO_SHORTCUT") != "1":
        threading.Thread(target=_auto_shortcut, daemon=True).start()        # 바탕화면 바로가기 (처음 한 번)
    if INTERNET_MODE:
        threading.Thread(target=ensure_enc_key, daemon=True).start()
        start_tunnel(port)
    if auto_open:
        threading.Thread(target=_open_when_ready, args=(teacher_url, port), daemon=True).start()
    try:
        from waitress import serve             # 운영용 서버: 동시 접속에 강하고 빠름
        serve(app, host="0.0.0.0", port=port, threads=16, connection_limit=300)   # 학생 기기가 많아도(최대 10개 조) 접속이 막히지 않게
    except ImportError:
        app.run(host="0.0.0.0", port=port, debug=False, threaded=True)


if __name__ == "__main__":
    main()
