@echo off
chcp 65001 >nul
title 토론 앱 exe 만들기
cd /d "%~dp0"
echo.
echo  ============================================================
echo   토론 수업 앱을 DebateApp 폴더(실행 파일 DebateApp.exe)로 만듭니다.
echo   폴더형이라 켤 때마다 압축을 풀지 않아 빨리 켜져요.
echo   처음 한 번만 하면 되고, 3~5분 걸려요. 인터넷이 필요해요.
echo  ============================================================
echo.

set "PY="
py -3 -c "import sys" >nul 2>nul && set "PY=py -3"
if not defined PY python -c "import sys; sys.exit(0 if sys.version_info >= (3,8) else 1)" >nul 2>nul && set "PY=python"
if not defined PY goto nopython

echo  [1/4] 필요한 부품을 설치하는 중...
%PY% -m pip install --disable-pip-version-check flask reportlab waitress pyinstaller
if errorlevel 1 goto fail

echo  [2/4] 인터넷 연결 도구(cloudflared)를 준비하는 중...
if exist "cloudflared.exe" goto cfok
if exist "%USERPROFILE%\Desktop\tunnel\cloudflared.exe" copy /y "%USERPROFILE%\Desktop\tunnel\cloudflared.exe" "cloudflared.exe" >nul
if exist "cloudflared.exe" goto cfok
powershell -NoProfile -Command "try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; Invoke-WebRequest -UseBasicParsing -Uri 'https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-windows-amd64.exe' -OutFile 'cloudflared.exe' } catch { exit 1 }"
if not exist "cloudflared.exe" echo   (내려받지 못했어요. 괜찮아요 - 앱을 처음 켤 때 다시 시도하고, 안 되면 cloudflared.exe 를 이 폴더에 넣어 주세요)
:cfok

echo  [3/4] exe 를 만드는 중... 화면에 글자가 많이 지나가도 정상이에요.
%PY% -m PyInstaller --noconfirm --clean --onedir --name DebateApp --icon "app_icon.ico" ^
  --exclude-module tkinter --exclude-module unittest --exclude-module pydoc --exclude-module test ^
  --add-data "templates;templates" --add-data "static;static" --add-data "fonts;fonts" --add-data "seteuk_reference.md;." --add-data "app_icon.ico;." ^
  --collect-all reportlab --hidden-import waitress app.py
if errorlevel 1 goto fail
if not exist "dist\DebateApp\DebateApp.exe" goto fail

echo  [4/4] 정리하는 중...
if exist "DebateApp" rmdir /s /q "DebateApp" >nul 2>nul
xcopy /e /i /y /q "dist\DebateApp" "DebateApp" >nul
if exist "DebateApp.exe" del /q "DebateApp.exe" >nul 2>nul
echo  [점검] 만든 프로그램이 제대로 동작하는지 확인하는 중...
"DebateApp\DebateApp.exe" --selftest
if errorlevel 1 goto selffail
rmdir /s /q build >nul 2>nul
rmdir /s /q dist >nul 2>nul
del /q DebateApp.spec >nul 2>nul

echo.
echo  ============================================================
echo   완료! 이제 토론앱_시작.bat 을 더블클릭하거나, DebateApp 폴더 안의 DebateApp.exe 를 더블클릭하면 됩니다.
echo   - 처음 켤 때 바탕화면에 '토론 수업 앱' 바로가기(사자 아이콘)가 자동으로 생겨요. 다음부터는 그걸 두 번 누르세요.
echo   - 인터넷 연결, 짧은 주소 만들기, 교사 화면 열기가 한 번에 자동으로 돼요.
echo   - 같은 와이파이로 쓰고 싶은 날은 토론앱_같은와이파이.bat 을 쓰세요.
echo   - cloudflared.exe 는 이 폴더(DebateApp 폴더 바깥)에 그대로 두세요.
echo   - 수업 기록은 이 폴더에 저장돼요. 다른 컴퓨터로 옮길 때는 이 폴더를 통째로 옮기세요.
echo   - 처음 실행 때 "Windows의 PC 보호" 창이 뜨면 [추가 정보] - [실행]을 누르세요.
echo  ============================================================
pause
exit /b

:nopython
echo.
echo  [안내] exe 를 만들려면 이 컴퓨터에 파이썬이 한 번은 필요해요.
echo   python.org 에서 설치할 때 "Add python.exe to PATH" 를 체크하고 다시 실행하세요.
echo   다 만든 DebateApp 폴더는 파이썬이 없는 다른 컴퓨터에서도 실행돼요.
start "" "https://www.python.org/downloads/"
pause
exit /b

:selffail
echo.
echo  [안내] 프로그램은 만들어졌지만 자체 점검에서 문제가 발견됐어요. 위 메시지를 사진으로 찍어 보내 주세요.
echo   그동안은 토론앱_시작.bat 으로 쓰면 됩니다 (파이썬으로 실행).
if exist "DebateApp" rmdir /s /q "DebateApp" >nul 2>nul
pause
exit /b

:fail
echo.
echo  [안내] exe 만들기에 실패했어요. 인터넷 연결을 확인하고 다시 실행해 주세요.
echo   그래도 안 되면 '토론앱_시작.bat' 으로 실행해도 똑같이 쓸 수 있어요.
pause
exit /b
